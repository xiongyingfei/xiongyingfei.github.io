This file contains information on how to build this plugin.

Some external libraries are required but not available on the CVS repository.
You need to download the jar files into the lib/ directory of this project.

Download ANTLR from http://antlr.org/ and put antlr.jar into lib/.
Download mdr-standalone.zip from http://mdr.netbeans.org/download/ and put
the included jar files into lib/.

Note that mdr-standalone.zip is updated more often on the MDR website than
in our development source. As a consequence, bugs may appear when using
the last-in-date mdr-standalone version of MDR.
