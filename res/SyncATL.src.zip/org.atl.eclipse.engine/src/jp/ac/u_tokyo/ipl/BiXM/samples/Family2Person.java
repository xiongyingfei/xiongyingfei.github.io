/*
 * Copyright (c) 2007, Xiong Yingfei, SwiftWing Studio
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM.samples;

import jp.ac.u_tokyo.ipl.BiXM.Main;

public class Family2Person {

    /**
     * @param args
     */
    public static void main(String[] args) {
        Main.main(new String[] { "--f", "--trans", 
                "file:TestData/Family2Person.asm",
                "--in", "IN=file:./TestData/Source.Families",
                "Families=file:TestData/Families.ecore", "--out",
                "OUT=TestData/Target.persons",
                "Persons=file:TestData/Persons.ecore" });

    }

}
