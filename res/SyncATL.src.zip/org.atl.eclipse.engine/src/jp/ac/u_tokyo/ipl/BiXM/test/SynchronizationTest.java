/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM.test;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Set;

import jp.ac.u_tokyo.ipl.BiXM.Main;
import jp.ac.u_tokyo.ipl.BiXM.Executor.ModificationNotAcceptedException;

import org.atl.engine.repositories.emf4atl.ASMEMFModel;
import org.atl.engine.repositories.emf4atl.ASMEMFModelElement;
import org.atl.engine.repositories.emf4atl.test.ModelHelper;
import org.atl.engine.vm.nativelib.ASMModelElement;
import org.atl.engine.vm.nativelib.ASMOclAny;
import org.atl.engine.vm.nativelib.ASMReference;
import org.atl.engine.vm.nativelib.ASMString;
import org.eclipse.core.internal.runtime.FindSupport;
import org.junit.Test;

public class SynchronizationTest {

    public void execute(String[] args) throws Exception {
        Main main = new Main();
        int argsLeft = args.length;
        argsLeft = main.parseArgs(args);
        if (argsLeft > -1)
            main.actualRun();

    }
    
    private ASMEMFModel _newSrc;
    private ASMEMFModel _newTgt;

    private void synchronize(String transformationFileName,
            String srcPath, String srcMetaName, String srcMetaPath, String tgt,
            String tgtMetaName, String tgtMetaPath, String modifiedSrcPath,
            String outSrc, String outTgt,
            boolean checkIF)
            throws FileNotFoundException, Exception {
        String[] cmdLineArgs = new String[] { "--s", "--trans",
                "file:" + transformationFileName, "--src", "IN=file:" + srcPath,
                srcMetaName + "=file:" + srcMetaPath, "--tgt",
                "OUT=file:" + tgt, tgtMetaName + "=file:" + tgtMetaPath,
                "--modifiedSrc", "IN=file:" + modifiedSrcPath,
                "--outSrc", "IN=" + outSrc, "--outTgt", "OUT=" + outTgt  };

        if (checkIF) {
            String[] temp = cmdLineArgs;
            cmdLineArgs = new String[temp.length + 1];
            for (int i = 0; i < temp.length; i++)
                cmdLineArgs[i] = temp[i];
            cmdLineArgs[temp.length] = "--checkif";
        }

        execute(cmdLineArgs);

        // ModelLoader loader = new EMFModelLoader();
        ASMEMFModel mof = ASMEMFModel.createMOF();
        InputStream srcMeta = new FileInputStream(new File(srcMetaPath));
        ASMEMFModel srcmetaModel = ASMEMFModel.loadASMEMFModel("meta", mof,
                srcMeta);
        InputStream tgtMeta = new FileInputStream(new File(tgtMetaPath));
        ASMEMFModel tgtmetaModel = ASMEMFModel.loadASMEMFModel("meta", mof,
                tgtMeta);
        InputStream newSrcStream = new FileInputStream(new File(outSrc));
        _newSrc = ASMEMFModel.loadASMEMFModel("outSrc",
                srcmetaModel, newSrcStream);
        InputStream newTgtStream = new FileInputStream(new File(outTgt));
        _newTgt = ASMEMFModel.loadASMEMFModel("outTgt",
                tgtmetaModel, newTgtStream);
    }
    

    @Test
    public void TestFamily2Person() throws Exception {
        String outTgt = "TestData/Target-out.persons";
        String outSrc = "TestData/Source-out.Families";
        String tgtMeta = "TestData/Persons.ecore";
        String transformationFileName = "TestData/Family2Person.asm";
        String src = "TestData/Source.Families";
        String srcMeta = "TestData/Families.ecore";
        String srcMetaName = "Families";
        String tgtMetaName = "Persons";
        String modifiedSrc = "TestData/Source-modified.Families";
        String modifiedTgt = "TestData/Target-modified.Persons";

        synchronize(transformationFileName,
                src, srcMetaName, srcMeta, modifiedTgt, tgtMetaName, tgtMeta,
                modifiedSrc, outSrc, outTgt, false);

        assertEquals(6, _newSrc.getElementsByType("Member").size());
        ASMModelElement liu1111bei = ModelHelper.findModelElementByAttribute(
                _newSrc, "Member", "firstName", "Bei");
        assertEquals(new ASMString("Liu"), ((ASMReference) liu1111bei.get(
                null, "family")).getModelElement().get(null, "lastName"));
        assertNotNull(ModelHelper.findModelElementByAttribute(
                _newSrc, "Family", "lastName", "Xiong"));
        assertNull(ModelHelper.findModelElementByAttribute(
                _newSrc, "Member", "firstName", "Ni"));
        
        assertEquals(6, _newTgt.getElementsByType("Person").size());
        ASMModelElement XXYY = ModelHelper.findModelElementByAttribute(
                _newTgt, "Person", "lastName", "XX");
        assertNotNull(XXYY);
        assertEquals(new ASMString("YY"), XXYY.get(null, "firstName"));
        
    }
    
    
    @Test
    public void TestClass2Relational() throws Exception {
        String outTgt = "TestData/TargetID-out.relational";
        String outSrc = "TestData/SourceID-out.classes";
        String tgtMeta = "TestData/RelationalID.xmi";
        String transformationFileName = "TestData/Class2RelationalID.asm";
        String src = "TestData/SourceID.classes";
        String srcMeta = "TestData/ClassID.xmi";
        String srcMetaName = "Class";
        String tgtMetaName = "Relational";
        String modifiedSrc = "TestData/SourceID-modified.classes";
        String modifiedTgt = "TestData/TargetID-modified.relational";

        synchronize(transformationFileName,
                src, srcMetaName, srcMeta, modifiedTgt, tgtMetaName, tgtMeta,
                modifiedSrc, outSrc, outTgt, false);

        assertEquals(4, _newSrc.getElementsByType("Attribute").size());
        
        assertEquals(8, _newTgt.getElementsByType("Column").size());

        assertNotNull(ModelHelper.findModelElementByAttribute(
                _newSrc, "Attribute", "name", "email1234Addresses"));

        assertNull(ModelHelper.findModelElementByAttribute(
                _newSrc, "Attribute", "name", "emailAddresses"));

        assertNull(ModelHelper.findModelElementByAttribute(
                _newSrc, "Attribute", "name", "closestFriend"));

        

    }

}
