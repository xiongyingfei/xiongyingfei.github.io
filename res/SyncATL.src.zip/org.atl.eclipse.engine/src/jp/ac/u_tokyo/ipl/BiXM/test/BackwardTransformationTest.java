/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM.test;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Set;

import jp.ac.u_tokyo.ipl.BiXM.Main;
import jp.ac.u_tokyo.ipl.BiXM.Executor.ModificationNotAcceptedException;

import org.atl.engine.repositories.emf4atl.ASMEMFModel;
import org.atl.engine.repositories.emf4atl.ASMEMFModelElement;
import org.atl.engine.repositories.emf4atl.test.ModelHelper;
import org.atl.engine.vm.nativelib.ASMModelElement;
import org.atl.engine.vm.nativelib.ASMOclAny;
import org.atl.engine.vm.nativelib.ASMReference;
import org.atl.engine.vm.nativelib.ASMString;
import org.eclipse.core.internal.runtime.FindSupport;
import org.junit.Test;

public class BackwardTransformationTest {

    public void execute(String[] args) throws Exception {
        Main main = new Main();
        int argsLeft = args.length;
        argsLeft = main.parseArgs(args);
        if (argsLeft > -1)
            main.actualRun();

    }

    private ASMEMFModel executeBackward(String transformationFileName,
            String in, String inMetaName, String inMeta, String out,
            String outMetaName, String outMeta, String newin, boolean checkIF)
            throws FileNotFoundException, Exception {
        new File(newin).delete();
        String[] cmdLineArgs = new String[] { "--b", "--trans",
                        "file:" + transformationFileName, "--in", "IN=file:" + in,
                        inMetaName + "=file:" + inMeta, "--out", "OUT=file:" + out,
                        outMetaName + "=file:" + outMeta, "--newin", "IN=" + newin};
        
        if (checkIF) {
            String[] temp = cmdLineArgs;
            cmdLineArgs = new String[temp.length + 1];
            for(int i = 0; i < temp.length; i++)
                cmdLineArgs[i] = temp[i];
            cmdLineArgs[temp.length] = "--checkif"; 
        }

        execute(cmdLineArgs);

        // ModelLoader loader = new EMFModelLoader();
        ASMEMFModel mof = ASMEMFModel.createMOF();
        InputStream metaStream = new FileInputStream(new File(inMeta));
        ASMEMFModel metaModel = ASMEMFModel.loadASMEMFModel("meta", mof,
                metaStream);
        InputStream newInStream = new FileInputStream(new File(newin));
        ASMEMFModel newInModel = ASMEMFModel.loadASMEMFModel("output",
                metaModel, newInStream);
        return newInModel;
    }

    @Test
    public void TestFamily2Person() throws Exception {
        String outputFile = "TestData/Target-updated.persons";
        String outputMeta = "TestData/Persons.ecore";
        String transformationFileName = "TestData/Family2Person.asm";
        String inputFile = "TestData/Source.Families";
        String inputMeta = "TestData/Families.ecore";
        String inName = "Families";
        String outName = "Persons";
        String newInFile = "TestData/Source-updated.Families";

        ASMEMFModel newSource = executeBackward(transformationFileName,
                inputFile, inName, inputMeta, outputFile, outName, outputMeta,
                newInFile, false);

        assertEquals(5, newSource.getElementsByType("Member").size());
        ASMModelElement liu1111bei = ModelHelper.findModelElementByAttribute(
                newSource, "Member", "firstName", "Bei");
        assertEquals(new ASMString("Liu11111"), ((ASMReference) liu1111bei.get(
                null, "family")).getModelElement().get(null, "lastName"));
    }
    
    @Test
    public void TestUnchangedFamily2Person() throws Exception {
        String outputFile = "TestData/Target.persons";
        String outputMeta = "TestData/Persons.ecore";
        String transformationFileName = "TestData/Family2Person.asm";
        String inputFile = "TestData/Source.Families";
        String inputMeta = "TestData/Families.ecore";
        String inName = "Families";
        String outName = "Persons";
        String newInFile = "TestData/Source-updated.Families";

        ASMEMFModel newSource = executeBackward(transformationFileName,
                inputFile, inName, inputMeta, outputFile, outName, outputMeta,
                newInFile, false);

        assertEquals(6, newSource.getElementsByType("Member").size());
        ASMModelElement liubei = ModelHelper.findModelElementByAttribute(
                newSource, "Member", "firstName", "Bei");
        assertEquals(new ASMString("Liu"), ((ASMReference) liubei.get(
                null, "family")).getModelElement().get(null, "lastName"));
    }
      
    @Test
    public void TestClass2Table() throws Exception {
        String outputFile = "TestData/Target-updated.relational";
        String outputMeta = "TestData/Relational.xmi";
        String transformationFileName = "TestData/Class2Relational.asm";
        String inputFile = "TestData/Source.classes";
        String inputMeta = "TestData/Class.xmi";
        String inName = "Class";
        String outName = "Relational";
        String newInFile = "TestData/Source-updated.classes";

        ASMEMFModel newSource = executeBackward(transformationFileName,
                inputFile, inName, inputMeta, outputFile, outName, outputMeta,
                newInFile, false);
        
        assertEquals(5, newSource.getElementsByType("Attribute").size());
        assertEquals(2, newSource.getElementsByType("Class").size());
        
        ASMModelElement closestFriend = ModelHelper.findModelElementByAttribute(
                newSource, "Attribute", "name", "closestFriend");

        ASMModelElement Family = ModelHelper.findModelElementByAttribute(
                newSource, "Class", "name", "Family");
        
        assertEquals(new ASMReference(Family), closestFriend.get(null, "owner"));
    }

    @Test
    public void TestClass2TableID() throws Exception {
        String outputFile = "TestData/TargetID-updated.relational";
        String outputMeta = "TestData/RelationalID.xmi";
        String transformationFileName = "TestData/Class2RelationalID.asm";
        String inputFile = "TestData/SourceID.classes";
        String inputMeta = "TestData/ClassID.xmi";
        String inName = "Class";
        String outName = "Relational";
        String newInFile = "TestData/SourceID-updated.classes";

        ASMEMFModel newSource = executeBackward(transformationFileName,
                inputFile, inName, inputMeta, outputFile, outName, outputMeta,
                newInFile, false);
        
        assertEquals(5, newSource.getElementsByType("Attribute").size());
        assertEquals(2, newSource.getElementsByType("Class").size());

        assertNotNull(ModelHelper.findModelElementByAttribute(
                newSource, "Attribute", "name", "email1234Addresses"));

        assertNull(ModelHelper.findModelElementByAttribute(
                newSource, "Attribute", "name", "emailAddresses"));

    }

    
    @Test(expected=ModificationNotAcceptedException.class)
    public void TestClass2TableViolatingIf() throws Exception {
        String outputFile = "TestData/Target-updated-violateIF.relational";
        String outputMeta = "TestData/Relational.xmi";
        String transformationFileName = "TestData/Class2Relational.asm";
        String inputFile = "TestData/Source.classes";
        String inputMeta = "TestData/Class.xmi";
        String inName = "Class";
        String outName = "Relational";
        String newInFile = "TestData/Source-updated.classes";

        executeBackward(transformationFileName,
                inputFile, inName, inputMeta, outputFile, outName, outputMeta,
                newInFile, true);
        
    }



}
