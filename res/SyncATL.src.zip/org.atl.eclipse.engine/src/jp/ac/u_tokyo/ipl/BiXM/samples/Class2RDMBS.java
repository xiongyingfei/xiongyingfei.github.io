/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM.samples;

import jp.ac.u_tokyo.ipl.BiXM.Main;

public class Class2RDMBS {

    /**
     * @param args
     */
    public static void main(String[] args) {
        Main.main(new String[] { "--f", "--trans", 
                "file:TestData/Class2Relational.asm",
                "--in", "IN=file:./TestData/Source.classes",
                "Class=file:TestData/Class.xmi", "--out",
                "OUT=TestData/Target.relational",
                "Relational=file:TestData/Relational.xmi" });
    }

}
