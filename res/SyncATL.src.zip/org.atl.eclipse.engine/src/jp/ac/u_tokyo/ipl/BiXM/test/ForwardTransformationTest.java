package jp.ac.u_tokyo.ipl.BiXM.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Set;

import jp.ac.u_tokyo.ipl.BiXM.Main;

import org.atl.engine.repositories.emf4atl.ASMEMFModel;
import org.atl.engine.repositories.emf4atl.ASMEMFModelElement;
import org.atl.engine.vm.nativelib.ASMBoolean;
import org.atl.engine.vm.nativelib.ASMCollection;
import org.atl.engine.vm.nativelib.ASMModelElement;
import org.atl.engine.vm.nativelib.ASMOclAny;
import org.atl.engine.vm.nativelib.ASMReference;
import org.atl.engine.vm.nativelib.ASMString;
import org.junit.Test;

/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */

public class ForwardTransformationTest {

    public void execute(String[] args) {
        Main main = new Main();
        int argsLeft = args.length;
        argsLeft = main.parseArgs(args);
        if (argsLeft > -1)
            main.run();

    }

    private ASMEMFModel executeForward(String transformationFileName,
            String in, String inMetaName, String inMeta, 
            String out, String outMetaName, String outMeta)
            throws FileNotFoundException, Exception {
        new File(out).delete();
        execute(new String[] { "--f", "--trans",
                "file:" + transformationFileName, "--in",
                "IN=file:" + in, inMetaName + "=file:" + inMeta, "--out",
                "OUT=" + out, outMetaName + "=file:" + outMeta });

//        ModelLoader loader = new EMFModelLoader();
        ASMEMFModel mof = ASMEMFModel.createMOF();
        InputStream metaStream = new FileInputStream(new File(outMeta));
        ASMEMFModel metaModel = ASMEMFModel.loadASMEMFModel("meta", mof,
                metaStream);
        InputStream outStream = new FileInputStream(new File(out));
        ASMEMFModel outputModel = ASMEMFModel.loadASMEMFModel("output",
                metaModel, outStream);
        return outputModel;
    }

    @Test
    public void TestFamily2Person() throws Exception {
        String outputFile = "TestData/Target.persons";
        String outputMeta = "TestData/Persons.ecore";
        String transformationFileName = "TestData/Family2Person.asm";
        String inputFile = "TestData/Source.Families";
        String inputMeta = "TestData/Families.ecore";
        String inName = "Families";
        String outName = "Persons";

        ASMEMFModel outputModel = executeForward(transformationFileName,
                inputFile, inName, inputMeta, outputFile, outName, outputMeta);

        Set set = outputModel.getElementsByType("Person");
        assertEquals(6, set.size());
        assertSinglePerson(set, "Yingfei", "Xiong");
        assertSinglePerson(set, "Dongxi", "Liu");
        assertSinglePerson(set, "Zhenjiang", "Hu");
        
    }

    private void assertSinglePerson(Set set, String firstName, String lastName) {
        ASMModelElement yingfei = findElement(set, "firstName", new ASMString(firstName));
        assertEquals(new ASMString(lastName), yingfei.get(null, "lastName"));
    }
    
    private ASMModelElement findElement(Set objects, String propertyName, ASMOclAny expectedValue) {
        for (Object o : objects) {
            ASMEMFModelElement elem = (ASMEMFModelElement) o;
            if (elem.get(null, propertyName).equals(expectedValue))
                return elem;
        }
        return null;
    }

    @Test
    public void TestClass2Relational() throws Exception {
        String transformationFileName = "TestData/Class2Relational.asm";
        String inputFile = "TestData/Source.classes";
        String inputMeta = "TestData/Class.xmi";
        String outputFile = "TestData/Target.relational";
        String outputMeta = "TestData/Relational.xmi";
        String inName = "Class";
        String outName = "Relational";

        ASMEMFModel outputModel = executeForward(transformationFileName,
                inputFile, inName, inputMeta, outputFile, outName, outputMeta);

        Set tables = outputModel.getElementsByType("Table");
        assertEquals(4, tables.size());
        Set columns = outputModel.getElementsByType("Column");
        assertEquals(9, columns.size());
        Set types = outputModel.getElementsByType("Type");
        assertEquals(2, types.size());
        
        ASMModelElement person = findElement(tables, "name", new ASMString("Person"));
        assertNotNull(person);
        ASMModelElement closestFriendID = findElement(columns, "name", new ASMString("closestFriendId"));
        assertNotNull(closestFriendID);
        ASMModelElement stringType = findElement(types, "name", new ASMString("Integer"));
        assertNotNull(stringType);
        
        assertEquals(new ASMReference(stringType), closestFriendID.get(null, "type"));

        assertEquals(new ASMBoolean(true), 
                ASMCollection.includes(null, (ASMCollection)person.get(null, "col"), 
                        new ASMReference(closestFriendID)));
    }
}
