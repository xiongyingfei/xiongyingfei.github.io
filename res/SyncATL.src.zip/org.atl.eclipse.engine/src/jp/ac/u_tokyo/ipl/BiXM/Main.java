/*
 * Created on 2-jun-2005
 * (C) 2005, Dennis Wagelaar, SSEL, VUB
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License, version 2 as
 *  published by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *  (See the file "COPYING" that is included with this source distribution.)
 */
package jp.ac.u_tokyo.ipl.BiXM;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import jp.ac.u_tokyo.ipl.BiXM.Executor.ModificationNotAcceptedException;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.Verifier;

import org.atl.eclipse.engine.AtlEMFModelHandler;
import org.atl.eclipse.engine.AtlLauncher;
import org.atl.eclipse.engine.AtlModelHandler;
import org.atl.engine.repositories.emf4atl.ASMEMFModel;
import org.atl.engine.repositories.emf4atl.ModelDifferencer;
import org.atl.engine.vm.nativelib.ASMModel;
import org.eclipse.emf.common.util.URI;

/**
 * Command-line interface to the ATLAS transformation engine.
 * 
 * @author Dennis Wagelaar
 */
public class Main implements Runnable {
    public static final String USAGE = "Usage: <this program> " + "[ --f "
            + "--trans <transformation url> "
            + "[--src <id>=<model> <id>=<metamodel>] "
            + "[--tgt <id>=<model> <id>=<metamodel>] "
            + "[--lib <id>=<library url>] ] | \n\t" + "[ --b "
            + "--trans <transformation url> "
            + "[--src <id>=<model> <id>=<metamodel>] "
            + "[--tgt <id>=<model> <id>=<metamodel>] "
            + "[--outSrc <id>=<model> ] " + "[--lib <id>=<library url>]"
            + "[--checkif] ]" + "\n\t[ --s " + "--trans <transformation url> "
            + "[--src <id>=<model> <id>=<metamodel>] "
            + "[--tgt <id>=<model> <id>=<metamodel>] "
            + "[--modifiedSrc <id>=<model>] " + "[--outSrc <id>=<model> ] "
            + "[--outTgt <id>=<model> ] " + "[--lib <id>=<library url>] "
            + "[--checkif] ]";

    private URL _trans = null;

    private int _argPos = 0;

    private Executor _executor = new Executor();

    private Map<String, URL> _libs = new HashMap<String, URL>();

    private boolean _checkIf = false;

    private Map<String, String> _outSrcPaths = new HashMap<String, String>();

    private Map<String, String> _outTgtPaths = new HashMap<String, String>();

    private List<String> _srcs = new LinkedList<String>();

    private Map<String, String> _modelMetaMap = new HashMap<String, String>();

    private List<String> _tgts = new LinkedList<String>();

    private List<String> _modifiedTgts = new LinkedList<String>();

//    private List<String> _modifiedSrcs = new LinkedList<String>();

    private static enum ExecutionMode {
        Forward, Backward, Synchronize
    }

    ExecutionMode _executionMode;

    /**
     * Logs the given strings, separated by spaces.
     * 
     * @param strings
     */
    private void logStrings(String[] strings) {
        StringBuffer output = new StringBuffer();
        for (int i = 0; i < strings.length; i++) {
            if (i > 0) {
                output.append(' ');
            }
            output.append(strings[i]);
        }
        System.out.println(output.toString());
    }

    public static void main(String[] args) {
        Main main = new Main();
        int argsLeft = main.parseArgs(args);
        if (argsLeft > -1)
            main.run();
        if (argsLeft < 0) {
            System.exit(1);
        } else {
            System.exit(0);
        }
    }

    /**
     * Parses the command line arguments
     * 
     * @param args
     * @return number of arguments left (e.g. if "--next" is used) or -1 if
     *         error
     */
    public int parseArgs(String[] args) {
        if (args.length <= _argPos + 1) {
            System.out.println(USAGE);
            return -1;
        }
        try {
            for (int i = _argPos; i < args.length; i++) {
                if (args[i].equals("--b"))
                    _executionMode = ExecutionMode.Backward;
                else if (args[i].equals("--f"))
                    _executionMode = ExecutionMode.Forward;
                else if (args[i].equals("--s"))
                    _executionMode = ExecutionMode.Synchronize;
                else if (args[i].equals("--trans")) {
                    i++;
                    logStrings(new String[] { args[i - 1], args[i] });
                    if (!args[i].startsWith("file:")) args[i] = "file:" + args[i]; 
                    _trans = new URL(args[i]);
                } else if (args[i].equals("--in") || args[i].equals("--src")) {
                    i++;
                    i++;
                    logStrings(new String[] { args[i - 2], args[i - 1], args[i] });
                    addInputModel(args[i - 1], args[i]);
                } else if (args[i].equals("--out") || args[i].equals("--tgt")) {
                    i++;
                    i++;
                    logStrings(new String[] { args[i - 2], args[i - 1], args[i] });
                    addOutputModel(args[i - 1], args[i]);
                } else if (args[i].equals("--modifiedSrc")) {
                    i++;
                    logStrings(new String[] { args[i - 1], args[i] });
                    addModifiedSrc(args[i]);
                } else if (args[i].equals("--newin")
                        || args[i].equals("--outSrc")) {
                    i++;
                    logStrings(new String[] { args[i - 1], args[i] });
                    addOutSrcPaths(args[i]);
                } else if (args[i].equals("--outTgt")) {
                    i++;
                    logStrings(new String[] { args[i - 1], args[i] });
                    addOutTgtPaths(args[i]);
                } else if (args[i].equals("--lib")) {
                    i++;
                    logStrings(new String[] { args[i - 1], args[i] });
                    addLib(args[i]);
                } else if (args[i].equals("--checkif")) {
                    _checkIf = true;
                } else {
                    System.out.println(USAGE);
                    return -1;
                }
            }
        } catch (Exception e) {
            System.err.println(e.toString());
            e.printStackTrace();
            System.out.println(USAGE);
            return -1;
        }
        return 0;
    }

    private void addOutSrcPaths(String model) {
        StringTokenizer mdl = new StringTokenizer(model, "=");
        String modelid = mdl.nextToken();
        String modelpath = mdl.nextToken();
        _outSrcPaths.put(modelid, modelpath);
    }

    private void addOutTgtPaths(String model) {
        StringTokenizer mdl = new StringTokenizer(model, "=");
        String modelid = mdl.nextToken();
        String modelpath = mdl.nextToken();
        _outTgtPaths.put(modelid, modelpath);
    }

    /**
     * Parses --in arguments and adds them to the internal list
     * 
     * @param model
     * @param metamodel
     * @param repository
     * @throws Exception
     */
    private void addInputModel(String model, String metamodel) throws Exception {
        StringTokenizer mdl = new StringTokenizer(model, "=");
        String modelid = mdl.nextToken();
        String modelpath = mdl.nextToken();
        if (!modelpath.startsWith("file:"))
            modelpath = "file:" + modelpath;
        StringTokenizer metamdl = new StringTokenizer(metamodel, "=");
        String metaid = metamdl.nextToken();
        String metapath = metamdl.nextToken();
        if (!metapath.startsWith("file:"))
            metapath = "file:" + metapath;

        _executor.loadModel(metapath, metaid, "MOF");
        _executor.loadModel(modelpath, modelid, metaid);
        if (_executionMode.equals(ExecutionMode.Synchronize)) {
            _executor.loadModel(modelpath, toOriginalName(modelid), metaid);
        }

        _modelMetaMap.put(modelid, metaid);
        _srcs.add(modelid);
    }

    /**
     * Parses --out arguments and adds them to the internal list
     * 
     * @param model
     * @param metamodel
     * @param repository
     * @throws Exception
     */
    private void addOutputModel(String model, String metamodel) throws Exception {
        StringTokenizer mdl = new StringTokenizer(model, "=");
        String modelid = mdl.nextToken();
        String modelpath = mdl.nextToken();
        StringTokenizer metamdl = new StringTokenizer(metamodel, "=");
        String metaid = metamdl.nextToken();
        String metapath = metamdl.nextToken();
        if (!metapath.startsWith("file:"))
            metapath = "file:" + metapath;

        _executor.loadModel(metapath, metaid, "MOF");
        _executor.createModel(modelid, metaid);

        if (_executionMode.equals(ExecutionMode.Forward)) {
            _outTgtPaths.put(modelid, modelpath);
        } else {
            if (!modelpath.startsWith("file:"))
                modelpath = "file:" + modelpath;
            _executor.loadModel(modelpath, toUpdatedName(modelid), metaid);
            _modifiedTgts.add(toUpdatedName(modelid));
        }
        _modelMetaMap.put(modelid, metaid);
        _tgts.add(modelid);
    }

    private void addModifiedSrc(String model) throws Exception {
        StringTokenizer mdl = new StringTokenizer(model, "=");
        String modelid = mdl.nextToken();
        String modelpath = mdl.nextToken();
        if (!modelpath.startsWith("file:"))
            modelpath = "file:" + modelpath;


        _executor.loadModel(modelpath, toUpdatedName(modelid), _modelMetaMap
                .get(modelid));

//        _modifiedSrcs.add(toUpdatedName(modelid));
    }

    private String toUpdatedName(String modelid) {
        return modelid + "@Modified";
    }

    private String toOriginalName(String modelid) {
        return modelid + "@Original";
    }

    /**
     * Parses --lib arguments and adds them to the internal list
     * 
     * @param lib
     * @throws Exception
     */
    private void addLib(String lib) throws Exception {
        StringTokenizer l = new StringTokenizer(lib, "=");
        String libid = l.nextToken();
        URL liburl = new URL(l.nextToken());
        _libs.put(libid, liburl);
    }

    public void run() {
        try {
            actualRun();
        } catch (ModificationNotAcceptedException e) {
            System.err.println(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void actualRun() throws Exception {
        if (_executionMode.equals(ExecutionMode.Forward)) {
            System.out.println("Starting forward transformation " + _trans);
            _executor.forward(_trans, _libs, prepareTransformingModels());
            _executor.saveModels(_outTgtPaths);
        } else if (_executionMode.equals(ExecutionMode.Backward)) {
            System.out.println("Starting backward transformation " + _trans);
            _executor.forward(_trans, _libs, prepareTransformingModels());
            for (String name : _tgts) {
                _executor.difference(name, toUpdatedName(name));
            }
            _executor.backwardPropagate(_tgts, _checkIf);
            _executor.saveModels(_outSrcPaths);
        } else {
            System.out.println("Starting synchronization " + _trans);
            ArrayList<String> models = prepareTransformingModels();
            _executor.forward(_trans, _libs, models);
            for (String name : _tgts) {
                _executor.difference(name, toUpdatedName(name));
            }
            _executor.backwardPropagate(_tgts, _checkIf);
//            System.out.println("@@@@@@@@@@@@@@@@@" + _executor.getModel(_srcs.get(0)).getElementsByType("Author").size());
            for (String name : _srcs) {
                _executor.difference(toOriginalName(name), toUpdatedName(name));
//                System.out.println("@@@@@@@@@@@@@@@@@" + _executor.getModel(_srcs.get(0)).getElementsByType("Author").size());
                    _executor.merge(name, toOriginalName(name));
            }
//            System.out.println("@@@@@@@@@@@@@@@@@" + _executor.getModel(_srcs.get(0)).getElementsByType("Author").size());
            _executor.saveModels(_outSrcPaths);
//            System.out.println("@@@@@@@@@@@@@@@@@" + _executor.getModel(_srcs.get(0)).getElementsByType("Author").size());
            for (String name : _tgts) {
                _executor.createModel(name, _modelMetaMap.get(name));
            }
            _executor.forward(_trans, _libs, prepareTransformingModels());
            for (String name : _tgts) {
                _executor.supplMerge(name, toUpdatedName(name));
            }
            _executor.saveModels(_outTgtPaths);
        }
    }

    private ArrayList<String> prepareTransformingModels() {
        ArrayList<String> models = new ArrayList<String>();
        models.addAll(_srcs);
        models.addAll(_tgts);
        models.addAll(_modelMetaMap.values());
        models.add("MOF");
        return models;
    }
}