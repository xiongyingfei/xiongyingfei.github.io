/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.Verifier;

import org.atl.eclipse.engine.AtlEMFModelHandler;
import org.atl.eclipse.engine.AtlLauncher;
import org.atl.eclipse.engine.AtlModelHandler;
import org.atl.engine.repositories.emf4atl.ASMEMFModel;
import org.atl.engine.repositories.emf4atl.ModelDifferencer;
import org.atl.engine.repositories.emf4atl.ModelMerger;
import org.atl.engine.repositories.emf4atl.SupplMerger;
import org.atl.engine.repositories.emf4atl.ModelMerger.ConflictingModificationException;
import org.atl.engine.vm.nativelib.ASMModel;
import org.atl.engine.vm.nativelib.ASMModelElement;
import org.eclipse.emf.common.util.URI;

public class Executor {

    private Map<String, ASMModel> _models = new HashMap<String, ASMModel>();

    public void forward(URL trans, Map<String, URL> libs
                                                          , Collection<String>
                                                         models
                                                         ) {
         Map<String, ASMModel> modelMap = new HashMap<String, ASMModel>();
         for (String name : models) {
         modelMap.put(name, _models.get(name));
         }
        AtlLauncher.getDefault().launch(trans, libs, modelMap,
                Collections.EMPTY_MAP);
    }
    
    public ASMModel getModel(String name) {
        return _models.get(name);
    }
    
    

    public void differencing(Collection<String> origModels,
            Collection<String> updatedModels)
            throws ModificationNotAcceptedException {
        Iterator<String> i = origModels.iterator();
        Iterator<String> j = updatedModels.iterator();
        for (; i.hasNext() && j.hasNext();) {
            String origName = i.next();
            String updatedName = j.next();
            difference(origName, updatedName);
        }
    }

    public void difference(String origName, String updatedName)
            throws ModificationNotAcceptedException {
        ASMModel outModel = _models.get(origName);
        ASMModel updated = _models.get(updatedName);
        assert updated != null;
        assert outModel != null;
        try {
            new ModelDifferencer().merge(outModel, updated);
        } catch (ConflictingModificationException e) {
            throw new ModificationNotAcceptedException(e.getMessage());
        }
    }

    public void merge(String base, String updated)
            throws ModificationNotAcceptedException {
        ASMModel baseModel = _models.get(base);
        ASMModel updatedModel = _models.get(updated);
        assert baseModel != null;
        assert updatedModel != null;
        try {
            new ModelMerger().merge(baseModel, updatedModel);
        } catch (ConflictingModificationException e) {
            throw new ModificationNotAcceptedException(e.getMessage());
        }
    }

    public void supplMerge(String base, String updated) throws ModificationNotAcceptedException {
        ASMModel baseModel = _models.get(base);
        ASMModel updatedModel = _models.get(updated);
        assert baseModel != null;
        assert updatedModel != null;
        try {
            new SupplMerger().merge(baseModel, updatedModel);
        } catch (ConflictingModificationException e) {
            throw new ModificationNotAcceptedException(e.getMessage());
        }
    }

    public static class ModificationNotAcceptedException extends Exception {

        /**
         * 
         */
        private static final long serialVersionUID = -6390945125730980289L;

        public ModificationNotAcceptedException() {
            super("The modification of the model is not acceptable!");
        }

        public ModificationNotAcceptedException(String message, Throwable cause) {
            super(message, cause);
        }

        public ModificationNotAcceptedException(String message) {
            super(message);
        }

        public ModificationNotAcceptedException(Throwable cause) {
            super(cause);
        }

    }

    public void backwardPropagate(Collection<String> taggedModels,
            boolean checkIf) throws ModificationNotAcceptedException {
        for (String s : taggedModels) {
            ASMModel outModel = _models.get(s);
            if (!outModel.satisfy()) {
                throw new ModificationNotAcceptedException();
            }
            outModel.putBack();
        }
        if (checkIf) {
            for (Verifier v : Verifier.getAll()) {
                if (!v.verify()) {
                    System.err.println("The conditional values are changed!");
                    throw new ModificationNotAcceptedException();
                }
            }
        }
    }

    public void saveModels(Map<String, String> paths) throws IOException {
        for (Iterator i = paths.keySet().iterator(); i.hasNext();) {
            String mName = (String) i.next();
            saveModel(paths.get(mName), mName);
        }
    }

    public void saveModel(String path, String mName) throws IOException {
        ASMModel currentOutModel = _models.get(mName);
        assert currentOutModel != null;
        currentOutModel.save(URI.createFileURI(path).toString());
        System.out.println("Wrote " + path);
    }

    public ASMModel loadModel(String path, String name, String metaModel)
            throws Exception {
        if (metaModel.equals("MOF") && _models.get("MOF") == null)
            _models.put(metaModel, ASMEMFModel.createMOF());
        assert ASMEMFModel.getMOF() != null;

        URI cwd = URI.createURI("file:/" + new File(".").getAbsolutePath());

        URI absURI = URI.createURI(path).resolve(cwd);

        ASMModel model = _models.get(name);
        if (model != null)
            return model;
        assert _models.get(metaModel) != null;
        model = ASMEMFModel.loadASMEMFModel(name, (ASMEMFModel) _models
                .get(metaModel), absURI);
        _models.put(name, model);
        return model;

    }

    public ASMModel createModel(String name, String metaModel) throws Exception {
//        ASMModel model = _models.get(name);
//        if (model != null)
//            return model;
        ASMModel model = ASMEMFModel.newASMEMFModel(name, (ASMEMFModel) _models
                .get(metaModel));
        _models.put(name, model);
        return model;

    }

}
