/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM.backwardExtensions;

import org.atl.engine.vm.nativelib.ASMOclAny;

public class ConstantPutBack implements PutBack {
    
    private ASMOclAny _original;
    
    public ConstantPutBack(ASMOclAny original) {
        super();
        _original = original;
    }

    public void putBackDeletion() {
        assert false;

    }

    public void putBackModification(ASMOclAny o) {
    }

    public boolean satisfyDeletion() {
        return false;
    }

    public boolean satisfyModification(ASMOclAny o) {
        return _original.equals(o);
    }

    public ASMOclAny reevalute() {
        return _original;
    }

}
