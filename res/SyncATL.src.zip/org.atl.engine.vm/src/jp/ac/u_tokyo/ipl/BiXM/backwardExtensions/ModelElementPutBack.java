/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM.backwardExtensions;


import org.atl.engine.vm.nativelib.ASMOclAny;

public class ModelElementPutBack implements PutBack {

    ModelElementLocation _location;

    public ModelElementPutBack(ModelElementLocation location) {
        super();
        _location = location;
    }

    public void putBackDeletion() {
        _location.deleteSourceElement();
    }

    public void putBackModification(ASMOclAny o) {
    }

    public boolean satisfyDeletion() {
        return true;
    }

    public boolean satisfyModification(ASMOclAny o) {
        return false;
    }

    public ASMOclAny reevalute() {
        return _location.getModelElement();
    }

}
