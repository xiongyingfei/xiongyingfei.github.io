/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM.backwardExtensions;

import org.atl.engine.vm.nativelib.ASMValue;

public abstract class SourceLocation {

    public abstract void replaceSourceValue(ASMValue value);

    public abstract ASMValue getSourceValue();

    public abstract void deleteSourceValue();

    public abstract void insertSourceValue(ASMValue value);

    protected void checkDeletionConflicts(String attributeName,
            String modelElementName) {
        ModTag modTag = getSourceValue().getModTag();
        if (!modTag.equals(ModTag.NON)
                && modTag.equals(ModTag.DELETED)) {
            System.out.println("Conflicting modifications detected! On: "
                    + modelElementName + ":" + attributeName);
        }
    }

    protected void checkReplacementConflicts(ASMValue value,
            String attributeName, String modelElementName) {
        ASMValue sourceValue = getSourceValue();
        if (!sourceValue.getModTag().equals(ModTag.NON)) {
            if (!(sourceValue.getModTag().equals(ModTag.REPLACED) 
                    && sourceValue.equals(value)))
                System.out.println("Conflicting modifications detected! On: "
                        + modelElementName + ":" + attributeName);
        }

    }
}
