/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM.backwardExtensions;

import org.atl.engine.vm.nativelib.ASMOclAny;

public class OneParaConstPutBack<T extends ASMOclAny, Ret extends ASMOclAny>
        extends ConstantPutBack {
    PutBack _putBack;

    Calculator<T, Ret> _calculator;

    public OneParaConstPutBack(ASMOclAny original, T v, Calculator<T, Ret> c) {
        super(original);
        _putBack = v.getPutBack();
        assert _putBack != null: "The putback of the original value is null:" + v;
        _calculator = c;
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ConstantPutBack#reevalute()
     */
    @Override
    public ASMOclAny reevalute() {
        T v = (T) _putBack.reevalute();
        return _calculator.calculate(v);
    }

    public static interface Calculator<T, Ret> {
        Ret calculate(T v);
    }

    public static <T extends ASMOclAny, Ret extends ASMOclAny> Ret createResult(
            Calculator<T, Ret> c, T v) {
        Ret result = c.calculate(v);
        result.setPutBack(new OneParaConstPutBack<T, Ret>(result, v, c));
        return result;
    }

}
