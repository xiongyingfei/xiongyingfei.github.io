/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM.backwardExtensions;

import org.atl.engine.vm.nativelib.ASMOclAny;

public class TwoParaDelOnlyPutBack<T1 extends ASMOclAny, T2 extends ASMOclAny, Ret extends ASMOclAny>
        extends DeletionOnlyPutBack {
    PutBack _putBack1;

    PutBack _putBack2;

    Calculator<T1, T2, Ret> _calculator;

    private TwoParaDelOnlyPutBack(ASMOclAny original, PutBack source, T1 v1,
            T2 v2, Calculator<T1, T2, Ret> c) {
        super(original, source);
        _putBack1 = v1.getPutBack();
        assert _putBack1 != null;
        _putBack2 = v2.getPutBack();
        assert _putBack2 != null;
        _calculator = c;
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ConstantPutBack#reevalute()
     */
    @Override
    public ASMOclAny reevalute() {
        T1 v1 = (T1) _putBack1.reevalute();
        T2 v2 = (T2) _putBack2.reevalute();
        return _calculator.calculate(v1, v2);
    }

    public static interface Calculator<T1, T2, Ret> {
        Ret calculate(T1 v1, T2 v2);
    }

    public static <T1 extends ASMOclAny, T2 extends ASMOclAny, Ret extends ASMOclAny> Ret createResult(
            Calculator<T1, T2, Ret> c, T1 v1, T2 v2) {
        Ret result = c.calculate(v1, v2);
        result.setPutBack(new TwoParaDelOnlyPutBack<T1, T2, Ret>(result, v1
                .getPutBack(), v1, v2, c));
        return result;
    }

}
