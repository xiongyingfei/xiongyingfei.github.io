/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM.backwardExtensions;


import org.atl.engine.vm.nativelib.ASMOclAny;
import org.atl.engine.vm.nativelib.ASMReference;
import org.atl.engine.vm.nativelib.ASMValue;

public class PrimitiveValuePutBack implements PutBack {

    private SourceLocation _sourceLocation;

    public PrimitiveValuePutBack(SourceLocation sourceLocation) {
        super();
        _sourceLocation = sourceLocation;
    }

    public void putBackDeletion() {
        _sourceLocation.deleteSourceValue();
    }

    public void putBackModification(ASMOclAny o) {
        o.setModTag(ModTag.REPLACED);
        o.setPutBack(this);
        _sourceLocation.replaceSourceValue((ASMValue) o);

    }

    public boolean satisfyDeletion() {
        return true;
    }

    public boolean satisfyModification(ASMOclAny o) {
        return true;
    }

    public ASMOclAny reevalute() {
        ASMValue sourceValue = _sourceLocation.getSourceValue();
        return sourceValue;
    }
    
    
    

}
