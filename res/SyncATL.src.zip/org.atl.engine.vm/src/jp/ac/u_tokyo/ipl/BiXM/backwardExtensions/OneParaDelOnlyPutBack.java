/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM.backwardExtensions;

import org.atl.engine.vm.nativelib.ASMOclAny;

public class OneParaDelOnlyPutBack<T extends ASMOclAny, Ret extends ASMOclAny>
        extends DeletionOnlyPutBack {
    PutBack _putBack;

    Calculator<T, Ret> _calculator;

    public OneParaDelOnlyPutBack(ASMOclAny original, PutBack source, T v, Calculator<T, Ret> c) {
        super(original, source);
        _putBack = v.getPutBack();
        assert _putBack != null;
        _calculator = c;
    }

    /*
     * (non-Javadoc)
     * 
     * @see jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ConstantPutBack#reevalute()
     */
    @Override
    public ASMOclAny reevalute() {
        T v = (T) _putBack.reevalute();
        return _calculator.calculate(v);
    }

    public static interface Calculator<T, Ret> {
        Ret calculate(T v);
    }

    public static <T extends ASMOclAny, Ret extends ASMOclAny> Ret createResult(
            Calculator<T, Ret> c, T v) {
        Ret result = c.calculate(v);
        result.setPutBack(new OneParaDelOnlyPutBack<T, Ret>(result, v.getPutBack(), v, c));
        return result;
    }

}
