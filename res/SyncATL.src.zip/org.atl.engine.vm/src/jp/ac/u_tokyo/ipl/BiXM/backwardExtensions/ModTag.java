/*
 * Copyright (c) 2007, Xiong Yingfei, SwiftWing Studio
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM.backwardExtensions;

public enum ModTag {
    NON,
    UNSET,
    REPLACED,
    DELETED,
    INSERTED;
    
    public boolean isDeleted() {
        return this == DELETED;
    }

}
