/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM.backwardExtensions;

import org.atl.engine.vm.nativelib.ASMOclAny;

public class PassivePutBack implements PutBack {

    public void putBackDeletion() {

    }

    public void putBackModification(ASMOclAny o) {

    }

    public boolean satisfyDeletion() {
        return true;
    }

    public boolean satisfyModification(ASMOclAny o) {
        return true;
    }

    public ASMOclAny reevalute() {
        // There is no method which produce boolean from 
        // reference, directly or indirectly. So it is safe
        // to return null here
        return null;
    }

}
