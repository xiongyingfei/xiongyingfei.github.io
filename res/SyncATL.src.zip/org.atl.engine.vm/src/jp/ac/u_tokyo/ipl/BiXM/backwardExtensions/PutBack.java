/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM.backwardExtensions;

import org.atl.engine.vm.nativelib.ASMOclAny;

public interface PutBack {
    
    void putBackDeletion();

    void putBackModification(ASMOclAny o);
    
    boolean satisfyDeletion();
    
    boolean satisfyModification(ASMOclAny o);
    
    ASMOclAny reevalute();

}
