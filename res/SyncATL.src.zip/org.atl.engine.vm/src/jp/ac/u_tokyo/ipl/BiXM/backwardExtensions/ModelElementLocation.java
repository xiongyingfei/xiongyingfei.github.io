/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM.backwardExtensions;

import org.atl.engine.vm.nativelib.ASMModelElement;

public interface ModelElementLocation {
    
    public abstract void deleteSourceElement();
    
    public abstract void insertNewElement();
    
    public abstract ASMModelElement getModelElement();

}
