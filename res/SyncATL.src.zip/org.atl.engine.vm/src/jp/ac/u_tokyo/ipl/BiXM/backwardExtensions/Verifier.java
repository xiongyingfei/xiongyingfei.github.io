/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM.backwardExtensions;

import java.util.Collection;
import java.util.LinkedList;

import org.atl.engine.vm.nativelib.ASMBoolean;

public class Verifier {
    
    private PutBack _p;
    private boolean _expected;
    
    private static Collection<Verifier> _verifiers = new LinkedList<Verifier>();
    
    public Verifier(PutBack p, boolean expected) {
        super();
        assert p != null;
        _p = p;
        _expected = expected;
        _verifiers.add(this);
    }

    public boolean verify() {
        return ((ASMBoolean)_p.reevalute()).getSymbol() == _expected;
    }
    
    public static Collection<Verifier> getAll() {
        return _verifiers;
    }

}
