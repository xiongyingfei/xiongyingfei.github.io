/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM.backwardExtensions;

import org.atl.engine.vm.nativelib.ASMOclAny;

public class ConstantModelElementPutBack implements PutBack {
    
    
    public void putBackDeletion() {
        assert false;

    }

    public void putBackModification(ASMOclAny o) {
        assert false;
    }

    public boolean satisfyDeletion() {
        return false;
    }

    public boolean satisfyModification(ASMOclAny o) {
        return false;
    }

    public ASMOclAny reevalute() {
        return null;
    }

}
