/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM.backwardExtensions;

import org.atl.engine.vm.nativelib.ASMOclAny;

public class DeletionOnlyPutBack extends ConstantPutBack {
    
    private PutBack _source;

    public DeletionOnlyPutBack(ASMOclAny original, PutBack source) {
        super(original);
        _source = source;
    }

    /* (non-Javadoc)
     * @see jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ConstantPutBack#putBackDeletion()
     */
    @Override
    public void putBackDeletion() {
        _source.putBackDeletion();
    }

    /* (non-Javadoc)
     * @see jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ConstantPutBack#satisfyDeletion()
     */
    @Override
    public boolean satisfyDeletion() {
        return _source.satisfyDeletion();
    }
    
    

}
