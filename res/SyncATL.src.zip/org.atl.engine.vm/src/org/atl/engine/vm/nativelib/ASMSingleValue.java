/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.vm.nativelib;


public class ASMSingleValue extends ASMValue {

    public ASMSingleValue(ASMOclType type) {
        super(type);
    }
    
    
}
