package org.atl.engine.vm.nativelib;

import java.util.Collection;

import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModelElementLocation;

import org.atl.engine.vm.StackFrame;

/**
 * An ASMModelElement represents a model element. There is no separate class for
 * special model elements such as metamodel elements. Therefore, some operations
 * of ASMModelElement are only valid for metamodel ASMModelElements.
 * 
 * @author Fr�d�ric Jouault
 */
public abstract class ASMModelElement extends ASMOclType {

    public static class NotMetaModelObjectException extends Exception {

        private static final long serialVersionUID = -8608514809762147201L;

    }

    protected ASMModelElement(ASMModel model, ASMModelElement metaobject) {
        super(metaobject);
        this.model = model;
        this.metaobject = metaobject;
        addSupertype(getOclAnyType());
    }

    public abstract ASMOclAny get(StackFrame frame, String name);

    public void set(StackFrame frame, String name, ASMOclAny value) {
        if (value instanceof ASMOclUndefined)
            return;
        if (name.equals("name") && (value instanceof ASMString))
            this.name = ((ASMString) value).getSymbol();
        // the rest is up to the subclass' implementation
    }

    public String toString() {
        return model.getName() + "!" + name + ":" + getMetaobject().name;
    }

    public void setMetaobject(ASMModelElement metaobject) {
        this.metaobject = metaobject;
    }

    public ASMModelElement getMetaobject() {
        return metaobject;
    }

    public ASMModel getModel() {
        return model;
    }

    public String getName() {
        return model.getName() + "!" + name;
    }

    protected void setName(String name) {
        this.name = name;
    }

    public abstract ASMBoolean conformsTo(ASMOclType other);

    // public ASMModelElement getAcquaintance(String name) {
    // return null;
    // }

    // public abstract ASMModelElement getProperty(String name);

    // public abstract ASMModelElement getPropertyType(String name);

    // public static ASMModelElement lookupElementExtended(StackFrame frame,
    // ASMModelElement self, ASMString name) {
    // return null;
    // }
    //
    // public static ASMModelElement otherEnd(StackFrame frame, ASMModelElement
    // self) {
    // return null;
    // }

    // public ModelElementLocation getSourceLocation() {
    // return _sourceLocation;
    // }

    private ASMModel model;

    private ASMModelElement metaobject;

    private String name;

    // protected ModelElementLocation _sourceLocation;

    public abstract void prepareSave();

    /**
     * This method should only be called after prepareSave()
     */
    public abstract boolean IsContained();

    public abstract boolean isPrimaryAttribute(String primaryAttribute)
            throws NotMetaModelObjectException;

    public abstract Collection<String> getPrimaryAttributeNames()
            throws NotMetaModelObjectException;

    public abstract Collection<String> getAttributeNames()
            throws NotMetaModelObjectException;

    public void putBackReplacement() {
        if (getModTag().equals(ModTag.DELETED)) {
            //getPutBack().putBackDeletion();
            return;
        }
        try {
            for (String attr : getMetaobject().getAttributeNames()) {
                getRaw(null, attr).putBack();
            }
        } catch (NotMetaModelObjectException e) {
            assert false;
            e.printStackTrace();
        }

    }
    
    public void putBackDeletion() {
        if (getModTag().equals(ModTag.DELETED))
            getPutBack().putBackDeletion();
    
    }


    @Override
    public boolean satisfy() {
        if (!super.satisfy()) {
            System.err.println("The modifications on " + this
                    + " is not acceptable");
            return false;
        }

        try {
            for (String attr : getMetaobject().getAttributeNames()) {
                if (!get(null, attr).satisfy()) {
                    System.err.println("The modifications " + get(null, attr)
                            + ":" + get(null, attr).getModTag() + " on " + this + ":" + attr + " is not acceptable");
                    return false;
                }
            }
        } catch (NotMetaModelObjectException e) {
            assert false;
            e.printStackTrace();
        }
        return true;
    }

    public abstract ASMOclAny getRaw(StackFrame frame, String name);

}
