package org.atl.engine.vm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ConstantPutBack;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.DeletionOnlyPutBack;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.PutBack;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.TwoParaConstPutBack;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.Verifier;

import org.atl.engine.vm.nativelib.ASMBoolean;
import org.atl.engine.vm.nativelib.ASMCollection;
import org.atl.engine.vm.nativelib.ASMInteger;
import org.atl.engine.vm.nativelib.ASMModel;
import org.atl.engine.vm.nativelib.ASMModelElement;
import org.atl.engine.vm.nativelib.ASMNativeObject;
import org.atl.engine.vm.nativelib.ASMOclAny;
import org.atl.engine.vm.nativelib.ASMOclType;
import org.atl.engine.vm.nativelib.ASMReal;
import org.atl.engine.vm.nativelib.ASMReference;
import org.atl.engine.vm.nativelib.ASMSingleValue;
import org.atl.engine.vm.nativelib.ASMString;
import org.atl.engine.vm.nativelib.ASMValue;

/**
 * The line number table contains a list of IDs
 * (startLine:startColumn-endLine:endColumn) of source elements associated to a
 * range of asm instructions. This list is depth first (first the condition is
 * found, then the if). However, it is entered root first... so it is a LIFO. To
 * find the source element (and its location, IDs being positions) associated to
 * an asm instruction, we just have to find the first range matching the
 * instruction.
 * 
 * @author Fr�d�ric Jouault
 */
public class ASMOperation extends Operation {

    public ASMOperation(ASM asm, String name) {
        this.name = name;
        this.asm = asm;
    }

    public String getName() {
        return name;
    }

    public void setContext(String context) {
        this.context = context;
    }

    public String getContextSignature() {
        return context;
    }

    public void addParameter(ASMParameter parameter) {
        parameters.add(parameter);
    }

    public List getParameters() {
        return parameters;
    }

    public void addInstruction(ASMInstruction instruction) {
        instructions.add(instruction);
    }

    public void addLabeledInstruction(ASMInstructionWithOperand instruction,
            String labelName) {
        instructions.add(instruction);
        Label label = (Label) labels.get(labelName);

        if (label == null) {
            label = new Label(labelName);
            labels.put(labelName, label);
        }

        int index = label.getIndex();
        if (index != -1) {
            instruction.setOperand("" + index);
        } else {
            label.addInstruction(instruction);
        }
    }

    public List getInstructions() {
        return instructions;
    }

    public void addLabel(String labelName) {
        Label label = (Label) labels.get(labelName);

        if (label == null) {
            label = new Label(labelName);
            labels.put(labelName, label);
        }

        label.setIndex(instructions.size());
    }

    public void addVariableInstruction(ASMInstructionWithOperand instruction,
            String varId) {
        LocalVariableEntry lve = (LocalVariableEntry) localVariableEntries
                .get(varId);
        if (lve == null) {
            System.out.println("ERROR: no slot reserved for variable: " + varId
                    + " used at " + lastLNE + ".");
        }
        instruction.setOperand("" + lve.slot);
        instructions.add(instruction);
    }

    private class Label {

        public Label(String name) {
            this.name = name;
        }

        public int getIndex() {
            return index;
        }

        public void addInstruction(ASMInstruction i) {
            instr.add(i);
        }

        public void setIndex(int index) {
            this.index = index;
            String id = "" + index;
            for (Iterator i = instr.iterator(); i.hasNext();) {
                ((ASMInstructionWithOperand) i.next()).setOperand(id);
            }
        }

        public String getName() {
            return name;
        }

        private String name;

        private int index = -1;

        private ArrayList instr = new ArrayList();
    }

    public String getSignature() {
        return "<TODO>";
    }

    public String toString() {
        StringBuffer ret = new StringBuffer(context);

        ret.append(".");
        ret.append(name);
        ret.append("(");
        for (Iterator i = parameters.iterator(); i.hasNext();) {
            ret.append(i.next());
            if (i.hasNext())
                ret.append(", ");
        }
        ret.append(") : ??");

        return ret.toString();
    }

    public ASMOclAny exec(StackFrame frame) {
        ASMOclAny ret = null;

        try {
            realExec((ASMStackFrame) frame);
        } catch (Exception e) {
            frame.printStackTrace(e);
        } catch (StackOverflowError soe) {
            frame.printStackTrace("stack overflow");
        }
        ret = frame.leaveFrame();

        return ret;
    }

    public void realExec(ASMStackFrame frame) throws Exception {
        while (frame.hasNextInstruction()) {
            ASMInstruction instr = frame.nextInstruction();
            String mn = instr.getMnemonic();
            ASMString op = null;
            String ops = null;
            if (instr instanceof ASMInstructionWithOperand) {
                ops = ((ASMInstructionWithOperand) instr).getOperand();
                op = new ASMString(ops);
            }

            frame.step();

            if (mn.equals("push")) {
                setConstantProperties(op);
                frame.push(op);
            } else if (mn.equals("pop")) {
                frame.pop();
            } else if (mn.equals("swap")) {
                ASMOclAny o1 = frame.pop();
                ASMOclAny o2 = frame.pop();
                frame.push(o1);
                frame.push(o2);
            } else if (mn.equals("new")) {
                String mname = ((ASMString) frame.pop()).getSymbol();
                String me = ((ASMString) frame.pop()).getSymbol();
                if (mname.equals("#native")) {
                    Class c = ASMNativeObject.getNativeImpl(me);
                    if (c != null) {
                        ASMOclAny oclValue = (ASMOclAny) c.newInstance();
                        if (frame.getExecEnv().getIteratingItems().empty()) {
                            oclValue.setModTag(ModTag.NON);
                            oclValue.setPutBack(new ConstantPutBack(oclValue));
                        } else {
                            oclValue.setModTag(ModTag.NON);
                            PutBack sourcePutBack = frame.getExecEnv()
                                    .getIteratingItems().peek().getPutBack();
                            oclValue.setPutBack(new DeletionOnlyPutBack(
                                    oclValue, sourcePutBack));
                        }
                        assert oclValue.getPutBack() != null;
                        frame.push(oclValue);
                    } else {
                        frame.printStackTrace("ERROR: element " + me
                                + " not found in native");
                    }
                } else {
                    boolean created = false;
                    for (Iterator j = frame.getExecEnv().getModels().values()
                            .iterator(); j.hasNext();) {
                        ASMModel model = (ASMModel) j.next();
                        if (model.getMetamodel().equals(frame.getModel(mname))) {
                            ASMModelElement newModelElement = model
                                    .newModelElement(frame, me);
                            if (frame.getExecEnv().getStack().empty()) {
                                newModelElement.setModTag(ModTag.NON);
                                newModelElement.setPutBack(new ConstantPutBack(
                                        newModelElement));
                            } else {
                                newModelElement.setModTag(ModTag.NON);
                                PutBack sourcePutBack = frame.getExecEnv()
                                        .getIteratingItems().peek()
                                        .getPutBack();
                                newModelElement
                                        .setPutBack(new DeletionOnlyPutBack(
                                                newModelElement, sourcePutBack));
                            }

                            ASMReference reference = new ASMReference(
                                    newModelElement, ModTag.NON);
                            reference
                                    .setPutBack(new ConstantPutBack(reference));
                            frame.push(reference);
                            created = true;
                            break;
                        }
                    }
                    if (!created) {
                        frame.printStackTrace("ERROR: element " + mname + "!" + me + " not founded!");
                    }

                    // for(Iterator j =
                    // frame.getModel(mname).getSubModels().values().iterator()
                    // ; j.hasNext() ; ) {
                    // ASMModel model = (ASMModel)j.next();
                    // if(frame.getModels().containsValue(model) &&
                    // model.isTarget()) {
                    // frame.push(model.newModelElement(frame, me));
                    // break;
                    // }
                    // }
                }
            } else if (mn.equals("call")) {
                int nb = getNbArgs(ops);
                String opName = getOpName(ops);
                ArrayList arguments = new ArrayList();
                for (int j = 0; j < nb; j++)
                    arguments.add(0, frame.pop());
                ASMOclAny o = frame.pop(); // self
                ASMOclAny ret = o.invoke(frame, opName, arguments);

                if (ret != null) {
                    if (ret instanceof ASMSingleValue
                            && ret.getPutBack() == null) {
                        frame.printStackTrace("ERROR: the backward behavior of method " + ops + " has not been implemented!");
                    }

                    frame.push(ret);
                }
            } else if (mn.equals("supercall")) {
                int nb = getNbArgs(ops);
                String opName = getOpName(ops);
                ArrayList arguments = new ArrayList();
                for (int j = 0; j < nb; j++)
                    arguments.add(0, frame.pop());
                ASMOclAny o = frame.pop(); // self
                ASMOclAny ret = o.invoke(frame, opName, arguments,
                        (ASMOclType) contextType.getSupertypes().iterator()
                                .next());

                if (ret != null) {
                    frame.push(ret);
                }
            } else if (mn.equals("store")) {
                frame.popVariable(ops);
            } else if (mn.equals("load")) {
                frame.pushVariable(ops);
            } else if (mn.equals("dup")) {
                frame.push(frame.peek());
            } else if (mn.equals("dup_x1")) {
                ASMOclAny val1 = frame.pop();
                ASMOclAny val2 = frame.pop();
                frame.push(val1);
                frame.push(val2);
                frame.push(val1);
            } else if (mn.equals("findme")) {
                ASMString mname = ((ASMString) frame.pop());
                ASMString name = ((ASMString) frame.pop());
                ASMOclAny result = findObject(frame, mname, name);
                frame.push(result);
            } else if (mn.equals("get")) {
                ASMOclAny val = (frame.pop()).get(frame, ops);
                frame.push(val);
            } else if (mn.equals("set")) {
                ASMOclAny value = frame.pop();
                ASMOclAny o = frame.pop();
                o.set(frame, ops, value);
            } else if (mn.equals("pushi")) {
                ASMInteger ai = new ASMInteger(Integer.parseInt(ops));
                setConstantProperties(ai);
                frame.push(ai);
            } else if (mn.equals("pushd")) {
                ASMReal ar = new ASMReal(Double.parseDouble(ops));
                setConstantProperties(ar);
                frame.push(ar);
            } else if (mn.equals("pusht")) {
                final ASMBoolean boolTrue = new ASMBoolean(true);
                setConstantProperties(boolTrue);
                frame.push(boolTrue);
            } else if (mn.equals("pushf")) {
                final ASMBoolean boolFalse = new ASMBoolean(false);
                setConstantProperties(boolFalse);
                frame.push(boolFalse);
            } else if (mn.equals("enditerate")) {
                frame.getExecEnv().getIteratingItems().pop();
                return;
            } else if (mn.equals("if")) {
                ASMBoolean condition = ((ASMBoolean) frame.pop());
                new Verifier(condition.getPutBack(), condition.getSymbol());
                if (condition.getSymbol()) {
                    int target = Integer.parseInt(ops);
                    frame.setLocation(target - 1);
                }
            } else if (mn.equals("goto")) {
                int target = Integer.parseInt(ops);
                frame.setLocation(target - 1);
            } else if (mn.equals("getasm")) {
                frame.push(((ASMExecEnv) frame.getExecEnv()).getASMModule());
            } else if (mn.equals("iterate")) {
                ASMOclAny v = frame.pop();
                if (!(v instanceof ASMCollection)) {
                    frame.printStackTrace("cannot iterate on non-collection");
                }
                ASMCollection c = (ASMCollection) v; // TODO: iterate <index>
                // (jusqu'ou iterer...)
                // plutot que enditerate
                int oldLocation = frame.getLocation();
                for (Iterator j = c.iterator(); j.hasNext();) {
                    ASMOclAny item = (ASMOclAny) j.next();
                    frame.getExecEnv().getIteratingItems().push(item);
                    frame.push(item);
                    // frame.step();
                    realExec(frame);
                    frame.setLocation(oldLocation);
                }
                int nested = 0;
                do {
                    String mnc = frame.nextInstruction().getMnemonic();
                    if (mnc.equals("enditerate")) {
                        if (nested == 0) {
                            break;
                        }
                        nested--;
                    } else if (mnc.equals("iterate")) {
                        nested++;
                    }
                } while (true);
            } else {
                frame
                        .printStackTrace("ERROR: instruction not implemented yet : "
                                + mn);
            }

        }
    }

    private static class findObjectCalculator implements
            TwoParaConstPutBack.Calculator<ASMString, ASMString, ASMOclAny> {

        StackFrame frame;

        public findObjectCalculator(StackFrame frame) {
            super();
            this.frame = frame;
        }

        public ASMOclAny calculate(ASMString v1, ASMString v2) {
            String mname = v1.getSymbol();
            String name = v2.getSymbol();
            ASMOclAny result = null;
            if (mname.equals("#native")) {
                if (name.equals("String")) {
                    result = ASMString.myType;
                } else if (name.equals("OclAny")) {
                    result = ASMOclAny.myType;
                } else if (name.equals("Integer")) {
                    result = ASMInteger.myType;
                } else if (name.equals("Boolean")) {
                    result = ASMBoolean.myType;
                } else if (name.equals("Real")) {
                    result = ASMReal.myType;
                } else {
                    frame.printStackTrace("ERROR: element " + name
                            + " not found in native");
                }
            } else {
                ASMModel model = frame.getModel(mname);
                if (model == null) {
                    frame.printStackTrace("cannot find model " + mname);
                }
                ASMModelElement ame = model.findModelElement(name);
                if (ame == null) {
                    frame.printStackTrace("cannot find metamodel element "
                            + name + " in model " + mname);
                }
                ASMReference ref = new ASMReference(ame, ModTag.NON);
                result = ref;
            }
            return result;

        }

    }

    private ASMOclAny findObject(StackFrame frame, ASMString asmMName,
            ASMString asmName) {
        return TwoParaConstPutBack.createResult(
                new findObjectCalculator(frame), asmMName, asmName);
    }

    private void setConstantProperties(ASMValue ai) {
        // ai.setModTag(ModTag.Generated);
        ai.setModTag(ModTag.NON);
        ai.setPutBack(new ConstantPutBack(ai));
        // ai.setPutBack(new DoNothingPutBack());
        // ai.setSatisfy(new EqualitySatisfy(ai));
    }

    // BEGIN SIGNATURE TOOLS
    private static int getNbArgs(String s) {
        int ret = 0;

        s = s.replaceFirst("^.*\\(", "");
        while (!s.startsWith(")")) {
            ret++;
            s = removeFirst(s);
        }

        return ret;
    }

    private static String removeFirst(String s) {
        String simple = "^J|I|B|S|D|A|(M|N)[^;]*;|L";

        if (s.startsWith("T")) {
            s = s.substring(1);
            while (!s.startsWith(";")) {
                s = removeFirst(s);
            }
            s = s.substring(1);
        } else if (s.matches("^(Q|G|C|E|O).*")) {
            s = removeFirst(s.substring(1));
        } else {
            s = s.replaceFirst(simple, "");
        }

        return s;
    }

    private static String getOpName(String s) {
        return s.substring(s.indexOf(".") + 1, s.indexOf("("));
    }

    // END SIGNATURE TOOLS

    /** Temporary storage for lineNumberEntries began but not yet ended. */
    private Map lineNumberEntries = new HashMap();

    private String lastLNE = null;

    public void beginLineNumberEntry(String id) {
        lastLNE = id;
        lineNumberEntries.put(id, new LineNumberEntry(id, instructions.size(),
                -1));
    }

    public void endLineNumberEntry(String id) {
        LineNumberEntry lne = (LineNumberEntry) lineNumberEntries.remove(id);
        lne.end = instructions.size() - 1;
        lineNumberTable.add(lne);
    }

    public void addLineNumberEntry(String id, int begin, int end) {
        lineNumberTable.add(new LineNumberEntry(id, begin, end));
    }

    public List getLineNumberTable() {
        return lineNumberTable;
    }

    public String resolveLineNumber(int l) {
        String ret = null;

        for (Iterator i = lineNumberTable.iterator(); i.hasNext()
                && (ret == null);) {
            LineNumberEntry lne = (LineNumberEntry) i.next();
            if ((l >= lne.begin) && (l <= lne.end)) {
                ret = lne.id;
            }
        }

        return ret;
    }

    public class LineNumberEntry {

        public LineNumberEntry(String id, int begin, int end) {
            this.id = id;
            this.begin = begin;
            this.end = end;
        }

        public String id; /* startLine:startColumn-endLine:endColumn */

        public int begin;

        public int end;
    }

    /** Temporary storage for localVariableEntries began but not yet ended. */
    private Map localVariableEntries = new HashMap();

    public int beginLocalVariableEntry(String id, String name) {
        LocalVariableEntry lve = (LocalVariableEntry) localVariableEntries
                .get(id);
        if (lve != null) {
            throw new Error("variable id already in use: " + id);
        }
        int slot = reserveSlot();
        localVariableEntries.put(id, new LocalVariableEntry(slot, name,
                instructions.size(), -1));
        return slot;
    }

    public int endLocalVariableEntry(String id) {
        LocalVariableEntry lve = (LocalVariableEntry) localVariableEntries
                .remove(id);
        if (lve == null) {
            System.out.println("ERROR: variable id not defined: " + id);
        }
        lve.end = instructions.size() - 1;
        localVariableTable.add(lve);
        freeSlot(lve.slot);
        return lve.slot;
    }

    public void addLocalVariableEntry(int slot, String name, int begin, int end) {
        localVariableTable.add(new LocalVariableEntry(slot, name, begin, end));
    }

    public List getLocalVariableTable() {
        return localVariableTable;
    }

    public String resolveVariableName(int slot, int l) {
        String ret = null;

        for (Iterator i = localVariableTable.iterator(); i.hasNext()
                & (ret == null);) {
            LocalVariableEntry lve = (LocalVariableEntry) i.next();

            if ((slot == lve.slot) && (l >= lve.begin) && (l <= lve.end)) {
                ret = lve.name;
            }
        }

        return ret;
    }

    public class LocalVariableEntry {

        public LocalVariableEntry(int slot, String name, int begin, int end) {
            this.slot = slot;
            this.name = name;
            this.begin = begin;
            this.end = end;
        }

        public int slot;

        public String name;

        public int begin;

        public int end;
    }

    public ASM getASM() {
        return asm;
    }

    private int reserveSlot() {
        int ret = -1;

        for (int i = 0; (i < slots.size()) && (ret == -1); i++) {
            if (!((Boolean) slots.get(i)).booleanValue()) {
                ret = i;
                slots.set(ret, new Boolean(true));
            }
        }

        if (ret == -1) {
            ret = slots.size();
            slots.add(new Boolean(true));
        }

        return ret;
    }

    private void freeSlot(int slot) {
        slots.set(slot, new Boolean(false));
    }

    /** List of Boolean true if slot busy. */
    private List slots = new ArrayList();

    private String name;

    private String context;

    private List parameters = new ArrayList();

    private List instructions = new ArrayList();

    private Map labels = new HashMap();

    private List lineNumberTable = new ArrayList();

    private List localVariableTable = new ArrayList();

    private ASM asm;

    private ASMOclType contextType;

    public void setContextType(ASMOclType contextType) {
        this.contextType = contextType;
    }

    public ASMOclType getReturnType() {
        // TODO Auto-generated method stub
        return null;
    }

    public ASMOclType getContextType() {
        return contextType;
    }
}
