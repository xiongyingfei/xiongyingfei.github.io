package org.atl.engine.vm.nativelib;

import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ConstantPutBack;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.PutBack;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.TwoParaConstPutBack;

import org.atl.engine.vm.StackFrame;

/**
 * @author Fr�d�ric Jouault
 */
public class ASMBoolean extends ASMSingleValue {

    public static ASMOclType myType = new ASMOclSimpleType("Boolean",
            getOclAnyType());

    public ASMBoolean(boolean s) {
        super(myType);
        this.s = s;
    }

    public String toString() {
        return "" + s;
    }

    public boolean getSymbol() {
        return s;
    }

    public int hashCode() {
        return s ? 1 : 0;
    }

    public boolean equals(Object o) {
        return (o instanceof ASMBoolean) && (((ASMBoolean) o).s == s);
    }

    // Native Operations below

    private static class NotPutBack extends ConstantPutBack {
        PutBack _srcPutBack;

        public NotPutBack(ASMOclAny original, PutBack srcPutBack) {
            super(original);
            assert srcPutBack != null;
            _srcPutBack = srcPutBack;
        }

        /*
         * (non-Javadoc)
         * 
         * @see jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ConstantPutBack#reevalute()
         */
        @Override
        public ASMOclAny reevalute() {
            ASMBoolean original = (ASMBoolean) _srcPutBack.reevalute();
            return new ASMBoolean(!original.s);
        }
    }

    public static ASMBoolean not(StackFrame frame, ASMBoolean self) {
        ASMBoolean result = new ASMBoolean(!self.s);
        result.setPutBack(new NotPutBack(result, self.getPutBack()));
        return result;
    }

    private static class AndPutBack
            implements
            TwoParaConstPutBack.Calculator<ASMBoolean, ASMBoolean, ASMBoolean> {

        public ASMBoolean calculate(ASMBoolean v1, ASMBoolean v2) {
            return new ASMBoolean(v1.s && v2.s);
        }
    }

    public static ASMBoolean and(StackFrame frame, ASMBoolean self, ASMBoolean o) {
        return TwoParaConstPutBack.createResult(new AndPutBack(), self, o);
    }

    private static class OrPutBack extends ConstantPutBack {
        PutBack _srcPutBack1;

        PutBack _srcPutBack2;

        public OrPutBack(ASMOclAny original, PutBack srcPutBack1,
                PutBack srcPutBack2) {
            super(original);
            _srcPutBack1 = srcPutBack1;
            _srcPutBack2 = srcPutBack2;
        }

        /*
         * (non-Javadoc)
         * 
         * @see jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ConstantPutBack#reevalute()
         */
        @Override
        public ASMOclAny reevalute() {
            ASMBoolean original1 = (ASMBoolean) _srcPutBack1.reevalute();
            ASMBoolean original2 = (ASMBoolean) _srcPutBack2.reevalute();
            return new ASMBoolean(original1.s || original2.s);
        }
    }

    public static ASMBoolean or(StackFrame frame, ASMBoolean self, ASMBoolean o) {
        ASMBoolean result = new ASMBoolean(self.s || o.s);
        result.setPutBack(new OrPutBack(result, self.getPutBack(), o
                .getPutBack()));
        return result;
    }

    public static ASMBoolean xor(StackFrame frame, ASMBoolean self, ASMBoolean o) {
        return new ASMBoolean(self.s ^ o.s);
    }

    public static ASMBoolean implies(StackFrame frame, ASMBoolean self,
            ASMBoolean o) {
        return new ASMBoolean((!self.s) || (self.s && o.s));
    }

    public static ASMString toString(StackFrame frame, ASMBoolean self) {
        return new ASMString(self.s ? "true" : "false");
    }

    private boolean s;
}
