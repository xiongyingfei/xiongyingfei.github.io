package org.atl.engine.vm.nativelib;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ConstantPutBack;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.OneParaConstPutBack;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.PutBack;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.TwoParaConstPutBack;

import org.atl.engine.vm.ASMExecEnv;
import org.atl.engine.vm.Operation;
import org.atl.engine.vm.StackFrame;

/**
 * @author Fr�d�ric Jouault
 */
public class ASMOclAny extends ASMNativeObject {

    public static ASMOclType myType = getOclAnyType();

    static {
        ASMOclType.myType.addSupertype(getOclAnyType());
    }

    private static ASMOclType oclAnyType = null;

    protected static ASMOclType getOclAnyType() {
        if (oclAnyType == null)
            oclAnyType = new ASMOclSimpleType("OclAny");
        return oclAnyType;
    }

    public ASMOclAny(ASMOclType type) {
        this.type = type;
    }

    public void setType(ASMOclType type) {
        this.type = type;
    }

    public ASMOclType getType() {
        return type;
    }

    public Operation findOperation(StackFrame frame, String opName,
            List arguments) {
        return findOperation(frame, opName, arguments, getType());
    }

    public Operation findOperation(StackFrame frame, String opName,
            List arguments, ASMOclType type) {
        return ((ASMExecEnv) frame.getExecEnv()).getOperation(type, opName);
    }

    // The Operation to execute on this object is searched for in its type.
    public ASMOclAny invoke(StackFrame frame, String opName, List arguments) {
        return invoke(frame, opName, arguments, getType());
    }

    public ASMOclAny invoke(StackFrame frame, String opName, List arguments,
            ASMOclType type) {
        ASMOclAny ret = null;

        Operation oper = findOperation(frame, opName, arguments, type);

        if (oper != null) {
            arguments.add(0, this); // self
            ret = oper.exec(frame.enterFrame(oper, arguments));
        } else {
            frame.printStackTrace("ERROR: could not find operation " + opName
                    + " on " + getType() + " having supertypes: "
                    + getType().getSupertypes());
        }

        return ret;
    }

    public ASMOclAny get(StackFrame frame, String name) {
        if (isHelper(frame, name)) {
            return getHelper(frame, name);
        }
        frame.printStackTrace("ERROR: get unsupported on OclAny.");
        return null;
    }

    public void set(StackFrame frame, String name, ASMOclAny value) {
        frame.printStackTrace("ERROR: set unsupported on OclAny");
    }

    public ASMOclAny refImmediateComposite() {
        return new ASMOclUndefined();
    }

    public boolean isHelper(StackFrame frame, String name) {
        // return type.getHelperAttributes().containsKey(name);
        return ((ASMExecEnv) frame.getExecEnv()).getAttributeInitializer(type,
                name) != null;
    }

    public ASMOclAny getHelper(StackFrame frame, String name) {
        return ((ASMExecEnv) frame.getExecEnv()).getHelperValue(frame, this,
                name);
    }

    // Native Operations below

    /**
     * @return the modTag
     */
    public ModTag getModTag() {
        return _modTag;
    }

    /**
     * @param modTag
     *            the modTag to set
     */
    public void setModTag(ModTag modTag) {
        _modTag = modTag;
    }

    /**
     * @return the putback
     */
    public PutBack getPutBack() {
        return _putback;
    }

    /**
     * @param putback
     *            the putback to set
     */
    public void setPutBack(PutBack putback) {
        _putback = putback;
    }

    private static class IsOclUndefinedCalculator implements
            OneParaConstPutBack.Calculator<ASMOclAny, ASMBoolean> {

        public ASMBoolean calculate(ASMOclAny v) {
            if (v instanceof ASMOclUndefined)
                return new ASMBoolean(true);
            else
                return new ASMBoolean(false);
        }

    }

    public static ASMBoolean oclIsUndefined(StackFrame frame, ASMOclAny self) {
        return OneParaConstPutBack.createResult(new IsOclUndefinedCalculator(),
                self);
    }

    public static ASMString toString(StackFrame frame, ASMOclAny self) {
        return new ASMString(self.toString());
    }

    public static ASMOclAny oclType(StackFrame frame, ASMOclAny self) {
        if (self.type instanceof ASMModelElement) {
            ASMReference result = new ASMReference((ASMModelElement) self.type);
            result.setPutBack(new ConstantPutBack(result));
            return result;
        }
        return self.type;
    }

//    private static class IsKindOfPutBack extends ConstantPutBack {
//
//        private PutBack _objPutBack;
//
//        private PutBack _typePutBack;
//
//        public IsKindOfPutBack(ASMOclAny original, PutBack objPutBack,
//                PutBack typePutBack) {
//            super(original);
//            assert _objPutBack != null;
//            _objPutBack = objPutBack;
//            _typePutBack = typePutBack;
//        }
//
//        /*
//         * (non-Javadoc)
//         * 
//         * @see jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ConstantPutBack#reevalute()
//         */
//        @Override
//        public ASMOclAny reevalute() {
//            return _objPutBack.reevalute().type
//                    .conformsTo((ASMOclType) _typePutBack.reevalute());
//        }
//
//    }
    
    private static class IsKindOfCalculator implements TwoParaConstPutBack.Calculator<ASMOclAny, ASMOclAny, ASMBoolean>{

        public ASMBoolean calculate(ASMOclAny self, ASMOclAny otherType) {
            assert self != null;
            assert otherType != null;
            if (otherType instanceof ASMReference)
                otherType = ((ASMReference) otherType).getModelElement();
            return self.type.conformsTo((ASMOclType) otherType);
        }
        
    }

    public static ASMBoolean oclIsKindOf(StackFrame frame, ASMOclAny self,
            ASMOclAny otherType) {
        return TwoParaConstPutBack.createResult(new IsKindOfCalculator(), self, otherType);
    }

    public static ASMBoolean oclIsTypeOf(StackFrame frame, ASMOclAny self,
            ASMOclAny otherType) {
        if (otherType instanceof ASMReference)
            otherType = ((ASMReference) otherType).getModelElement();
        return new ASMBoolean(self.type.equals(otherType));
    }

    public static ASMOclAny refSetValue(StackFrame frame, ASMOclAny self,
            ASMString name, ASMOclAny value) {
        self.set(frame, name.getSymbol(), value);
        return self;
    }

    public static ASMOclAny refGetValue(StackFrame frame, ASMOclAny self,
            ASMString name) {
        return self.get(frame, name.getSymbol());
    }

    // public static ASMOclAny refImmediateComposite(StackFrame frame, ASMOclAny
    // self) {
    // return self.refImmediateComposite();
    // }

    public static ASMOclAny refInvokeOperation(StackFrame frame,
            ASMOclAny self, ASMString opName_, ASMSequence arguments_) {
        ASMOclAny ret = null;

        String opName = opName_.getSymbol();
        ArrayList arguments = new ArrayList();
        for (Iterator i = arguments_.iterator(); i.hasNext();)
            arguments.add(i.next());

        ret = self.invoke(frame, opName, arguments);

        return ret;
    }

    public static ASMOclAny operatorEQ(StackFrame frame, ASMOclAny self,
            ASMOclAny other) {
        return new ASMBoolean(self.equals(other));
    }

    public static ASMOclAny operatorNE(StackFrame frame, ASMOclAny self,
            ASMOclAny other) {
        return new ASMBoolean(!self.equals(other));
    }

    public static ASMSequence asSequence(StackFrame frame, ASMOclAny self) {
        ASMSequence ret = new ASMSequence();

        ret.add(self);

        return ret;
    }

    public static ASMSet asSet(StackFrame frame, ASMOclAny self) {
        ASMSet ret = new ASMSet();

        ret.add(self);

        return ret;
    }

    public static ASMBag asBag(StackFrame frame, ASMOclAny self) {
        ASMBag ret = new ASMBag();

        ret.add(self);

        return ret;
    }

    public static void output(StackFrame frame, ASMOclAny self) {
        System.out.println(self);
    }

    private PutBack _putback;

    public static ASMOclAny debug(StackFrame frame, ASMOclAny self,
            ASMString msg) {
        System.out.println(msg.getSymbol() + ": " + self.toString());
        return self;
    }

    private ModTag _modTag = ModTag.NON;

    // private Satisfy _satisfy;

    public static ASMOclAny check(StackFrame frame, ASMOclAny self,
            ASMString msg, ASMBoolean cond) {
        if (!cond.getSymbol()) {
            System.out.println(msg.getSymbol());
        }
        return self;
    }

    private ASMOclType type;

    public boolean satisfy() {
        assert _putback != null;
        if (_putback == null)
            return false;
        if (this.getModTag().equals(ModTag.REPLACED))
            return _putback.satisfyModification(this);
        else if (this.getModTag().equals(ModTag.DELETED))
            return _putback.satisfyDeletion();
        else if (this.getModTag().equals(ModTag.NON))
            return true;
        else if (this.getModTag().equals(ModTag.UNSET))
            return true;
        else if (this.getModTag().equals(ModTag.INSERTED)) {
            System.err.println("Insertion detected! May not able to put back!");
            return true;
        }
        return false;
    }

    public void putBack() {
        assert _putback != null;
        if (_putback == null)
            return;
        if (getModTag().equals(ModTag.REPLACED))
            _putback.putBackModification(this);
        else if (this.getModTag().equals(ModTag.DELETED))
            _putback.putBackDeletion();
    }
}
