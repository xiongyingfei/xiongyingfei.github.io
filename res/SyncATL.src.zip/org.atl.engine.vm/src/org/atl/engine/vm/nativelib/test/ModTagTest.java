/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.vm.nativelib.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;

import org.junit.Test;

public class ModTagTest {

    @Test
    public void testIsDeleted() {
        assertTrue(ModTag.DELETED.isDeleted());
        assertFalse(ModTag.INSERTED.isDeleted());
    }

}
