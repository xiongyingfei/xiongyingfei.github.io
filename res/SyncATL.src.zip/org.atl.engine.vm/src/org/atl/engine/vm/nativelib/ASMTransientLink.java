package org.atl.engine.vm.nativelib;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.PutBack;

import org.atl.engine.vm.StackFrame;

/**
 * An ASMTransientLink represents an internal traceability link. Other languages
 * than ATL may be compiled to ATL VM and reuse this class. They can also define
 * their own traceability links using Maps and Tuples.
 * 
 * @author Fr�d�ric Jouault
 */
public class ASMTransientLink extends ASMOclAny {

    public static ASMOclType myType = new ASMOclSimpleType("TransientLink",
            getOclAnyType());

    public ASMTransientLink() {
        super(myType);
    }

    public String toString() {
        StringBuffer ret = new StringBuffer("TransientLink {");

        ret.append("rule = ");
        ret.append(rule);

        ret.append(", sourceElements = {");
        appendMap(sourceElements, ret);
        ret.append("}");

        ret.append(", targetElements = {");
        appendMap(targetElements, ret);
        ret.append("}");

        ret.append(", variables = {");
        appendMap(variables, ret);
        ret.append("}");

        ret.append("}");

        return ret.toString();
    }

    private void appendMap(Map map, StringBuffer ret) {
        for (Iterator i = map.keySet().iterator(); i.hasNext();) {
            Object name = i.next();
            ret.append(name);
            ret.append(" = ");
            ret.append(map.get(name));
            if (i.hasNext())
                ret.append(", ");
        }
    }

    public Map getSourceMap() {
        return sourceElements;
    }

    public Collection getSourceElements() {
        return sourceElements.values();
    }

    public Collection getTargetElements() {
        return targetElements.values();
    }

    private ASMTransientLinkSet _parentSet;

    /**
     * @return the parentSet
     */
    public ASMTransientLinkSet getParentSet() {
        return _parentSet;
    }

    /**
     * @param parentSet
     *            the parentSet to set
     */
    public void setParentSet(ASMTransientLinkSet parentSet) {
        _parentSet = parentSet;
    }

    // Native Operations Below
    public static void setRule(StackFrame frame, ASMTransientLink self,
            ASMOclAny rule) {
        self.rule = rule;
    }

    public static void addSourceElement(StackFrame frame,
            ASMTransientLink self, ASMString name, ASMReference element)
            throws Exception {
        if (self.sourceElements.size() > 0)
            throw new Exception(
                    "Multiple source element added to one transient link");
        self.sourceElements.put(name.getSymbol(), element);
    }

    public static void addTargetElement(StackFrame frame,
            ASMTransientLink self, ASMString name, ASMOclAny element) {
        self.targetElements.put(name.getSymbol(), element);
        self.targetElementsList.add(element);
    }

    public static void addVariable(StackFrame frame, ASMTransientLink self,
            ASMString name, ASMOclAny value) {
        self.variables.put(name.getSymbol(), value);
    }

    public static ASMOclAny getRule(StackFrame frame, ASMTransientLink self) {
        return self.rule;
    }

    public static ASMOclAny getSourceElement(StackFrame frame,
            ASMTransientLink self, ASMString name) {
        return (ASMOclAny) self.sourceElements.get(name.getSymbol());
    }

    public static ASMOclAny getTargetElement(StackFrame frame,
            ASMTransientLink self, ASMString name) {
        return (ASMOclAny) self.targetElements.get(name.getSymbol());
    }

    private static class ReferencePutBack implements PutBack {
        ASMTransientLinkSet _set;

        PutBack _sourcePutBack;

        public void putBackDeletion() {
            _sourcePutBack.putBackDeletion();

        }

        public void putBackModification(ASMOclAny o) {
            ASMReference sourceRef = (ASMReference) _set
                    .getLinkByTargetElement(o).getSourceElements().iterator()
                    .next();

            _sourcePutBack.putBackModification(sourceRef);

        }

        public boolean satisfyDeletion() {
            return _sourcePutBack.satisfyDeletion();
        }

        public boolean satisfyModification(ASMOclAny o) {
            return _sourcePutBack.satisfyModification(o);
        }

        public ReferencePutBack(ASMTransientLinkSet set, PutBack sourcePutBack) {
            super();
            _set = set;
            _sourcePutBack = sourcePutBack;
        }

        public ASMOclAny reevalute() {
            ASMOclAny links = ASMTransientLinkSet.getLinkBySourceElement(null, _set,
                    _sourcePutBack.reevalute());
            if (links instanceof ASMTransientLink)
                return (ASMOclAny)((ASMTransientLink)links).getTargetElements().iterator().next();
            else
                return new ASMOclUndefined(); 
            
        }

    }

    public static ASMOclAny getTargetFromSource(StackFrame frame,
            ASMTransientLink self, ASMOclAny sourceElement) {
        ASMOclAny ret = null;
        // TODO: use mapsTo
        // return (ASMOclAny)self.targetElements.values().iterator().next();

        if (!self.targetElementsList.isEmpty()) {
            ASMReference ref = (ASMReference) self.targetElementsList
                    .iterator().next();
            ret = new ASMReference(ref.getModelElement());
            ret.setPutBack(new ReferencePutBack(self.getParentSet(),
                    sourceElement.getPutBack()));
            // ret.setPutBack(new ReferencePutBack(self.getParentSet(),
            // sourceElement.getPutBack()));
            // ret.setSatisfy(sourceElement.getSatisfy());

        }

        if (ret == null) {
            ret = new ASMOclUndefined();
        }

        return ret;
    }

    public static ASMOclAny getNamedTargetFromSource(StackFrame frame,
            ASMTransientLink self, ASMOclAny sourceElement, ASMString name) {
        return (ASMOclAny) self.targetElements.get(name.getSymbol());
    }

    public static ASMOclAny getVariable(StackFrame frame,
            ASMTransientLink self, ASMString name) {
        return (ASMOclAny) self.variables.get(name.getSymbol());
    }

    private Map sourceElements = new HashMap();

    private Map targetElements = new HashMap();

    private List targetElementsList = new ArrayList();

    private Map variables = new HashMap();

    private ASMOclAny rule;
}
