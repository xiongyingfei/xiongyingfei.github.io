package org.atl.engine.vm.nativelib;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.atl.engine.vm.StackFrame;
import org.atl.engine.vm.StackFrame;

/**
 * An ASMModel represents a model. This is an abstraction layer for concrete
 * model handlers such as EMF or MDR. At the present time, there is no separate
 * class for metamodels. Therefore some of the methods of ASMModel only apply to
 * metamodels. TODO (for this class and ASMModelElement): separate
 * metamodel-specific in ASMMetamodel and rename some methods.
 * 
 * @author Fr�d�ric Jouault
 */
public abstract class ASMModel extends ASMOclAny {

    private static ASMModel mof = null;

    public static ASMModel getMOF() {
        return mof;
    }

    // private ModelLoader ml;

    // public ModelLoader getModelLoader() {
    // return ml;
    // }

    public static ASMOclType myType = new ASMOclSimpleType("Model",
            getOclAnyType());

    public ASMModel(String name, ASMModel metamodel, boolean isTarget) {
        super(myType);
        if (name.equals("MOF"))
            mof = this;
        this.name = name;
        // this.ml = ml;
        if (metamodel == null) {
            assert mof == this;
            this.metamodel = mof;
        } else {
            this.metamodel = metamodel;
        }
        if (metamodel != null && metamodel != mof) {
            Set metaElements = metamodel.getElementsByType("EClass");
            for (Object o : metaElements)
                _uncreatedTypes.add(((ASMModelElement) o).getName());
        }
        // this.metamodel.addSubModel(this);
        // this.isTarget = isTarget;
    }

    public String toString() {
        return name + " : " + metamodel.name;
    }

    public Set getElementsByType(String typeName) {
        return getElementsByType(getMetamodel().findModelElement(typeName));
    }

    public abstract Set getElementsByType(ASMModelElement type);

    public Set getElementsByTypeRaw(String typeName) {
        return getElementsByTypeRaw(getMetamodel().findModelElement(typeName));
    }

    public abstract Set getElementsByTypeRaw(ASMModelElement type);

    /** Finds a Classifier in a Metamodel. */
    public abstract ASMModelElement findModelElement(String name);

    public ASMModelElement newModelElement(String typeName) {
        return newModelElement(null, typeName);
    }

    public ASMModelElement newModelElement(StackFrame frame, String typeName) {
        ASMModelElement type = getMetamodel().findModelElement(typeName);
        if (type == null) {
            String msg = "no type named '" + typeName + "' in metamodel '"
                    + metamodel.name + "'";
            if (frame == null)
                System.out.println(msg);
            else
                frame.printStackTrace(msg);
        }
        return newModelElement(type, true);
    }

    public ASMModelElement newModelElement(ASMModelElement type, Boolean logCreation) {
        if (logCreation) _uncreatedTypes.remove(type.getName());
        return newModelElementImpl(type);
    }

    protected abstract ASMModelElement newModelElementImpl(ASMModelElement type);

    public String getName() {
        return name;
    }

    public ASMModel getMetamodel() {
        return metamodel;
    }

    // public boolean isTarget() {
    // return isTarget;
    // }
    //    
    // public void setIsTarget(boolean isTarget) {
    // this.isTarget = isTarget;
    // }

    public ASMOclAny get(StackFrame frame, String name) {
        System.out.println("ERROR !!!!!");
        return null;
    }

    public void set(StackFrame frame, String name, ASMOclAny value) {
        System.out.println("ERROR !!!!!");
    }

    public abstract void save(String uri) throws IOException;

    public boolean hasTypeCreated(String typeName) {
        return !_uncreatedTypes.contains(typeName);
    }

    private String name;

    private ASMModel metamodel;

    private Set<String> _uncreatedTypes = new HashSet<String>();
    // private Map subModels = new HashMap();
    // private boolean isTarget;

}
