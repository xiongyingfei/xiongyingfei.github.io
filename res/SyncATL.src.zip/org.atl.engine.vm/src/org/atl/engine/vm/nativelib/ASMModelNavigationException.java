package org.atl.engine.vm.nativelib;

public class ASMModelNavigationException extends RuntimeException {

    private static final long serialVersionUID = 4322916794113974411L;

    public ASMModelNavigationException(String message, Throwable cause) {
		super(message, cause);
	}
}
