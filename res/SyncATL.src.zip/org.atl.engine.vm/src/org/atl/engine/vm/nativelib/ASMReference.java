/*
 * Copyright (c) 2007, Xiong Yingfei, SwiftWing Studio
 * All rights reserved.
 */
package org.atl.engine.vm.nativelib;

import java.util.List;

import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.TwoParaConstPutBack;

import org.atl.engine.vm.ASMOperation;
import org.atl.engine.vm.Operation;
import org.atl.engine.vm.StackFrame;

public class ASMReference extends ASMSingleValue{
    
    private ASMModelElement _object;
    
    /**
     * @return the object
     */
    public ASMModelElement getModelElement() {
        return _object;
    }

    /**
     * @param object the object to set
     */
    public void setObject(ASMModelElement object) {
        _object = object;
    }

    public ASMReference(ASMModelElement object) {
        super(object.getMetaobject());
        _object = object;
    }

    public ASMReference(ASMModelElement object, ModTag tag) {
        super(object.getType());
        _object = object;
        setModTag(tag);
    }

//    @Override
//    public ASMOclAny invoke(StackFrame frame, String opName, List arguments) {
//        return _object.invoke(frame, opName, arguments);
//    }
    
    @Override
    public ASMOclAny invoke(StackFrame frame, String opName, List arguments, ASMOclType type) {
        Operation oper = findOperation(frame, opName, arguments, type);
        if (oper != null && 
                getOclAnyType().conformsTo(oper.getContextType()).getSymbol()) {
            return super.invoke(frame, opName, arguments, type);
        }
        
        if (oper instanceof ASMOperation) {
            return super.invoke(frame, opName, arguments, type);
        }

        return _object.invoke(frame, opName, arguments, type);
    }
    
    @Override
    public ASMOclAny get(StackFrame frame, String name) {
        return _object.get(frame, name);
    }
    
    @Override
    public void set(StackFrame frame, String name, ASMOclAny value) {
        _object.set(frame, name, value);
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + ((_object == null) ? 0 : _object.hashCode());
        return result;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final ASMReference other = (ASMReference) obj;
        if (_object == null) {
            if (other._object != null)
                return false;
        } else if (!_object.equals(other._object))
            return false;
        return true;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Ref: " + _object.toString();
    }
    
    
//    private static class IsKindOfCalculator implements TwoParaConstPutBack.Calculator<ASMReference, ASMOclAny, ASMBoolean>{
//
//        public ASMBoolean calculate(ASMReference self, ASMOclAny otherType) {
//            assert self != null;
//            assert otherType != null;
//            if (otherType instanceof ASMReference)
//                otherType = ((ASMReference) otherType).getModelElement();
//            return self._object.getType().conformsTo((ASMOclType) otherType);
//        }
//        
//    }
//
//    public static ASMBoolean oclIsKindOf(StackFrame frame, ASMReference self,
//            ASMOclAny otherType) {
//        System.err.println(self.getPutBack());
//        return TwoParaConstPutBack.createResult(new IsKindOfCalculator(), self, otherType);
//    }
//
    
}
