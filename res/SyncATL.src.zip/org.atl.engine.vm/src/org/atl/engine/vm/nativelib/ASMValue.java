/*
 * Copyright (c) 2007, Xiong Yingfei, SwiftWing Studio
 * All rights reserved.
 */
package org.atl.engine.vm.nativelib;


public abstract class ASMValue extends ASMOclAny{
    
    public ASMValue(ASMOclType type) {
        super(type);
    }
    
}
