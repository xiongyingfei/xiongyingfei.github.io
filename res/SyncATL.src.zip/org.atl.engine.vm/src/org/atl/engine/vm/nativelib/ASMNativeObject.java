package org.atl.engine.vm.nativelib;

import java.util.HashMap;
import java.util.Map;

import org.atl.engine.vm.ASMEmitter;

/**
 * Native Objects that can be created using "new" by VM code.
 * @author Fr�d�ric Jouault
 */
public abstract class ASMNativeObject {

	protected static Map nativeImpl = new HashMap();
	static {
		nativeImpl.put("ASMEmitter", ASMEmitter.class);
		nativeImpl.put("Bag", ASMBag.class);
		nativeImpl.put("EnumLiteral", ASMEnumLiteral.class);
		nativeImpl.put("Map", ASMMap.class);
		nativeImpl.put("OclParametrizedType", ASMOclParametrizedType.class);
		nativeImpl.put("OclSimpleType", ASMOclSimpleType.class);
		nativeImpl.put("OclUndefined", ASMOclUndefined.class);
		nativeImpl.put("OrderedSet", ASMOrderedSet.class);
		nativeImpl.put("Sequence", ASMSequence.class);
		nativeImpl.put("Set", ASMSet.class);
		nativeImpl.put("TransientLink", ASMTransientLink.class);
		nativeImpl.put("TransientLinkSet", ASMTransientLinkSet.class);
		nativeImpl.put("Tuple", ASMTuple.class);
		nativeImpl.put("TupleType", ASMTupleType.class);
	}

	public static Class getNativeImpl(String name) {
		return (Class)nativeImpl.get(name);
	}
}

