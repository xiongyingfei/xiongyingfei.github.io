package org.atl.engine.vm.nativelib;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;

import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.PutBack;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.TwoParaConstPutBack;

import org.atl.engine.vm.StackFrame;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;

/**
 * @author Fr�d�ric Jouault
 */

public class ASMString extends ASMSingleValue {

    public static ASMOclType myType = new ASMOclSimpleType("String",
            getOclAnyType());

    public ASMString(String s) {
        super(myType);
        this.s = s;
    }

    public String toString() {
        return "\'" + s + "\'";
    }

    public String getSymbol() {
        return s;
    }

    public boolean equals(Object o) {
        return (o instanceof ASMString) && (((ASMString) o).s.equals(s));
    }

    public int hashCode() {
        return s.hashCode();
    }

    public String cString() {
        StringBuffer ret = new StringBuffer();

        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\n') {
                ret.append("\\n");
            } else if (c == '\r') {
                ret.append("\\r");
            } else if (c == '\t') {
                ret.append("\\t");
            } else if (c == '\b') {
                ret.append("\\b");
            } else if (c == '\f') {
                ret.append("\\f");
            } else if ((c < ' ') || ((c > '~') && (c < '�'))) {
                ret.append("\\");
                if (c < 010)
                    ret.append("0");
                if (c < 0100)
                    ret.append("0");
                ret.append(java.lang.Integer.toOctalString(c));
            } else if (c == '\'') {
                ret.append("\\'");
            } else if (c == '\"') {
                ret.append("\\\"");
            } else if (c == '\\') {
                ret.append("\\\\");
            } else {
                ret.append(c);
            }
        }

        return "" + ret;
    }

    // Native Operations Below

    // OCL Operations
    public static ASMInteger size(StackFrame frame, ASMString self) {
        return new ASMInteger(self.s.length());
    }

    public static ASMString concat(StackFrame frame, ASMString self, ASMString o) {
        // return new ASMString(self.s + o.s);
        return operatorPlus(frame, self, o);
    }

    public static ASMString substring(StackFrame frame, ASMString self,
            ASMInteger start, ASMInteger end) {
        return new ASMString(self.s.substring(start.getSymbol() - 1, end
                .getSymbol()));
    }

    public static ASMInteger toInteger(StackFrame frame, ASMString self) {
        return new ASMInteger(Integer.parseInt(self.s));
    }

    public static ASMReal toReal(StackFrame frame, ASMString self) {
        return new ASMReal(Double.parseDouble(self.s));
    }

    public static ASMBoolean toBoolean(StackFrame frame, ASMString self)
            throws Exception {
        // return new ASMBoolean(Boolean.parseBoolean(self.s.toLowerCase()));
        String s = self.s.toLowerCase();
        if (s.equals("true") || s.equals("yes"))
            return new ASMBoolean(true);
        else if (s.equals("false") || s.equals("no"))
            return new ASMBoolean(false);
        else
            throw new Exception("Cannot convert to Boolean the String " + self
                    + ", the value is different from true/false or yes/no");
    }

    private static class EQCalculator implements
            TwoParaConstPutBack.Calculator<ASMString, ASMOclAny, ASMBoolean> {

        public ASMBoolean calculate(ASMString v1, ASMOclAny v2) {
            if (v2 instanceof ASMString) {
                return new ASMBoolean(v1.s.equals(((ASMString) v2).s));
            } else {
                return new ASMBoolean(false);
            }
        }

    }

    public static ASMBoolean operatorEQ(StackFrame frame, ASMString self,
            ASMOclAny o) {
        return TwoParaConstPutBack.createResult(new EQCalculator(), self, o);
    }

    public static ASMBoolean operatorNE(StackFrame frame, ASMString self,
            ASMOclAny o) {
        if (o instanceof ASMString) {
            return new ASMBoolean(!self.s.equals(((ASMString) o).s));
        } else {
            return new ASMBoolean(true);
        }
    }

    // Additional Operations

    public static ASMSequence toSequence(StackFrame frame, ASMString self) {
        ASMSequence ret = new ASMSequence();

        for (int i = 0; i < self.s.length(); i++)
            ret.add(new ASMString("" + self.s.charAt(i)));

        return ret;
    }

    private static class LTCalculator implements
            TwoParaConstPutBack.Calculator<ASMString, ASMString, ASMBoolean> {

        public ASMBoolean calculate(ASMString self, ASMString o) {
            return new ASMBoolean(self.s.compareTo(o.s) < 0);
        }

    }

    // Ordering Operations (using lexicographic order)
    public static ASMBoolean operatorLT(StackFrame frame, ASMString self,
            ASMString o) {
        return TwoParaConstPutBack.createResult(new LTCalculator(), self, o);
    }

    private static class LECalculator implements
            TwoParaConstPutBack.Calculator<ASMString, ASMString, ASMBoolean> {

        public ASMBoolean calculate(ASMString self, ASMString o) {
            return new ASMBoolean(self.s.compareTo(o.s) <= 0);
        }

    }

    public static ASMBoolean operatorLE(StackFrame frame, ASMString self,
            ASMString o) {
        return TwoParaConstPutBack.createResult(new LECalculator(), self, o);
    }

    private static class GTCalculator implements
            TwoParaConstPutBack.Calculator<ASMString, ASMString, ASMBoolean> {

        public ASMBoolean calculate(ASMString self, ASMString o) {
            return new ASMBoolean(self.s.compareTo(o.s) > 0);
        }

    }

    public static ASMBoolean operatorGT(StackFrame frame, ASMString self,
            ASMString o) {
        return TwoParaConstPutBack.createResult(new GTCalculator(), self, o);
    }

    private static class GECalculator implements
            TwoParaConstPutBack.Calculator<ASMString, ASMString, ASMBoolean> {

        public ASMBoolean calculate(ASMString self, ASMString o) {
            return new ASMBoolean(self.s.compareTo(o.s) >= 0);
        }

    }

    public static ASMBoolean operatorGE(StackFrame frame, ASMString self,
            ASMString o) {
        return TwoParaConstPutBack.createResult(new GECalculator(), self, o);
    }

    private static class ConcatenatePutBack2 implements PutBack {
        private PutBack _v1;

        private PutBack _v2;

        private Map<String, Boolean> satisfactoryMap = new HashMap<String, Boolean>();

        private Map<String, Integer> separatorMap = new HashMap<String, Integer>();

        public void putBackDeletion() {
            _v1.putBackDeletion();
            _v2.putBackDeletion();

        }

        public void putBackModification(ASMOclAny o) {
            String s = ((ASMString) o).getSymbol();
            if (separatorMap.containsKey(s)) {
                int i = separatorMap.get(s).intValue();
                ASMString substring1 = new ASMString(s.substring(0, i));
                substring1.setModTag(o.getModTag());
                ASMString substring2 = new ASMString(s.substring(i));
                substring2.setModTag(o.getModTag());
                _v1.putBackModification(substring1);
                _v2.putBackModification(substring2);
            } else
                for (int i = 0; i <= s.length(); i++) {
                    ASMString substring1 = new ASMString(s.substring(0, i));
                    substring1.setModTag(o.getModTag());
                    ASMString substring2 = new ASMString(s.substring(i));
                    substring2.setModTag(o.getModTag());
                    if (_v1.satisfyModification(substring1)
                            && _v2.satisfyModification(substring2)) {
                        _v1.putBackModification(substring1);
                        _v2.putBackModification(substring2);
                    }
                }
        }

        public ConcatenatePutBack2(PutBack v1, PutBack v2) {
            super();
            _v1 = v1;
            _v2 = v2;
        }

        public boolean satisfyDeletion() {
            return true;
        }

        public boolean satisfyModification(ASMOclAny o) {
            String s = ((ASMString) o).getSymbol();
            if (satisfactoryMap.containsKey(s))
                return satisfactoryMap.get(s).booleanValue();

            for (int i = 0; i <= s.length(); i++) {
                ASMString substring1 = new ASMString(s.substring(0, i));
                ASMString substring2 = new ASMString(s.substring(i));
                if (_v1.satisfyModification(substring1)
                        && _v2.satisfyModification(substring2)) {
                    satisfactoryMap.put(s, true);
                    separatorMap.put(s, i);
                    return true;
                }
            }
            satisfactoryMap.put(s, false);
            return false;
        }

        public ASMOclAny reevalute() {
            ASMString str1 = (ASMString) _v1.reevalute();
            ASMString str2 = (ASMString) _v2.reevalute();

            return new ASMString(str1.getSymbol() + str2.getSymbol());
        }

    }

    // private static class ConcatenatePutBack implements PutBack {
    // private ASMOclAny _v1;
    //
    // private ASMOclAny _v2;
    //
    // public ConcatenatePutBack(ASMOclAny v1, ASMOclAny v2) {
    // super();
    // _v1 = v1;
    // _v2 = v2;
    // }
    //
    // public void putback(ASMOclAny o) {
    // if (o.getModTag().equals(ModTag.Deleted)) {
    // _v1.setModTag(ModTag.Deleted);
    // _v1.putBack();
    // _v2.setModTag(ModTag.Deleted);
    // _v2.putBack();
    // }
    //
    // if (o.getModTag().equals(ModTag.Modified)) {
    // String s = ((ASMString) o).getSymbol();
    // for (int i = 0; i < s.length(); i++) {
    // ASMString substring1 = new ASMString(s.substring(0, i));
    // substring1.setModTag(ModTag.Modified);
    // ASMString substring2 = new ASMString(s.substring(i));
    // substring2.setModTag(ModTag.Modified);
    // if (_v1.getSatisfy().satisfy(substring1)
    // && _v2.getSatisfy().satisfy(substring2)) {
    // _v1.getPutBack().putback(substring1);
    // _v2.getPutBack().putback(substring2);
    // }
    // }
    // }
    // }
    // }
    //
    // private static class ConcatenateSatisfy implements Satisfy {
    //
    // Satisfy _s1;
    //
    // Satisfy _s2;
    //
    // public ConcatenateSatisfy(Satisfy s1, Satisfy s2) {
    // super();
    // _s1 = s1;
    // _s2 = s2;
    // }
    //
    // public boolean satisfy(ASMOclAny o) {
    // if (!(o instanceof ASMString))
    // return false;
    //
    // if (o.getModTag().equals(ModTag.Modified)) {
    // String s = ((ASMString) o).getSymbol();
    // for (int i = 0; i < s.length(); i++) {
    // ASMString substring1 = new ASMString(s.substring(0, i));
    // substring1.setModTag(ModTag.Modified);
    // ASMString substring2 = new ASMString(s.substring(i));
    // substring2.setModTag(ModTag.Modified);
    // if (_s1.satisfy(substring1) && _s2.satisfy(substring2)) {
    // return true;
    // }
    // }
    // return false;
    // }
    //            
    // return true;
    // }
    //
    // }
    //

    // Misc Operations
    public static ASMString operatorPlus(StackFrame frame, ASMString self,
            ASMString o) {
        ASMString newString = new ASMString(self.s + o.s);
        newString.setPutBack(new ConcatenatePutBack2(self.getPutBack(), o
                .getPutBack()));
        // newString.setPutBack(new ConcatenatePutBack(self, o));
        // newString.setSatisfy(new ConcatenateSatisfy(self.getSatisfy(),
        // o.getSatisfy()));
        return newString;
    }

    public static ASMString toCString(StackFrame frame, ASMString self) {
        return new ASMString(self.cString());
    }

    public static ASMString toUpper(StackFrame frame, ASMString self) {
        return new ASMString(self.s.toUpperCase());
    }

    public static ASMString toLower(StackFrame frame, ASMString self) {
        return new ASMString(self.s.toLowerCase());
    }

    public static ASMString trim(StackFrame frame, ASMString self) {
        return new ASMString(self.s.trim());
    }

    private static class StartsWithCalculator implements
            TwoParaConstPutBack.Calculator<ASMString, ASMString, ASMBoolean> {

        public ASMBoolean calculate(ASMString v1, ASMString v2) {
            return new ASMBoolean(v1.s.startsWith(v2.s));
        }

    }

    public static ASMBoolean startsWith(StackFrame frame, ASMString self,
            ASMString o) {
        return TwoParaConstPutBack.createResult(new StartsWithCalculator(),
                self, o);
    }

    public static ASMBoolean endsWith(StackFrame frame, ASMString self,
            ASMString o) {
        return new ASMBoolean(self.s.endsWith(o.s));
    }

    public static ASMInteger indexOf(StackFrame frame, ASMString self,
            ASMString o) {
        return new ASMInteger(self.s.indexOf(o.s));
    }

    public static ASMInteger lastIndexOf(StackFrame frame, ASMString self,
            ASMString o) {
        return new ASMInteger(self.s.lastIndexOf(o.s));
    }

    public static ASMString regexReplaceAll(StackFrame frame, ASMString self,
            ASMString a, ASMString b) {
        return new ASMString(self.s.replaceAll(a.s, b.s));
    }

    public static ASMSequence split(StackFrame frame, ASMString self,
            ASMString a) {
        ASMSequence ret = new ASMSequence();

        String s[] = self.s.split(a.s);
        for (int i = 0; i < s.length; i++) {
            ret.add(new ASMString(s[i]));
        }

        return ret;
    }

    public static ASMString replaceAll(StackFrame frame, ASMString self,
            ASMString a, ASMString b) {
        return new ASMString(self.s.replace(a.s.charAt(0), b.s.charAt(0)));
    }

    // File output
    public static ASMBoolean writeTo(StackFrame frame, ASMString self,
            ASMString fileName) {
        return writeToWithCharset(frame, self, fileName, null);
    }

    public static ASMBoolean writeToWithCharset(StackFrame frame,
            ASMString self, ASMString fileName, ASMString charset) {
        ASMBoolean ret = new ASMBoolean(false);

        try {
            File file = getFile(fileName.getSymbol());
            if (file.getParentFile() != null)
                file.getParentFile().mkdirs();
            PrintStream out = null;
            if (charset == null) {
                out = new PrintStream(new BufferedOutputStream(
                        new FileOutputStream(file)), true);
            } else {
                out = new PrintStream(new BufferedOutputStream(
                        new FileOutputStream(file)), true, charset.getSymbol());
            }
            out.print(self.s);
            out.close();
            ret = new ASMBoolean(true);
        } catch (IOException ioe) {
            frame.printStackTrace(ioe);
        }

        return ret;
    }

    public static void println(StackFrame frame, ASMString self) {
        System.out.println(self.s);
    }

    // End File output

    public static ASMString toString(StackFrame frame, ASMString self) {
        return self;
    }

    // public static ASMModelElement inject(StackFrame frame, ASMString self,
    // ASMString targetModelName, ASMString kind, ASMString params) {
    // ASMModelElement ret = null;
    //		
    // ASMModel tgt = frame.getExecEnv().getModel(targetModelName.getSymbol());
    // ModelLoader ml = tgt.getModelLoader();
    // ret = ml.inject(tgt, kind.getSymbol(), params.getSymbol(), null, new
    // ByteArrayInputStream(self.s.getBytes()));
    //		
    // return ret;
    // }

    // // Below: ATL Compiler specific operations.
    // public static ASMOclAny evalSOTS(StackFrame frame, ASMString self,
    // ASMTuple args) { // TODO: en asm ou ocl
    // ASMOclAny ret = new ASMOclUndefined();
    // try {
    // ret = new SOTSExpression2(self.s).exec(frame, args);
    // } catch(Exception e) {
    // e.printStackTrace(System.out);
    // }
    // return ret;
    // }
    //
    // public static ASMOclAny evalSOTSBrackets(StackFrame frame, ASMString
    // self, ASMTuple args) { // TODO: en asm ou ocl
    // boolean debug = false;
    // StringBuffer ret = new StringBuffer();
    // Reader in = new StringReader(self.s);
    // int c;
    //
    // if(debug) System.out.println("evalBrackets(\"" + self.s + "\")");
    // try {
    // boolean done = false;
    // do {
    // c = in.read();
    // switch(c) {
    // case -1:
    // done = true;
    // break;
    // case '{':
    // StringBuffer exp = new StringBuffer();
    // while((c = in.read()) != '}') {
    // exp.append((char)c);
    // }
    // if(debug) System.out.println("\tEvaluating : " + exp);
    // ASMOclAny result = new SOTSExpression2(exp.toString()).exec(frame, args);
    // if(debug) System.out.println("\t\t=>" + result);
    // if(result instanceof ASMCollection) {
    // result = (ASMOclAny)((ASMCollection)result).iterator().next();
    // }
    // if(result instanceof ASMString) {
    // ret.append(((ASMString)result).s);
    // } else {
    // ret.append(result.toString());
    // }
    // break;
    // default:
    // ret.append((char)c);
    // break;
    // }
    // } while(!done);
    // } catch(Exception e) {
    // e.printStackTrace(System.out);
    // }
    // if(debug) System.out.println("result = \"" + ret + "\"");
    //
    // return new ASMString(ret.toString());
    // }
    // // End ATL Compiler specific Operations

    private String s;

    /**
     * @param path
     *            The absolute or relative path to a file.
     * @return The file in the workspace, or the file in the filesystem if the
     *         workspace is not available.
     * @author Dennis Wagelaar <dennis.wagelaar@vub.ac.be>
     */
    public static File getFile(String path) {
        try {
            Class rp = Class
                    .forName("org.eclipse.core.resources.ResourcesPlugin");
            Object ws = rp.getMethod("getWorkspace", null).invoke(null, null);
            Object root = ws.getClass().getMethod("getRoot", null).invoke(ws,
                    null);
            Path wspath = new Path(path);
            Object wsfile = root.getClass().getMethod("getFile",
                    new Class[] { IPath.class }).invoke(root,
                    new Object[] { wspath });
            path = wsfile.getClass().getMethod("getLocation", null).invoke(
                    wsfile, null).toString();
        } catch (Throwable e) {
            // fall back to native java.io.File path resolution
        }
        return new File(path);
    }
}
