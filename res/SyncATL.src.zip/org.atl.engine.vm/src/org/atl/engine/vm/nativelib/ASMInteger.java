package org.atl.engine.vm.nativelib;

import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ConstantPutBack;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.PutBack;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.TwoParaConstPutBack;

import org.atl.engine.vm.StackFrame;

/**
 * @author Fr�d�ric Jouault
 */
public class ASMInteger extends ASMNumber {

    public static ASMOclType myType = new ASMOclSimpleType("Integer",
            ASMReal.myType);

    public ASMInteger(int s) {
        super(myType);
        this.s = s;
    }

    public String toString() {
        return "" + s;
    }

    public int getSymbol() {
        return s;
    }

    public double asDouble() {
        return s;
    }

    public boolean equals(Object o) {
        return (o instanceof ASMInteger) && (((ASMInteger) o).s == s);
    }

    public int hashCode() {
        return s;
    }

    // Native Operations below

    public static ASMInteger abs(StackFrame frame, ASMInteger self) {
        return new ASMInteger((self.s < 0) ? -self.s : self.s);
    }

    public static ASMInteger mod(StackFrame frame, ASMInteger self, ASMInteger o) {
        return new ASMInteger(self.s % o.s);
    }

    public static ASMInteger div(StackFrame frame, ASMInteger self, ASMInteger o) {
        return new ASMInteger(self.s / o.s);
    }

    public static ASMInteger max(StackFrame frame, ASMInteger self, ASMInteger o) {
        return new ASMInteger(Math.max(self.s, o.s));
    }

    public static ASMInteger min(StackFrame frame, ASMInteger self, ASMInteger o) {
        return new ASMInteger(Math.max(self.s, o.s));
    }

    /*
     * TODO: operation overloading is not supported yet. public static
     * ASMInteger operatorMinus(StackFrame frame, ASMInteger self) { return new
     * ASMInteger(-self.s); }
     */
    public static ASMNumber operatorMinus(StackFrame frame, ASMInteger self,
            ASMNumber o) {
        if (o instanceof ASMInteger) {
            return new ASMInteger(self.s - ((ASMInteger) o).s);
        }
        return new ASMReal(self.s - o.asDouble());
    }

    private static class IntegerAddingPutBack2 implements PutBack {

        PutBack _src1;

        PutBack _src2;

        int _int1;

        int _int2;

        public IntegerAddingPutBack2(PutBack src1, PutBack src2, int int1,
                int int2) {
            super();
            _src1 = src1;
            _src2 = src2;
            _int1 = int1;
            _int2 = int2;
        }

        public void putBackDeletion() {
            if (_src1.satisfyDeletion())
                _src1.putBackDeletion();
            if (_src2.satisfyDeletion())
                _src2.putBackDeletion();
        }

        public void putBackModification(ASMOclAny o) {
            ASMInteger integer = new ASMInteger(((ASMInteger) o).s - _int2);
            if (_src1.satisfyModification(integer)) {
                _src1.putBackModification(integer);
            }
            integer = new ASMInteger(((ASMInteger) o).s - _int1);
            integer.setModTag(o.getModTag());
            if (_src2.satisfyModification(integer))
                _src2.putBackModification(integer);
        }

        public boolean satisfyDeletion() {
            return _src1.satisfyDeletion() || _src2.satisfyDeletion();
        }

        public boolean satisfyModification(ASMOclAny o) {
            ASMInteger integer = new ASMInteger(((ASMInteger) o).s - _int2);
            if (_src1.satisfyModification(integer))
                return true;
            integer = new ASMInteger(((ASMInteger) o).s - _int1);
            if (_src2.satisfyModification(integer))
                return true;
            return false;
        }

        public ASMOclAny reevalute() {
            return new ASMInteger(((ASMInteger) _src1.reevalute()).getSymbol()
                    + ((ASMInteger) _src2.reevalute()).getSymbol());
        }

    }

    // private static class IntegerAddingPutBack implements PutBack {
    //
    // int generated;
    //
    // ASMInteger other;
    //        
    //        
    //
    // public IntegerAddingPutBack(int generated, ASMInteger other) {
    // super();
    // this.generated = generated;
    // this.other = other;
    // }
    //
    // public void putback(ASMOclAny o) {
    // ASMInteger integer = new ASMInteger(((ASMInteger) o).s - generated);
    // integer.setModTag(o.getModTag());
    // other.getPutBack().putback(o);
    // }
    // }
    //
    // private static class IntegerAddingSatisfy implements Satisfy {
    //
    // int generated;
    //
    // ASMInteger other;
    //        
    // public IntegerAddingSatisfy(int generated, ASMInteger other) {
    // super();
    // this.generated = generated;
    // this.other = other;
    // }
    //
    //
    //
    // public boolean satisfy(ASMOclAny o) {
    // ASMInteger integer = new ASMInteger(((ASMInteger) o).s - generated);
    // integer.setModTag(o.getModTag());
    // return other.getSatisfy().satisfy(o);
    // }
    //
    // }

    public static ASMNumber operatorPlus(StackFrame frame, ASMInteger self,
            ASMNumber o) {
        if (o instanceof ASMInteger) {
            // ASMInteger generated = null;
            // ASMInteger other = null;
            // if (self.getModTag().equals(ModTag.Generated)) {
            // generated = self;
            // other = (ASMInteger) o;
            // } else if (o.getModTag().equals(ModTag.Generated)) {
            // generated = (ASMInteger) o;
            // other = self;
            // }

            ASMInteger ret = new ASMInteger(self.s + ((ASMInteger) o).s);
            // if (generated == null) {
            // frame.printStackTrace("Unsported operation used!");
            // } else if (other.getModTag().equals(ModTag.Generated)) {
            // ret.setModTag(ModTag.Source);
            // // ret.setModTag(ModTag.Generated);
            // ret.setPutBack(new ConstantPutBack());
            // // ret.setSatisfy(new GeneratedModelElementSatisfy());
            // // ret.setPutBack(new DoNothingPutBack());
            // } else {
            // ret.setPutBack(new IntegerAddingPutBack2(generated.s,
            // other.getPutBack()));
            // // ret.setSatisfy(new IntegerAddingSatisfy(generated.s, other));
            // // ret.setPutBack(new IntegerAddingPutBack(generated.s, other));
            // }
            ret.setPutBack(new IntegerAddingPutBack2(self.getPutBack(), o
                    .getPutBack(), self.s, ((ASMInteger) o).s));
            return ret;
        }
        return new ASMReal(self.s + o.asDouble());
    }

    public static ASMNumber operatorMul(StackFrame frame, ASMInteger self,
            ASMNumber o) {
        if (o instanceof ASMInteger) {
            return new ASMInteger(self.s * ((ASMInteger) o).s);
        }
        return new ASMReal(self.s * o.asDouble());
    }

    public static ASMReal operatorDiv(StackFrame frame, ASMInteger self,
            ASMNumber o) {// Second parameter should be ASMReal
        return new ASMReal(self.s / o.asDouble());
    }
    
    private static class EQCalculator implements TwoParaConstPutBack.Calculator<ASMInteger, ASMOclAny, ASMBoolean> {

        public ASMBoolean calculate(ASMInteger self, ASMOclAny o) {
            if (o instanceof ASMInteger) {
                return new ASMBoolean(self.s == ((ASMInteger) o).s);
            } else if (o instanceof ASMNumber) {
                return new ASMBoolean(self.s == ((ASMNumber) o).asDouble());
            } else {
                return new ASMBoolean(false);
            }
        }
        
    }

    public static ASMBoolean operatorEQ(StackFrame frame, ASMInteger self,
            ASMOclAny o) {
        return TwoParaConstPutBack.createResult(new EQCalculator(), self, o);
    }

    
    private static class NECalculator implements TwoParaConstPutBack.Calculator<ASMInteger, ASMOclAny, ASMBoolean> {

        public ASMBoolean calculate(ASMInteger self, ASMOclAny o) {
            if (o instanceof ASMInteger) {
                return new ASMBoolean(self.s != ((ASMInteger) o).s);
            } else if (o instanceof ASMNumber) {
                return new ASMBoolean(self.s != ((ASMNumber) o).asDouble());
            } else {
                return new ASMBoolean(true);
            }
        }
        
    }

    public static ASMBoolean operatorNE(StackFrame frame, ASMInteger self,
            ASMOclAny o) {
        return TwoParaConstPutBack.createResult(new NECalculator(), self, o);
    }

    private static class LTCalculator implements TwoParaConstPutBack.Calculator<ASMInteger, ASMNumber, ASMBoolean> {

        public ASMBoolean calculate(ASMInteger self, ASMNumber o) {
            if (o instanceof ASMInteger) {
                return new ASMBoolean(self.s < ((ASMInteger) o).s);
            }
            return new ASMBoolean(self.s < o.asDouble());
        }
        
    }

    public static ASMBoolean operatorLT(StackFrame frame, ASMInteger self,
            ASMNumber o) {
        return TwoParaConstPutBack.createResult(new LTCalculator(), self, o);
    }

    private static class LECalculator implements TwoParaConstPutBack.Calculator<ASMInteger, ASMNumber, ASMBoolean> {

        public ASMBoolean calculate(ASMInteger self, ASMNumber o) {
            if (o instanceof ASMInteger) {
                return new ASMBoolean(self.s <= ((ASMInteger) o).s);
            }
            return new ASMBoolean(self.s <= o.asDouble());
        }
        
    }

    public static ASMBoolean operatorLE(StackFrame frame, ASMInteger self,
            ASMNumber o) {
        return TwoParaConstPutBack.createResult(new LECalculator(), self, o);
    }

    private static class GTCalculator implements TwoParaConstPutBack.Calculator<ASMInteger, ASMNumber, ASMBoolean> {

        public ASMBoolean calculate(ASMInteger self, ASMNumber o) {
            if (o instanceof ASMInteger) {
                return new ASMBoolean(self.s > ((ASMInteger) o).s);
            }
            return new ASMBoolean(self.s > o.asDouble());
        }
        
    }

    public static ASMBoolean operatorGT(StackFrame frame, ASMInteger self,
            ASMNumber o) {
        return TwoParaConstPutBack.createResult(new GTCalculator(), self, o);
    }

    private static class GECalculator implements TwoParaConstPutBack.Calculator<ASMInteger, ASMNumber, ASMBoolean> {

        public ASMBoolean calculate(ASMInteger self, ASMNumber o) {
            if (o instanceof ASMInteger) {
                return new ASMBoolean(self.s >= ((ASMInteger) o).s);
            }
            return new ASMBoolean(self.s >= o.asDouble());
        }
        
    }

    public static ASMBoolean operatorGE(StackFrame frame, ASMInteger self,
            ASMNumber o) {
        return TwoParaConstPutBack.createResult(new GECalculator(), self, o);
    }
    
    private static class ToStringPutBack implements PutBack {
        
        private ASMInteger _old;
        
        public ToStringPutBack(ASMInteger old) {
            _old = old;
        }

        public void putBackDeletion() {
            _old.getPutBack().putBackDeletion();
            
        }

        public void putBackModification(ASMOclAny o) {
            ASMString str = (ASMString) o;
            ASMInteger i = new ASMInteger(new Integer(str.cString()).intValue());
            _old.getPutBack().putBackModification(i);
        }

        public ASMOclAny reevalute() {
            return new ASMString("" + _old.s);
        }

        public boolean satisfyDeletion() {
            return _old.getPutBack().satisfyDeletion();
        }

        public boolean satisfyModification(ASMOclAny o) {
            if (!(o instanceof ASMString)) return false;
            ASMString str = (ASMString) o;
            ASMInteger i = new ASMInteger(new Integer(str.cString()).intValue());
            return _old.getPutBack().satisfyModification(i);
        }
        
    }

    public static ASMString toString(StackFrame frame, ASMInteger self) {
        ASMString result = new ASMString("" + self.s);
        result.setPutBack(new ToStringPutBack(self));
        return result;
    }

    // additional operations, not in OCL standard library

    public static ASMString toHexString(StackFrame frame, ASMInteger self) {
        return new ASMString(Integer.toHexString(self.s));
    }

    public static ASMString toBinaryString(StackFrame frame, ASMInteger self) {
        return new ASMString(Integer.toBinaryString(self.s));
    }
    private int s;
}
