/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.vm;

public interface StackTracePrinter {

    /* (non-Javadoc)
     * @see org.atl.engine.vm.TracePrinter#printStackTrace()
     */
    /* (non-Javadoc)
     * @see org.atl.engine.vm.TracePrinter#printStackTrace()
     */
    public abstract void printStackTrace();

    /* (non-Javadoc)
     * @see org.atl.engine.vm.TracePrinter#printStackTrace(java.lang.Exception)
     */
    /* (non-Javadoc)
     * @see org.atl.engine.vm.TracePrinter#printStackTrace(java.lang.Exception)
     */
    public abstract void printStackTrace(Exception e);

    /* (non-Javadoc)
     * @see org.atl.engine.vm.TracePrinter#printStackTrace(java.lang.String)
     */
    /* (non-Javadoc)
     * @see org.atl.engine.vm.TracePrinter#printStackTrace(java.lang.String)
     */
    public abstract void printStackTrace(String msg);

    /* (non-Javadoc)
     * @see org.atl.engine.vm.TracePrinter#printStackTrace(java.lang.String, java.lang.Exception)
     */
    /* (non-Javadoc)
     * @see org.atl.engine.vm.TracePrinter#printStackTrace(java.lang.String, java.lang.Exception)
     */
    public abstract void printStackTrace(String msg, Exception e);

}