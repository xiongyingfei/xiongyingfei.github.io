/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl.test;

import static org.atl.engine.repositories.emf4atl.test.ModelHelper.findModelElementByAttribute;
import static org.junit.Assert.assertEquals;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;

import org.atl.engine.repositories.emf4atl.ASMEMFModel;
import org.atl.engine.repositories.emf4atl.ModelDifferencer;
import org.atl.engine.vm.nativelib.ASMModelElement;
import org.eclipse.emf.common.util.URI;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class IdenticalModelDifferencerTest {

    ASMEMFModel baseModel;

    ASMEMFModel updatedModel;

    ASMEMFModel metaModel;

    ModelDifferencer comparator;

    @Before
    public void setUp() throws Exception {
        metaModel = ASMEMFModel.loadASMEMFModel("Families", ASMEMFModel
                .createMOF(), URI.createFileURI("TestData/ClassID.xmi"));
        baseModel = ASMEMFModel.loadASMEMFModel("Source", metaModel, URI
                .createFileURI("TestData/SourceID.classes"));
        updatedModel = ASMEMFModel.loadASMEMFModel("Source", metaModel, URI
                .createFileURI("TestData/SourceID.classes"));
        comparator = new ModelDifferencer();
        comparator.merge(baseModel, updatedModel);
    }

    @After
    public void tearDown() throws Exception {
        metaModel = null;
        baseModel = null;
        updatedModel = null;
        comparator = null;
    }

    @Test
    public void testModelElementNumber() throws Exception {
        assertEquals(5, baseModel.getElementsByType("Attribute").size());
    }
    
}
