/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.atl.engine.vm.nativelib.ASMModelElement;
import org.atl.engine.vm.nativelib.ASMOclAny;
import org.atl.engine.vm.nativelib.ASMReference;
import org.atl.engine.vm.nativelib.ASMSequence;
import org.atl.engine.vm.nativelib.ASMValue;
import org.atl.engine.vm.nativelib.ASMModelElement.NotMetaModelObjectException;

public class ModelElementComparator {

    private class Pair {
        ASMModelElement me1;

        ASMModelElement me2;

        public Pair(ASMModelElement me1, ASMModelElement me2) {
            super();
            this.me1 = me1;
            this.me2 = me2;
        }

        /*
         * (non-Javadoc)
         * 
         * @see java.lang.Object#hashCode()
         */
        @Override
        public int hashCode() {
            final int PRIME = 31;
            int result = 1;
            result = PRIME * result + ((me1 == null) ? 0 : me1.hashCode());
            result = PRIME * result + ((me2 == null) ? 0 : me2.hashCode());
            return result;
        }

        /*
         * (non-Javadoc)
         * 
         * @see java.lang.Object#equals(java.lang.Object)
         */
        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            final Pair other = (Pair) obj;
            if (me1 == null) {
                if (other.me1 != null)
                    return false;
            } else if (!me1.equals(other.me1))
                return false;
            if (me2 == null) {
                if (other.me2 != null)
                    return false;
            } else if (!me2.equals(other.me2))
                return false;
            return true;
        }
    }

    private Set<Pair> _equalSet = new HashSet<Pair>();

    public boolean areCorrespondent(ASMModelElement me1, ASMModelElement me2) {
        Set<Pair> comparingSet = new HashSet<Pair>();
        if (areCorrespondent(me1, me2, comparingSet))
        {
            _equalSet.add(new Pair(me1, me2));
            return true;
        }
        else
            return false;

    }

    private boolean areCorrespondent(ASMModelElement me1, ASMModelElement me2,
            Set<Pair> comparingSet) {
        if (_equalSet.contains(new Pair(me1, me2)))
            return true;

        if (comparingSet.contains(new Pair(me1, me2)))
            return true;
        comparingSet.add(new Pair(me1, me2));

        ASMModelElement meta = me1.getMetaobject();
        if (!meta.equals(me2.getMetaobject()))
            return false;

        try {
            for (Iterator i = meta.getPrimaryAttributeNames().iterator(); i
                    .hasNext();) {
                String attrName = (String) i.next();
                if (!equal(me1.get(null, attrName), me2.get(null, attrName),
                        comparingSet))
                    return false;
            }
        } catch (NotMetaModelObjectException e) {
            assert false;
            e.printStackTrace();
        }
        return true;
    }

    private boolean equal(ASMOclAny v1, ASMOclAny v2, Set<Pair> comparingSet) {

        if (!v1.getClass().equals(v2.getClass()))
            return false;

        if (v1 instanceof ASMSequence) {
            ASMSequence col1 = (ASMSequence) v1;
            ASMSequence col2 = (ASMSequence) v2;
            Iterator i1 = col1.iterator();
            Iterator i2 = col2.iterator();

            for (; i1.hasNext() && i2.hasNext();) {
                if (!equal((ASMValue) i1.next(), (ASMValue) i2.next(),
                        comparingSet))
                    return false;
            }
            return true;

        } else if (v2 instanceof ASMReference) {
            ASMReference r1 = (ASMReference) v1;
            ASMReference r2 = (ASMReference) v2;

            return areCorrespondent(r1.getModelElement(), r2.getModelElement(),
                    comparingSet);

        } else
            return v1.equals(v2);

    }

}
