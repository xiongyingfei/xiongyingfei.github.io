package org.atl.engine.repositories.emf4atl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModelElementLocation;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModelElementPutBack;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.PassivePutBack;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.PrimitiveValuePutBack;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.SourceLocation;

import org.atl.engine.vm.ClassNativeOperation;
import org.atl.engine.vm.StackFrame;
import org.atl.engine.vm.nativelib.ASMBoolean;
import org.atl.engine.vm.nativelib.ASMCollection;
import org.atl.engine.vm.nativelib.ASMEnumLiteral;
import org.atl.engine.vm.nativelib.ASMInteger;
import org.atl.engine.vm.nativelib.ASMModel;
import org.atl.engine.vm.nativelib.ASMModelElement;
import org.atl.engine.vm.nativelib.ASMOclAny;
import org.atl.engine.vm.nativelib.ASMOclType;
import org.atl.engine.vm.nativelib.ASMOclUndefined;
import org.atl.engine.vm.nativelib.ASMReal;
import org.atl.engine.vm.nativelib.ASMReference;
import org.atl.engine.vm.nativelib.ASMSequence;
import org.atl.engine.vm.nativelib.ASMSet;
import org.atl.engine.vm.nativelib.ASMString;
import org.atl.engine.vm.nativelib.ASMValue;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.emf.ecore.EAnnotation;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.xmi.XMIResource;

/**
 * @author Fr�d�ric Jouault
 */
public class ASMEMFModelElement extends ASMModelElement {

    private static final String ANNOTATION_SOURCE = "http:///jp.ac.u_tokyo.ipl.BiXM.AttributeAnnotations";

    // only for metamodels...?
    public ASMBoolean conformsTo(ASMOclType other) {
        boolean ret = false;

        if (other instanceof ASMEMFModelElement) {
            EObject o = ((ASMEMFModelElement) other)._object;
            EObject t = _object;

            if ((o instanceof EClass) && (t instanceof EClass)) {
                try {
                    ret = o.equals(t) || ((EClass) o).isSuperTypeOf((EClass) t);
                } catch (Exception e) {
                    e.printStackTrace(System.out);
                }
            }
        }

        return new ASMBoolean(ret);
    }

    // only for metamodels...?
    // public ASMModelElement getPropertyType(String name) {
    // ASMModelElement ret = null;
    //
    // ASMModelElement p = getProperty(name);
    // if (p != null) {
    // ret = (ASMModelElement) p.get(null, "eType");
    // }
    //
    // return ret;
    // }

    // only for metamodels...?
    // public ASMModelElement getProperty(String name) {
    // ASMModelElement ret = null;
    //
    // EObject t = _object;
    //
    // if (t instanceof EClass) {
    // try {
    // ret = ((ASMEMFModel) getModel())
    // .getASMModelElement(((EClass) t)
    // .getEStructuralFeature(name));
    // } catch (Exception e) {
    // e.printStackTrace(System.out);
    // }
    // }
    //
    // return ret;
    // }

    // public ASMOclAny refImmediateComposite() {
    // ASMOclAny ret = null;
    //
    // EObject ic = _object.eContainer();
    // if (ic == null) {
    // ret = super.refImmediateComposite();
    // } else {
    // ret = ((ASMEMFModel) getModel()).getASMModelElement(ic);
    // }
    //
    // return ret;
    // }

    public ASMOclAny get(StackFrame frame, String name) {
        ASMOclAny ret = null;

        if ((frame != null) && isHelper(frame, name)) {
            ret = getHelper(frame, name);
        } else if ("__xmiID__".equals(name)) {
            String id = ((XMIResource) ((ASMEMFModel) getModel()).getExtent())
                    .getURIFragment(_object);
            ret = emf2ASM(frame, id, name);
        } else {
            ret = _attributeValues.get(name);
            if (ret == null) {
                ret = initialGet(frame, name);
                //_attributeValues.put(name, ret);
            }
            
            if (ret.getModTag().isDeleted()) {
                ret = new ASMOclUndefined();
            }

            if (ret instanceof ASMSequence) {
                ASMSequence seq = (ASMSequence) ret;
                ASMSequence newSeq = new ASMSequence();
                for (int i = 0; i < seq.size(); i++) {
                    if (!seq.at(i).getModTag().isDeleted())
                        newSeq.add(seq.at(i));
                }
                newSeq.setModTag(seq.getModTag());
                newSeq.setPutBack(seq.getPutBack());
                ret = newSeq;
            }
        }
        return ret;
    }

    // return values even if they are marked as deleted
    @Override
    public ASMOclAny getRaw(StackFrame frame, String name) {
        ASMOclAny ret = _attributeValues.get(name);
        if (ret == null) {
            ret = initialGet(frame, name);
            //_attributeValues.put(name, ret);
        }
        if (ret instanceof ASMSequence) {
            ASMSequence seq = (ASMSequence) ret;
            ASMSequence newSeq = new ASMSequence();
            for (int i = 0; i < seq.size(); i++) {
                newSeq.add(seq.at(i));
            }
            newSeq.setModTag(seq.getModTag());
            newSeq.setPutBack(seq.getPutBack());
            ret = newSeq;
        }
        return ret;
    }

    private ASMOclAny initialGet(StackFrame frame, String name) {
        ASMOclAny ret;
        EStructuralFeature sf = _object.eClass().getEStructuralFeature(name);
        if (sf == null) {
            frame.printStackTrace("feature " + name + " does not exist on "
                    + getType());
        }
        ASMValue retValue = emf2ASM(frame, _object.eGet(sf), name);
        AttributeLocation attributeLocation = new AttributeLocation(this, name,
                frame);
        retValue.setPutBack(new PrimitiveValuePutBack(attributeLocation));
        if (_isNewElement) {
            retValue.setModTag(ModTag.UNSET);
        } else
            retValue.setModTag(ModTag.NON);
        ret = retValue;
        _attributeValues.put(name, ret);
        return ret;
    }

    private ASMValue emf2ASM(StackFrame frame, Object value, String attrName) {
        ASMValue ret = null;

        if (value instanceof String) {
            ret = new ASMString((String) value);
        } else if (value instanceof Boolean) {
            ret = new ASMBoolean(((Boolean) value).booleanValue());
        } else if (value instanceof Double) {
            ret = new ASMReal(((Double) value).doubleValue());
        } else if (value instanceof Float) {
            ret = new ASMReal(((Float) value).doubleValue());
        } else if (value instanceof Integer) {
            ret = new ASMInteger(((Integer) value).intValue());
        } else if (value instanceof Long) {
            ret = new ASMInteger(((Long) value).intValue());
        } else if (value instanceof Byte) {
            ret = new ASMInteger(((Byte) value).intValue());
        } else if (value instanceof Short) {
            ret = new ASMInteger(((Short) value).intValue());
        } else if (value instanceof Character) {
            ret = new ASMInteger(((Character) value).charValue());
        } else if (value instanceof Enumerator) {
            ret = new ASMEnumLiteral(((Enumerator) value).getName());
            // Do not support FeatureMap.Entry in this version
            // Because I don't know what it is
            // } else if (value instanceof FeatureMap.Entry) {
            // ret = new ASMTuple();
            // ret.set(frame, "eStructuralFeature", emf2ASM(frame,
            // ((FeatureMap.Entry) value).getEStructuralFeature()));
            // ret.set(frame, "value", emf2ASM(frame, ((FeatureMap.Entry) value)
            // .getValue()));
        } else if (value instanceof EObject) {
            ret = new ASMReference(eObjectToASM(frame, (EObject) value));
        } else if (value == null) {
            ret = new ASMOclUndefined();
        } else if (value instanceof Collection) {
            if (value instanceof List) {
                List emfList = (List) value;
                ASMSequence asmList;
                asmList = new ASMSequence();
                for (int i = 0; i < emfList.size(); i++) {
                    ASMValue item = emf2ASM(frame, emfList.get(i), null);
                    SourceLocation location;
                    if (attrName == null) {
                        location = new InnerSequenceLocation(asmList, i);
                    } else
                        location = new MultipleAttrLocation(frame, this,
                                attrName, i);
                    item.setPutBack(new PrimitiveValuePutBack(location));
                    asmList.add(item);
                }
                ret = asmList;

            } else if (value instanceof Set) {
                // I commented following code off since EMF should always
                // return EList for muliple values
                // ASMSet asmSet;
                // asmSet = new ASMSet();
                // for (Iterator i = ((Collection) value).iterator();
                // i.hasNext();) {
                // ASMValue item = emf2ASM(frame, i.next());
                // DefaultPutBack putback = new DefaultPutBack(new
                // SetLocation(asmSet, item));
                // item.setPutBack(putback);
                // asmSet.add(item);
                //
                // }
                // ret = asmSet;
                frame.printStackTrace("ERROR: cannot convert set value" + value
                        + " : " + value.getClass() + " from EMF.");
            } else {
                frame.printStackTrace("ERROR: cannot convert " + value + " : "
                        + value.getClass() + " from EMF.");
                return ret;
            }

        } else {
            frame.printStackTrace("ERROR: cannot convert " + value + " : "
                    + value.getClass() + " from EMF.");
        }

        return ret;
    }

    /**
     * @author Dennis Wagelaar <dennis.wagelaar@vub.ac.be>
     * @param frame
     *            The ATL VM stackframe
     * @param value
     *            The EMF value to convert
     * @return The corresponding ASMModelElement, taking into account the model
     *         in which the element should reside. Uses this model as a proxy if
     *         no other model contains the given value.
     */
    private ASMModelElement eObjectToASM(StackFrame frame, EObject value) {
        ASMEMFModel model = (ASMEMFModel) getModel();
        Resource valueExtent = value.eResource();
//        if (model.getExtent().equals(valueExtent)) {
//            return model.getASMModelElement(value);
//        } else {
//            Iterator models = frame.getModels().values().iterator();
//            while (models.hasNext()) {
//                Object m = models.next();
//                if ((m instanceof ASMEMFModel) && (!model.equals(m))) {
//                    if (((ASMEMFModel) m).getExtent().equals(valueExtent)) {
//                        return ((ASMEMFModel) m).getASMModelElement(value);
//                    }
//                }
//            }
//        }
        // Use this model as proxy
        return model.getASMModelElement(value);
    }

    // public void setSingle(StackFrame frame, String name, ASMOclAny value) {
    // EStructuralFeature feature = object.eClass()
    // .getEStructuralFeature(name);
    // if (feature.isMany()) {
    // frame.printStackTrace("setSingle called with a multiple attribute " +
    // name);
    // return;
    // }
    //
    // Object val = asm2EMF(frame, value, name, feature);
    // if (val != null) {
    // try {
    // object.eSet(feature, val);
    // checkContainment(feature, val);
    // } catch (Exception e) {
    // frame.printStackTrace("cannot set feature " + getType()
    // + "." + name + " to value " + val, e);
    // }
    // }
    //        
    // }

    // private void updateAttributeOfEObject(String name) {
    // ASMOclAny value = _attributeValues.get(name);
    // if (value == null)
    // return;
    //
    // EStructuralFeature feature = object.eClass()
    // .getEStructuralFeature(name);
    // if (feature.isMany()) {
    // EList l = (EList) object.eGet(feature);
    // ASMCollection asmCollection = (ASMCollection) value;
    //
    // l.clear();
    // for (Iterator i = ((ASMCollection) value).iterator(); i.hasNext();) {
    // ASMOclAny sv = (ASMOclAny) i.next();
    // Object val = asm2EMF(frame, sv, name, feature);
    // try {
    // l.add(val);
    // checkContainment(feature, val);
    // asmCollection.add(sv);
    // } catch (Exception e) {
    // frame.printStackTrace("cannot set feature " + getType()
    // + "." + name + " to value " + val);
    // }
    // }
    //
    // }
    //
    // }

    void directSetSingleValue(String name, ASMOclAny value) {
        initializeAttributeIfNeccessary(null, name);
        EStructuralFeature feature = _object.eClass().getEStructuralFeature(
                name);
        if (feature.isMany()) {
            ASMCollection asmCollection = ((ASMCollection) _attributeValues
                    .get(name));
            asmCollection.add(value);
        } else
            _attributeValues.put(name, value);
    }

    public void set(StackFrame frame, String name, ASMOclAny value) {
        final boolean debug = false;
        // final boolean checkSameModel = !true;

        if (debug)
            System.out.println("Setting: " + this + " : " + getType() + "."
                    + name + " to " + value);
        super.set(frame, name, value);

        EStructuralFeature feature = _object.eClass().getEStructuralFeature(
                name);
        if (feature == null) {
            frame.printStackTrace("feature " + name + " does not exist on "
                    + getType());
        }
        if (!feature.isChangeable()) {
            frame.printStackTrace("feature " + name + " is not changeable");
        }

        initializeAttributeIfNeccessary(frame, name);
        if (feature.isMany()) {

            ASMCollection asmCollection = ((ASMCollection) _attributeValues
                    .get(name));
            if(asmCollection.getModTag().equals(ModTag.UNSET))
                asmCollection.setModTag(ModTag.NON);
            
            if (value instanceof ASMCollection) {
                for (Iterator i = ((ASMCollection) value).iterator(); i
                        .hasNext();) {
                    final ASMOclAny item = (ASMOclAny) i.next();
                    asmCollection.add(item);
                    if (hasOppositeReference(feature))
                        addOppositeReference(frame, (ASMReference) item,
                                (EReference) feature, item.getModTag());
                }
            } else {
                asmCollection.add(value);
            }
        } else {
            if (hasOppositeReference(feature)) {
                EReference refFeature = (EReference) feature;
                removeOppositeReference(frame, _attributeValues.get(name),
                        refFeature);
                _attributeValues.put(name, value);
                addOppositeReference(frame, value, refFeature, value
                        .getModTag());
            } else
                _attributeValues.put(name, value);
        }
    }

    private void initializeAttributeIfNeccessary(StackFrame frame, String name) {
        if (_attributeValues.get(name) == null)
            get(frame, name);
    }

    private void addOppositeReference(StackFrame frame, ASMOclAny target,
            EReference refFeature, ModTag tag) {
        if (target instanceof ASMReference)
            ((ASMEMFModelElement) ((ASMReference) target).getModelElement())
                    .addReference(frame, refFeature.getEOpposite().getName(),
                            this, tag);
    }

    private void removeOppositeReference(StackFrame frame, ASMOclAny target,
            EReference refFeature) {
        if (!(target instanceof ASMReference))
            return; // ASMOclUndefined
        ((ASMEMFModelElement) ((ASMReference) target).getModelElement())
                .removeReference(frame, refFeature.getEOpposite().getName(),
                        this);
    }

    private boolean hasOppositeReference(EStructuralFeature feature) {
        return feature instanceof EReference
                && ((EReference) feature).getEOpposite() != null;
    }

    private void addReference(StackFrame frame, String attrName,
            ASMModelElement me, ModTag tag) {
        initializeAttributeIfNeccessary(frame, attrName);

        ASMReference ref = new ASMReference(me);
        ref.setModTag(tag);
        ref.setPutBack(new PassivePutBack());
        // ref.setModTag(ModTag.Passive);
        // ref.setPutBack(new DoNothingPutBack());
        // ref.setSatisfy(new AlwaysSatisfy());
        EStructuralFeature feature = _object.eClass().getEStructuralFeature(
                attrName);
        if (feature.isMany()) {
            ASMCollection asmCollection = ((ASMCollection) _attributeValues
                    .get(attrName));
            asmCollection.add(ref);
        } else {
            removeOppositeReference(frame, get(frame, attrName),
                    (EReference) feature);
            _attributeValues.put(attrName, ref);
        }
    }

    void removeReference(StackFrame frame, String attrName, ASMModelElement me) {
        ASMReference ref = new ASMReference(me);
        removeReference(frame, attrName, ref);
    }

    private void removeReference(StackFrame frame, String attrName,
            ASMReference ref) {
        initializeAttributeIfNeccessary(frame, attrName);

        EStructuralFeature feature = _object.eClass().getEStructuralFeature(
                attrName);
        if (feature.isMany()) {
            ASMCollection asmCollection = ((ASMCollection) _attributeValues
                    .get(attrName));
            for (Iterator i = asmCollection.iterator(); i.hasNext();) {
                Object next = i.next();
                if (next instanceof ASMOclUndefined) continue;
                ASMReference r = (ASMReference) next;
                if (r.equals(ref)) {
                    r.setModTag(ModTag.DELETED);
                    r.setPutBack(new PassivePutBack());
                    // r.setModTag(ModTag.PassiveDeleted);
                    // r.setPutBack(new DoNothingPutBack());
                    // r.setSatisfy(new AlwaysSatisfy());
                }
            }

        } else {
            ASMOclUndefined undefined = new ASMOclUndefined();
            undefined.setModTag(ModTag.NON);
            undefined.setPutBack(new PassivePutBack());
            // undefined.setModTag(ModTag.Passive);
            // undefined.setPutBack(new DoNothingPutBack());
            // undefined.setSatisfy(new AlwaysSatisfy());
            _attributeValues.put(attrName, undefined);

        }
    }

    // private void checkContainment(EStructuralFeature feature, Object val) {
    // if ((val != null) && (feature instanceof EReference)) {
    // EReference ref = (EReference) feature;
    // if (ref.isContainment()) {
    // ASMEMFModel model = (ASMEMFModel) getModel();
    // /*
    // * TODO add a plugin dependency to an assertion API (e.g.,
    // * org.eclipse.jface.text.Assert in 3.1.2 or
    // * org.eclipse.core.runtime.Assert in 3.2)
    // * Assert.isNotNull(model);
    // */
    // EList toplevelElements = model.getExtent().getContents();
    // // Check if 'val' is a toplevel element
    // // in the content list of the model resource extent.
    // //if (toplevelElements.contains(val)) {
    // // 'val' is about to become a contained element.
    // // therefore, we need to remove it from the list of toplevel
    // // elements
    // if (val instanceof Collection)
    // toplevelElements.removeAll((Collection) val);
    // else
    // toplevelElements.remove(val);
    //                    
    // //}
    // } else if (ref.isContainer()) {
    // ASMEMFModel model = (ASMEMFModel) getModel();
    // /*
    // * TODO add a plugin dependency to an assertion API (e.g.,
    // * org.eclipse.jface.text.Assert in 3.1.2 or
    // * org.eclipse.core.runtime.Assert in 3.2)
    // * Assert.isNotNull(model);
    // */
    // EList toplevelElements = model.getExtent().getContents();
    // // Check if 'val' is a toplevel element
    // // in the content list of the model resource extent.
    // if (toplevelElements.contains(_object)) {
    // // 'val' is about to become a contained element.
    // // therefore, we need to remove it from the list of toplevel
    // // elements
    // toplevelElements.remove(_object);
    // }
    // }
    // }
    // }

    private Object asm2EMF(ASMOclAny value, String propName,
            EStructuralFeature feature) {
        Object ret = null;

        if (value instanceof ASMString) {
            ret = ((ASMString) value).getSymbol();
        } else if (value instanceof ASMBoolean) {
            ret = new Boolean(((ASMBoolean) value).getSymbol());
        } else if (value instanceof ASMReal) {
            ret = new Double(((ASMReal) value).getSymbol());
        } else if (value instanceof ASMInteger) {
            int val = ((ASMInteger) value).getSymbol();
            if (feature != null) {
                String targetType = feature.getEType().getInstanceClassName();
                if (targetType.equals("java.lang.Double")
                        || targetType.equals("java.lang.Float")) {
                    ret = new Double(val);
                } else {
                    ret = new Integer(val);
                }
            } else {
                ret = new Integer(val);
            }
        } else if (value instanceof ASMReference) {
            ret = ((ASMEMFModelElement) ((ASMReference) value)
                    .getModelElement())._object;
        } else if (value instanceof ASMOclUndefined) {
            ret = null;
        } else if (value instanceof ASMEnumLiteral) {
            String name = ((ASMEnumLiteral) value).getName();
            EClassifier type = ((EClass) ((ASMEMFModelElement) getMetaobject())._object)
                    .getEStructuralFeature(propName).getEType();
            ret = ((EEnum) type).getEEnumLiteral(name).getInstance();

            // This is removed because I don't know what it is
            // } else if (value instanceof ASMTuple) {
            // Object f = asm2EMF(frame, ((ASMTuple) value).get(frame,
            // "eStructuralFeature"), propName, feature);
            // if (f instanceof EStructuralFeature) {
            // Object v = asm2EMF(frame, ((ASMTuple) value)
            // .get(frame, "value"), propName, feature);
            // ret = FeatureMapUtil.createEntry((EStructuralFeature) f, v);
            // } else {
            // frame.printStackTrace("ERROR: cannot convert " + value + " : "
            // + value.getClass() + " to EMF.");
            // }
        } else if (value instanceof ASMCollection) {
            ret = new ArrayList(((ASMCollection) value).size());
            for (Iterator i = ((ASMCollection) value).iterator(); i.hasNext();) {
                ASMOclAny asmValue = (ASMOclAny) i.next();
                if (!asmValue.getModTag().isDeleted()) {
                    Object v = asm2EMF(asmValue, propName, feature);
                    if (v != null)
                        ((List) ret).add(v);
                }
            }
        } else {
            System.err.print("ERROR: cannot convert " + value + " : "
                    + value.getClass() + " to EMF.");
        }

        return ret;
    }

    private static ASMModelElement getMetaobject(ASMModel model, EObject object) {
        ASMModelElement ret = null;

        EObject metaobject = object.eClass();
        if (metaobject != object) {
            ret = ((ASMEMFModel) model.getMetamodel())
                    .getASMModelElement(metaobject);
        }

        return ret;
    }

    private static void registerMOFOperation(String modelelementName,
            String methodName, Class args[]) throws Exception {
        List realArgs = new ArrayList(Arrays.asList(args));
        realArgs.add(0, ASMEMFModelElement.class);
        realArgs.add(0, StackFrame.class);
        ClassNativeOperation no = new ClassNativeOperation(
                ASMEMFModelElement.class.getMethod(methodName,
                        (Class[]) realArgs.toArray(args)));
        ASMModelElement amme = ASMEMFModel.getMOF().findModelElement(
                modelelementName);
        amme.registerVMOperation(no);
    }

    static {
        try {
            // Force creation of MOF!EClass before any other (otherwise
            // MOF!Classifier gets created twice)
            ASMEMFModel.getMOF().findModelElement("EClass");

            // Operations on MOF!Classifier
            // TODO on EClassifier after having added supertypes
            registerMOFOperation("EClass", "allInstances", new Class[] {});
            registerMOFOperation("EClass", "allInstancesFrom",
                    new Class[] { ASMString.class });
            registerMOFOperation("EClassifier", "newInstance", new Class[] {});
            registerMOFOperation("EClassifier", "getInstanceById", new Class[] {
                    ASMString.class, ASMString.class });
            // registerMOFOperation("Classifier", "getElementBy", new Class[]
            // {ASMString.class, ASMOclAny.class});
            // registerMOFOperation("Classifier", "getElementsBy", new Class[]
            // {ASMString.class, ASMOclAny.class});

            // Operations on MOF!GeneralizableElement
            // registerMOFOperation("GeneralizableElement",
            // "findElementsByTypeExtended", new Class[]
            // {ASMMDRModelElement.class, ASMBoolean.class});
            // registerMOFOperation("GeneralizableElement",
            // "lookupElementExtended", new Class[] {ASMString.class});

            // Operations on MOF!AssociationEnd
            // registerMOFOperation("AssociationEnd", "otherEnd", new Class[]
            // {});
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
    }

    // For testing purpose
    public static ASMOclAny getInstanceById(StackFrame frame,
            ASMEMFModelElement self, ASMString modelName, ASMString id) {
        ASMOclAny ret = null;

        ASMModel model = (ASMModel) frame.getModels()
                .get(modelName.getSymbol());
        if (model instanceof ASMEMFModel) {
            // TODO: test new version, was:
            // getIDToEObjectMap().get(id.getSymbol());
            EObject eo = (EObject) ((XMIResource) ((ASMEMFModel) model)
                    .getExtent()).getEObject(id.getSymbol());
            if (eo != null)
                ret = ((ASMEMFModel) model).getASMModelElement(eo);
        }

        return (ret == null) ? new ASMOclUndefined() : ret;
    }

    public static ASMSet allInstances(StackFrame frame, ASMEMFModelElement self) {
        return allInstancesFrom(frame, self, null);
    }

    public static ASMSet allInstancesFrom(StackFrame frame,
            ASMEMFModelElement self, ASMString sourceModelName) {
        Set ret = new HashSet();

        // if(self.object.eClass().equals()) {
        for (Iterator i = frame.getModels().keySet().iterator(); i.hasNext();) {
            String mname = (String) i.next();
            if ((sourceModelName != null)
                    && !mname.equals(sourceModelName.getSymbol()))
                continue;

            ASMModel am = (ASMModel) frame.getModels().get(mname);
            if (!am.getMetamodel().equals(self.getModel()))
                continue;

            Set elems = am.getElementsByType(self);
            for (Object modelElement : elems) {
                ASMModelElement me = (ASMModelElement) modelElement;
                ASMReference reference = new ASMReference(me);
                reference.setPutBack(me.getPutBack());
                // reference.setPutBack(new DoNothingPutBack());
                // reference.setSatisfy(new EqualitySatisfy(reference));
                // reference.setPutBack(me.getPutBack());
                // reference.setSatisfy(me.getSatisfy());
                ret.add(reference);
            }
            // ret.addAll(elems);
        }
        // }

        return new ASMSet(ret);
    }

    public static ASMModelElement newInstance(StackFrame frame,
            ASMEMFModelElement self) {
        ASMModelElement ret = null;
        if (self._object.eClass().getName().equals("EClass")) {
            for (Iterator j = frame.getExecEnv().getModels().values()
                    .iterator(); j.hasNext();) {
                ASMModel model = (ASMModel) j.next();
                if (model.getMetamodel().equals(self.getModel())) {
                    ret = model.newModelElement(self, true);
                    break;
                }
            }
        }

        // if(self.object.eClass().getName().equals("EClass")) {
        // for(Iterator i = self.getModel().getSubModels().values().iterator() ;
        // i.hasNext() ; ) {
        // ASMModel am = (ASMModel)i.next();
        // if(am.isTarget()) {
        // ret = am.newModelElement(self);
        // break;
        // }
        // }
        // }

        return ret;
    }

    /**
     * @param model
     * @param metaobject
     */
    protected ASMEMFModelElement(Map modelElements, ASMModel model,
            EObject object) {
        super(model, getMetaobject(model, object));
        this._object = object;

        ModelElementLocation sourceLocation = new EMFModelElementLocation(
                (ASMEMFModel) model, this);
        
//        System.out.println("new object " + object.eClass().getName() + " created!!!!!!!");
//        System.out.println(Thread.currentThread().getStackTrace()[3]);

        setPutBack(new ModelElementPutBack(sourceLocation));

        // setPutBack(new ModelElementLocationPutBack(sourceLocation));
        //
        // setSatisfy(new NoModificationSatisfy());

        // must be done here and not in getASMModelElement because EClass
        // extends EClassifier whose type is EClass
        modelElements.put(object, this);

        EStructuralFeature sfName = object.eClass().getEStructuralFeature(
                "name");
        if (sfName != null) {
            String name = (String) object.eGet(sfName);
            if (name == null) {
                name = "<notnamedyet>";
            }
            setName(name);
        } else {
            setName("<unnamed>");
        }

        if (getMetaobject() == null) {
            setMetaobject(this);
        }
        setType(getMetaobject());

        // Supertypes
        if (object instanceof EClass) {
            addSupertype(ASMOclType.myType);
            EClass cl = (EClass) object;
            for (Iterator i = cl.getESuperTypes().iterator(); i.hasNext();) {
                EClass s = (EClass) i.next();
                addSupertype(((ASMEMFModel) model).getASMModelElement(s));
            }
        }
    }
    
    protected ASMEMFModelElement(Map modelElements, ASMModel model,
            EObject object, boolean isNewElement) {
        this(modelElements, model, object);
        _isNewElement = isNewElement;
    }

    // private Method findMethod(Class cls, String name, Class argumentTypes[])
    // {
    // Method ret = null;
    //
    // Method methods[] = cls.getDeclaredMethods();
    // for (int i = 0; i < (methods.length) && (ret == null); i++) {
    // Method method = methods[i];
    // if (method.getName().equals(name)) {
    // Class pts[] = method.getParameterTypes();
    // if (pts.length == argumentTypes.length) {
    // boolean ok = true;
    // for (int j = 0; (j < pts.length) && ok; j++) {
    // if (!pts[j].isAssignableFrom(argumentTypes[j])) {
    // if (!(pts[j] == boolean.class
    // && argumentTypes[j] == Boolean.class
    // || pts[j] == int.class
    // && argumentTypes[j] == Integer.class
    // || pts[j] == char.class
    // && argumentTypes[j] == Character.class
    // || pts[j] == long.class
    // && argumentTypes[j] == Long.class
    // || pts[j] == float.class
    // && argumentTypes[j] == Float.class || pts[j] == double.class
    // && argumentTypes[j] == Double.class)) {
    // ok = false;
    // }
    // }
    // }
    // if (ok)
    // ret = method;
    // }
    // }
    // }
    //
    // if ((ret == null) && (cls.getSuperclass() != null)) {
    // ret = findMethod(cls.getSuperclass(), name, argumentTypes);
    // }
    //
    // return ret;
    // }

    // public ASMOclAny invoke(StackFrame frame, String opName, List arguments)
    // {
    // ASMOclAny ret = null;
    //
    // if (findOperation(frame, opName, arguments) != null) {
    // ret = super.invoke(frame, opName, arguments);
    // } else {
    // Object args[] = new Object[arguments.size()];
    // Class argumentTypes[] = new Class[arguments.size()];
    // int k = 0;
    // for (Iterator i = arguments.iterator(); i.hasNext();) {
    // // warning: ASMEnumLiterals will not be converted!
    // args[k] = asm2EMF(frame, (ASMOclAny) i.next(), null, null);
    // argumentTypes[k] = args[k].getClass();
    // k++;
    // }
    //
    // Method method = findMethod(_object.getClass(), opName, argumentTypes);
    // try {
    // if (method != null) {
    // ret = emf2ASM(frame, method.invoke(_object, args));
    // } else {
    // frame.printStackTrace("ERROR: could not find operation "
    // + opName + " on " + getType()
    // + " having supertypes: "
    // + getType().getSupertypes()
    // + " (including Java operations)");
    // }
    // } catch (IllegalAccessException e) {
    // frame.printStackTrace("ERROR: could not invoke operation "
    // + opName + " on " + getType() + " having supertypes: "
    // + getType().getSupertypes()
    // + " (including Java operations)");
    // } catch (InvocationTargetException e) {
    // Throwable cause = e.getCause();
    // Exception toReport = (cause instanceof Exception) ? (Exception) cause
    // : e;
    // frame.printStackTrace(
    // "ERROR: exception during invocation of operation "
    // + opName + " on " + getType()
    // + " (java method: " + method + ")", toReport);
    // }
    // }
    //
    // return ret;
    // }


    EObject getEObject() {
        return _object;
    }

    private EObject _object;

    private boolean _isNewElement = false;

    private Map<String, ASMOclAny> _attributeValues = new HashMap<String, ASMOclAny>();

    public void removeItemFromMultiple(String attrName, int index) {
        ASMSequence seq = (ASMSequence) _attributeValues.get(attrName);
        if (seq == null) {
            get(null, attrName);
            seq = (ASMSequence) _attributeValues.get(attrName);
        }
        EStructuralFeature feature = _object.eClass().getEStructuralFeature(
                attrName);
        ASMOclAny val = seq.at(index);
        if (feature instanceof EReference) {
            ASMReference ref = (ASMReference) val;
            if (hasOppositeReference(feature)) {
                removeOppositeReference(null, ref, (EReference) feature);
            }
        }
        val.setModTag(ModTag.DELETED);
    }

    public void replaceItemInMultiple(String attrName, int index, ASMValue v) {
        ASMSequence seq = (ASMSequence) _attributeValues.get(attrName);
        if (seq == null) {
            get(null, attrName);
            seq = (ASMSequence) _attributeValues.get(attrName);
        }
        EStructuralFeature feature = _object.eClass().getEStructuralFeature(
                attrName);
        if (hasOppositeReference(feature)) {
            removeOppositeReference(null, (ASMOclAny) seq.at(index),
                    (EReference) feature);
            seq.replace(index, v);
            addOppositeReference(null, v, (EReference) feature, v.getModTag());
        } else
            seq.replace(index, v);
    }

    public void prepareSave() {
        EList attrList = _object.eClass().getEAllStructuralFeatures();
        for (Iterator i = attrList.iterator(); i.hasNext();) {
            EStructuralFeature attr = (EStructuralFeature) i.next();
            ASMOclAny attrValue = _attributeValues.get(attr.getName());
            if (attrValue != null) {
                Object emfValue = asm2EMF(attrValue, attr.getName(), attr);
                _object.eSet(attr, emfValue);
            }
        }
    }

    @Override
    public boolean IsContained() {
        return _object.eContainer() != null;

    }

    @Override
    public boolean isPrimaryAttribute(String primaryAttribute)
            throws NotMetaModelObjectException {
        if (!(_object instanceof EClass))
            throw new NotMetaModelObjectException();

        EClass eClass = (EClass) _object;
        EAnnotation annotation = eClass.getEStructuralFeature(primaryAttribute)
                .getEAnnotation(ANNOTATION_SOURCE);
        if (annotation == null)
            return false;
        if ("true".equals(annotation.getDetails().get("PrimaryAttribute")))
            return true;
        else
            return false;
    }

    @Override
    public Collection<String> getPrimaryAttributeNames()
            throws NotMetaModelObjectException {
        if (!(_object instanceof EClass))
            throw new NotMetaModelObjectException();

        LinkedList<String> ret = new LinkedList<String>();

        EClass eClass = (EClass) _object;
        Iterator i = eClass.getEAllStructuralFeatures().iterator();
        for (; i.hasNext();) {
            EStructuralFeature attr = (EStructuralFeature) i.next();
            if (isPrimaryAttribute(attr.getName()))
                ret.add(attr.getName());
        }
        return ret;
    }

    public Collection<String> getAttributeNames()
            throws NotMetaModelObjectException {
        if (!(_object instanceof EClass))
            throw new NotMetaModelObjectException();

        LinkedList<String> ret = new LinkedList<String>();

        EClass eClass = (EClass) _object;
        Iterator i = eClass.getEAllStructuralFeatures().iterator();
        for (; i.hasNext();) {
            EStructuralFeature attr = (EStructuralFeature) i.next();
            ret.add(attr.getName());
        }
        return ret;

    }

}
