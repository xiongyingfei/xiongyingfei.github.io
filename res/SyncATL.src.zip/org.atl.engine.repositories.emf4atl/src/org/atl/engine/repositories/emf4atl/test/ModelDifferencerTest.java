/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl.test;

import static org.atl.engine.repositories.emf4atl.test.ModelHelper.findModelElementByAttribute;
import static org.junit.Assert.assertEquals;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;

import org.atl.engine.repositories.emf4atl.ASMEMFModel;
import org.atl.engine.repositories.emf4atl.ModelDifferencer;
import org.atl.engine.vm.nativelib.ASMModelElement;
import org.eclipse.emf.common.util.URI;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ModelDifferencerTest {

    ASMEMFModel baseModel;

    ASMEMFModel updatedModel;

    ASMEMFModel metaModel;

    ModelDifferencer comparator;

    @Before
    public void setUp() throws Exception {
        metaModel = ASMEMFModel.loadASMEMFModel("Families", ASMEMFModel
                .createMOF(), URI.createFileURI("TestData/Class.xmi"));
        baseModel = ASMEMFModel.loadASMEMFModel("Source", metaModel, URI
                .createFileURI("TestData/Source.classes"));
        updatedModel = ASMEMFModel.loadASMEMFModel("Source", metaModel, URI
                .createFileURI("TestData/Source2.classes"));
        comparator = new ModelDifferencer();
        comparator.merge(baseModel, updatedModel);
    }

    @After
    public void tearDown() throws Exception {
        metaModel = null;
        baseModel = null;
        updatedModel = null;
        comparator = null;
    }

    @Test
    public void testDeleteModelElement() throws Exception {
        ASMModelElement me = findModelElementByAttribute(baseModel,
                "Attribute", "name", "closestFriend");
        assert me != null;
        assertEquals(ModTag.DELETED, me.getModTag());
    }
    
//    @Test
//    public void testNoPassiveTag() throws Exception {
//        Set columns = baseModel.getElementsByType("Attribute");
//        for(Object o : columns) {
//            ASMModelElement column = (ASMModelElement) o;
//            ModTag2 modTag = column.get(null, "owner").getModTag();
//            assertTrue(modTag != ModTag.Passive && 
//                    modTag != ModTag.PassiveDeleted);
//        }
//        
//        Set classes = baseModel.getElementsByType("Class");
//        for(Object o : classes) {
//            ASMModelElement aClass = (ASMModelElement) o;
//            for(Object o1 : ((ASMCollection)aClass.get(null, "attr")).collection())
//            {
//                ASMOclAny ref = (ASMOclAny) o1;
//                ModTag modTag = ref.getModTag();
//                assertTrue(modTag != ModTag.Passive && 
//                        modTag != ModTag.PassiveDeleted);
//            }
//        }
//
//        
//    }

    @Test
    public void testInsertModelElement() throws Exception {
        ASMModelElement me = findModelElementByAttribute(baseModel,
                "Attribute", "name", "name1");
        assertEquals(ModTag.INSERTED, me.getModTag());
    }

    @Test
    public void testUnchangedModelElement() throws Exception {
        ASMModelElement me = findModelElementByAttribute(baseModel,
                "Attribute", "name", "firstName");
        assertEquals(ModTag.NON, me.getModTag());
    }
    
    @Test
    public void testUnchangedReference() throws Exception {
        ASMModelElement me = findModelElementByAttribute(baseModel,
                "Attribute", "name", "firstName");
        assertEquals(ModTag.NON, me.get(null, "owner").getModTag());
    }

    
    @Test
    public void testModifiedAttribute() throws Exception {
        ASMModelElement me = findModelElementByAttribute(baseModel,
                "Attribute", "name", "emailAddresses");
        assertEquals(ModTag.REPLACED, me.get(null, "multiValued").getModTag());
    }

}
