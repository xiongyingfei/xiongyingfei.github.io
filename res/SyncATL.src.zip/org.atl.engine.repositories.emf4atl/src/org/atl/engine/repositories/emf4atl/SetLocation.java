/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl;

import org.atl.engine.vm.nativelib.ASMSet;
import org.atl.engine.vm.nativelib.ASMValue;


//This is not needed since all set only appears as sequences in memory
public class SetLocation extends CollectionLocation {

    ASMSet _set;
    ASMValue _originalValue;
    
    public SetLocation(ASMSet set, ASMValue originalValue) {
        super();
        _set = set;
        _originalValue = originalValue;
    }

    @Override
    public void deleteSourceValue() {
        _set.remove(_originalValue);
    }

    @Override
    public void replaceSourceValue(ASMValue value) {
        _set.remove(_originalValue);
        _set.add(value);
        _originalValue = value;

    }

    @Override
    public ASMValue getSourceValue() {
        return _originalValue;
    }

    @Override
    public void insertSourceValue(ASMValue value) {
        _set.add(value);
        
    }

}
