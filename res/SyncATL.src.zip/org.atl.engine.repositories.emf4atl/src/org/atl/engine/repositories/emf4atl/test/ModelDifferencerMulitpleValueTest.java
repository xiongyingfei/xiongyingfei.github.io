/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl.test;

import static org.atl.engine.repositories.emf4atl.test.ModelHelper.findModelElementByAttribute;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;

import org.atl.engine.repositories.emf4atl.ASMEMFModel;
import org.atl.engine.repositories.emf4atl.ASMEMFModelElement;
import org.atl.engine.repositories.emf4atl.ModelDifferencer;
import org.atl.engine.vm.nativelib.ASMModelElement;
import org.atl.engine.vm.nativelib.ASMSequence;
import org.atl.engine.vm.nativelib.ASMString;
import org.eclipse.emf.common.util.URI;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ModelDifferencerMulitpleValueTest {
    ASMEMFModel baseModel;

    ASMEMFModel updatedModel;

    ASMEMFModel metaModel;

    ModelDifferencer comparator;

    @Before
    public void setUp() throws Exception {
        metaModel = ASMEMFModel.loadASMEMFModel("Families", ASMEMFModel
                .createMOF(), URI.createFileURI("TestData/Families.ecore"));
        baseModel = ASMEMFModel.loadASMEMFModel("Source", metaModel, URI
                .createFileURI("TestData/Source.Families"));
        updatedModel = ASMEMFModel.loadASMEMFModel("Source", metaModel, URI
                .createFileURI("TestData/Source1.Families"));
        comparator = new ModelDifferencer();
        comparator.merge(baseModel, updatedModel);
    }

    @After
    public void tearDown() throws Exception {
        metaModel = null;
        baseModel = null;
        updatedModel = null;
        comparator = null;
    }

    @Test
    public void testAddInSet() throws Exception {
        ASMModelElement me = findModelElementByAttribute(baseModel, "Family",
                "lastName", "Liu");
        ASMSequence set = (ASMSequence) me.get(null, "stringSet");
        assertEquals(3, set.collection().size());
        assertTrue(set.collection().contains(new ASMString("efg")));
        for (Object o : set.collection()) {
            ASMString v = (ASMString) o;
            if (v.getSymbol().equals("abc"))
                assertEquals(ModTag.NON, v.getModTag());
            else if (v.getSymbol().equals("bbc"))
                assertEquals(ModTag.NON, v.getModTag());
            else if (v.getSymbol().equals("efg"))
                assertEquals(ModTag.INSERTED, v.getModTag());
            else
                fail();
        }

    }

    @Test
    public void testRemoveInSet() throws Exception {
        ASMEMFModelElement me = findModelElementByAttribute(baseModel, "Family",
                "lastName", "Hu");
        ASMSequence set = (ASMSequence) me.getRaw(null, "stringSet");
        assertEquals(2, set.collection().size());
        for (Object o : set.collection()) {
            ASMString v = (ASMString) o;
            if (v.getSymbol().equals("abc"))
                assertEquals(ModTag.NON, v.getModTag());
            else if (v.getSymbol().equals("bbc"))
                assertEquals(ModTag.DELETED, v.getModTag());
            else
                fail();

        }
    }

    @Test
    public void testModifyInSet() throws Exception {
        ASMEMFModelElement me = findModelElementByAttribute(baseModel, "Family",
                "lastName", "Xiong");
        ASMSequence set = (ASMSequence) me.getRaw(null, "stringSet");
        assertEquals(3, set.collection().size());
        for (Object o : set.collection()) {
            ASMString v = (ASMString) o;
            if (v.getSymbol().equals("abc"))
                assertEquals(ModTag.DELETED, v.getModTag());
            else if (v.getSymbol().equals("bbc"))
                assertEquals(ModTag.NON, v.getModTag());
            else if (v.getSymbol().equals("abc1"))
                assertEquals(ModTag.INSERTED, v.getModTag());
            else
                fail();

        }

    }

}
