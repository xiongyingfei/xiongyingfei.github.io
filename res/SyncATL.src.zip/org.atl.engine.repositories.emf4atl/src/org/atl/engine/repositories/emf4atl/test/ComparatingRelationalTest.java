/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl.test;

import static org.atl.engine.repositories.emf4atl.test.ModelHelper.findModelElementByAttribute;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;

import org.atl.engine.repositories.emf4atl.ASMEMFModel;
import org.atl.engine.repositories.emf4atl.ModelDifferencer;
import org.atl.engine.repositories.emf4atl.ModelElementComparator;
import org.atl.engine.vm.nativelib.ASMCollection;
import org.atl.engine.vm.nativelib.ASMModelElement;
import org.atl.engine.vm.nativelib.ASMOclUndefined;
import org.eclipse.emf.common.util.URI;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ComparatingRelationalTest {

    ASMEMFModel baseModel;

    ASMEMFModel updatedModel;

    ASMEMFModel metaModel;

    ModelDifferencer comparator;

    @Before
    public void setUp() throws Exception {
        metaModel = ASMEMFModel.loadASMEMFModel("Families", ASMEMFModel
                .createMOF(), URI.createFileURI("TestData/Relational.xmi"));
        baseModel = ASMEMFModel.loadASMEMFModel("Source", metaModel, URI
                .createFileURI("TestData/Target.relational"));
        updatedModel = ASMEMFModel.loadASMEMFModel("Source", metaModel, URI
                .createFileURI("TestData/Target-updated.relational"));
    }

    @After
    public void tearDown() throws Exception {
        metaModel = null;
        baseModel = null;
        updatedModel = null;
        comparator = null;
    }

    @Test
    public void testMoveModelElement() throws Exception {
        comparator = new ModelDifferencer();
        comparator.merge(baseModel, updatedModel);
        ASMModelElement closeFriend = findModelElementByAttribute(baseModel,
                "Column", "name", "closestFriendId");
        assertEquals(ModTag.NON, closeFriend.getModTag());

        assertEquals(ModTag.REPLACED, closeFriend.get(null, "owner")
                .getModTag());
        
        assertFalse(closeFriend.get(null, "owner") instanceof ASMOclUndefined);


        ASMModelElement person = findModelElementByAttribute(baseModel,
                "Table", "name", "Person");

        assertEquals(3, ((ASMCollection) person.getRaw(null, "col")).size());
        assertEquals(2, ((ASMCollection) person.get(null, "col")).size());

    }

    @Test
    public void testPrimaryAttribute() throws Exception {
        assertTrue(metaModel.findModelElement("Column")
                .getPrimaryAttributeNames().contains("name"));
        assertTrue(metaModel.findModelElement("Column")
                .getPrimaryAttributeNames().contains("keyOf"));
        assertEquals(2, metaModel.findModelElement("Column")
                .getPrimaryAttributeNames().size());
    }

    @Test
    public void testComparingMovedModelElement() throws Exception {
        ASMModelElement me1 = findModelElementByAttribute(baseModel, "Column",
                "name", "closestFriendId");
        ASMModelElement me2 = findModelElementByAttribute(updatedModel,
                "Column", "name", "closestFriendId");
        assertNotNull(me1);
        assertNotNull(me2);
        assertTrue(new ModelElementComparator().areCorrespondent(me1, me2));
    }

}
