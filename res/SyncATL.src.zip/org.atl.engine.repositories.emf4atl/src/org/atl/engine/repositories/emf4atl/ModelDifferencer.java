/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;

import org.atl.engine.repositories.emf4atl.ModelMerger.ConflictingModificationException;
import org.atl.engine.repositories.emf4atl.test.ModelMergerTest;
import org.atl.engine.vm.nativelib.ASMCollection;
import org.atl.engine.vm.nativelib.ASMModel;
import org.atl.engine.vm.nativelib.ASMModelElement;
import org.atl.engine.vm.nativelib.ASMOclAny;
import org.atl.engine.vm.nativelib.ASMOclUndefined;
import org.atl.engine.vm.nativelib.ASMReference;
import org.atl.engine.vm.nativelib.ASMModelElement.NotMetaModelObjectException;
import org.eclipse.emf.ecore.EReference;

public class ModelDifferencer {

    private ModelElementComparator _meComparator = new ModelElementComparator();

    private Map<ASMModelElement, ASMModelElement> _equalityMap = new HashMap<ASMModelElement, ASMModelElement>();

    private Map<ASMModelElement, ASMModelElement> _antiEqualityMap = new HashMap<ASMModelElement, ASMModelElement>();

    private ASMModel _metaModel;
    

    public void merge(ASMModel baseModel, ASMModel updatedModel)
            throws ConflictingModificationException {

        _metaModel = baseModel.getMetamodel();

        compareModelElements(baseModel, updatedModel);

        compareAttributes();

    }

    private void compareAttributes() throws ConflictingModificationException {
        for (Map.Entry<ASMModelElement, ASMModelElement> entry : _equalityMap
                .entrySet()) {
            ASMModelElement base = entry.getKey();
            ASMModelElement updated = entry.getValue();

//            if (this instanceof ModelMerger
//                    && updated.getType().getName().endsWith("Class")) {
//                    ASMOclAny value = updated.get(null, "attr");
//                    System.out.println("#######" + value);
//            }

            if (!base.getModTag().equals(ModTag.DELETED))
                compareOneAttribute(base, updated);

        }
    }

    private void compareOneAttribute(ASMModelElement base,
            ASMModelElement updated) throws ConflictingModificationException {
        try {
            for (String attr : base.getMetaobject().getAttributeNames()) {

                ASMOclAny vBase = base.getRaw(null, attr);
                ASMOclAny vUpdated = updated.getRaw(null, attr);
//                if (attr.equals("attr") && this instanceof ModelMerger) {
//                    System.out.println(base.getType().getName() + "****" + vUpdated);
//                }
                if (vBase instanceof ASMCollection) {
                    compareCollectionAttribute(base, attr, vBase, vUpdated);
                } else {
                    mergeSingleAttribute(base, attr, vBase, vUpdated);
                }
            }
        } catch (NotMetaModelObjectException e) {
            assert false;
            e.printStackTrace();
        }
    }

    protected void mergeSingleAttribute(ASMModelElement base, String attr,
            ASMOclAny vBase, ASMOclAny vUpdated)
            throws ConflictingModificationException {

        if (!areValuesEqual(vBase, vUpdated)) {
            copySingleValue(base, attr, vBase, vUpdated, ModTag.REPLACED);
        }
    }

    private boolean areValuesEqual(ASMOclAny vBase, ASMOclAny vUpdated) {
        if (vUpdated instanceof ASMReference) {
            ASMReference updatedRef = (ASMReference) vUpdated;
            if (vBase instanceof ASMOclUndefined) {
                return false;
            } else {
                ASMReference baseRef = (ASMReference) vBase;

                ASMModelElement correspondent = _equalityMap.get(baseRef
                        .getModelElement());

                if (correspondent == null) {
                    if (updatedRef.getModelElement() != null)
                        return false;
                } else if (correspondent.equals(updatedRef.getModelElement()))
                    return true;
                else
                    return false;
            }

        } else if (vBase.equals(vUpdated))
            return true;

        return false;

    }

    protected void copySingleValue(ASMModelElement base, String attr,
            ASMOclAny vBase, ASMOclAny vUpdated, ModTag tag) {
        if (vUpdated instanceof ASMReference) {
            copyReferenceAttribute(base, attr, vBase, (ASMReference) vUpdated,
                    tag);
        } else {
            copyBackwardExtions(vBase, vUpdated, tag);
            ((ASMEMFModelElement) base).directSetSingleValue(attr, vUpdated);
            // base.set(null, attr, vUpdated);
        }
    }

    private void copyReferenceAttribute(ASMModelElement base, String attr,
            ASMOclAny vBase, ASMReference updatedRef, ModTag tag) {

        ASMModelElement modelElement = _antiEqualityMap.get(updatedRef
                                .getModelElement());
        if (modelElement == null) return;
        ASMReference newBase = new ASMReference(modelElement);
        copyBackwardExtions(vBase, newBase, tag);
        assert vBase.getPutBack() != null;
        ((ASMEMFModelElement) base).directSetSingleValue(attr, newBase);
        // base.set(null, attr, newBase);
    }

    private void copyBackwardExtions(ASMOclAny vOld, ASMOclAny vNew, ModTag tag) {
        vNew.setModTag(tag);
        vNew.setPutBack(vOld.getPutBack());
    }

    private void compareCollectionAttribute(ASMModelElement base, String attr,
            ASMOclAny vBase, ASMOclAny vUpdated)
            throws ConflictingModificationException {
        {
            ASMCollection baseCol = (ASMCollection) vBase;
            ASMCollection updatedCol = (ASMCollection) vUpdated;
            Set marked = new HashSet();

            for (Object updatedItem : updatedCol.collection()) {
                boolean found = false;
                for (Object baseItem : baseCol.collection()) {
                    // if (updatedItem.toString().equals("Ref:
                    // Source!emailAddresses:Attribute")) {
                    // System.out.println(baseItem);
                    // }
                    if (marked.contains(baseItem))
                        continue;
                    if (areValuesEqual((ASMOclAny) baseItem,
                            (ASMOclAny) updatedItem)) {
                        marked.add(baseItem);
                        mergeMultipleAttributeValue((ASMOclAny)baseItem, (ASMOclAny)updatedItem);
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    mergeUnmatchedValueInUpdated(base, attr,
                            (ASMOclAny) updatedItem);
                }
            }
            for (Object baseItem : baseCol.collection()) {
                if (!marked.contains(baseItem)) {
                    mergeUnmatchedValueInBase(base, attr, (ASMOclAny) baseItem);
                }
            }
        }
    }
    
    protected void mergeMultipleAttributeValue(
            ASMOclAny baseItem, ASMOclAny updatedItem) throws ConflictingModificationException {
    }


    protected void mergeUnmatchedValueInBase(ASMModelElement base, String attr,
            ASMOclAny baseItem) throws ConflictingModificationException {
        baseItem.setModTag(ModTag.DELETED);
    }

    protected void mergeUnmatchedValueInUpdated(ASMModelElement base, String attr,
            ASMOclAny updatedItem) throws ConflictingModificationException {
        copySingleValue(base, attr, updatedItem, updatedItem, ModTag.INSERTED);
        // base.set(null, attr, updatedItem);
    }

    private void compareModelElements(ASMModel baseModel, ASMModel updatedModel)
            throws ConflictingModificationException {
        for (Object o : _metaModel.getElementsByType("EClass")) {
            ASMModelElement type = (ASMModelElement) o;
            if (type.getSubtypes().size() > 0)
                continue;
            Set baseSet = baseModel.getElementsByTypeRaw(type);
            Set updatedSet = updatedModel.getElementsByTypeRaw(type);
            compareModelElementSets(baseModel, type, baseSet, updatedSet);
        }
    }

    private void compareModelElementSets(ASMModel baseModel,
            ASMModelElement type, Set baseSet, Set updatedSet)
            throws ConflictingModificationException {
        for (Object o1 : updatedSet) {
            ASMModelElement meUpdated = (ASMModelElement) o1;
            boolean found = false;
            for (Object o2 : baseSet) {
                if (_equalityMap.get(o2) != null)
                    continue;
                ASMModelElement meBase = (ASMModelElement) o2;
                if (_meComparator.areCorrespondent(meBase, meUpdated)) {
                    setEqual(meBase, meUpdated);
                    assert (baseModel.getElementsByTypeRaw(type)
                            .contains(meBase));
                    mergeMatchedMEs(meBase, meUpdated);
                    found = true;
                    break;
                }
            }
            if (!found) {
                mergeUnmatchedMEInUpdated(baseModel, meUpdated);
            }
        }

        for (Object o3 : baseSet) {
            ASMModelElement me = (ASMModelElement) o3;
            if (_equalityMap.get(me) == null) {
                mergeUnmatchedMEInBase(me);
            }
        }
    }

    protected void mergeUnmatchedMEInBase(ASMModelElement me)
            throws ConflictingModificationException {
        me.setModTag(ModTag.DELETED);
//        try {
//            for(String name : me.getMetaobject().getAttributeNames()) {
//                ASMOclUndefined oclUndefined = new ASMOclUndefined();
//                oclUndefined.setModTag(ModTag.DELETED);
//                me.set(null, name, oclUndefined);
//            }
//        } catch (NotMetaModelObjectException e) {
//            e.printStackTrace();
//            assert false;
//        }
//
        
    }

    protected void mergeUnmatchedMEInUpdated(ASMModel baseModel,
            ASMModelElement meUpdated) throws ConflictingModificationException {
        ASMModelElement type = meUpdated.getMetaobject();
        ASMModelElement meBase = baseModel.newModelElement(type, true);
        meBase.setModTag(ModTag.INSERTED);
        setEqual(meBase, meUpdated);
        assert (baseModel.getElementsByTypeRaw(type).contains(meBase));
    }

    protected void mergeMatchedMEs(ASMModelElement meBase,
            ASMModelElement meUpdated) throws ConflictingModificationException {
    }

    protected void setEqual(ASMModelElement meBase, ASMModelElement meUpdated) {
        _equalityMap.put(meBase, meUpdated);
        _antiEqualityMap.put(meUpdated, meBase);
    }
}
