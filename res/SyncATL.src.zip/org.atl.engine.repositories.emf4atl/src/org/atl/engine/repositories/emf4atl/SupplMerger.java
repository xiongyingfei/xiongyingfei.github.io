/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl;

import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;

import org.atl.engine.repositories.emf4atl.ModelMerger.ConflictingModificationException;
import org.atl.engine.vm.nativelib.ASMModel;
import org.atl.engine.vm.nativelib.ASMModelElement;
import org.atl.engine.vm.nativelib.ASMOclAny;
import org.atl.engine.vm.nativelib.ASMReference;

public class SupplMerger extends ModelDifferencer {

    /*
     * (non-Javadoc)
     * 
     * @see org.atl.engine.repositories.emf4atl.ModelDifferencer#mergeMatchedMEs(org.atl.engine.vm.nativelib.ASMModelElement,
     *      org.atl.engine.vm.nativelib.ASMModelElement)
     */
    @Override
    protected void mergeMatchedMEs(ASMModelElement meBase,
            ASMModelElement meUpdated) throws ConflictingModificationException {
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.atl.engine.repositories.emf4atl.ModelDifferencer#mergeMissedMEInBase(org.atl.engine.vm.nativelib.ASMModelElement)
     */
    @Override
    protected void mergeUnmatchedMEInBase(ASMModelElement me)
            throws ConflictingModificationException {

    }

    /*
     * (non-Javadoc)
     * 
     * @see org.atl.engine.repositories.emf4atl.ModelDifferencer#mergeMissedMEInUpdated(org.atl.engine.vm.nativelib.ASMModel,
     *      org.atl.engine.vm.nativelib.ASMModelElement)
     */
    @Override
    protected void mergeUnmatchedMEInUpdated(ASMModel baseModel,
            ASMModelElement meUpdated) throws ConflictingModificationException {
        ASMModelElement type = meUpdated.getMetaobject();
       if (!baseModel.hasTypeCreated(type.getName())) {
            ASMModelElement meBase = baseModel.newModelElement(type, false);
            setEqual(meBase, meUpdated);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.atl.engine.repositories.emf4atl.ModelDifferencer#mergeMissedValueInBase(org.atl.engine.vm.nativelib.ASMModelElement,
     *      java.lang.String, org.atl.engine.vm.nativelib.ASMOclAny)
     */
    @Override
    protected void mergeUnmatchedValueInBase(ASMModelElement base, String attr,
            ASMOclAny baseItem) throws ConflictingModificationException {
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.atl.engine.repositories.emf4atl.ModelDifferencer#mergeMissedValueInUpdated(org.atl.engine.vm.nativelib.ASMModelElement,
     *      java.lang.String, org.atl.engine.vm.nativelib.ASMOclAny)
     */
    @Override
    protected void mergeUnmatchedValueInUpdated(ASMModelElement base, String attr, ASMOclAny updatedItem) throws ConflictingModificationException {
        if (base.getRaw(null, attr).getModTag().equals(ModTag.UNSET) ||
                (updatedItem instanceof ASMReference && 
                        base.getModel().hasTypeCreated(((ASMReference)updatedItem).getModelElement().getMetaobject().getName()))) {
            copySingleValue(base, attr, updatedItem, updatedItem, updatedItem.getModTag());
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.atl.engine.repositories.emf4atl.ModelDifferencer#mergeSingleAttribute(org.atl.engine.vm.nativelib.ASMModelElement,
     *      java.lang.String, org.atl.engine.vm.nativelib.ASMOclAny,
     *      org.atl.engine.vm.nativelib.ASMOclAny)
     */
    @Override
    protected void mergeSingleAttribute(ASMModelElement base, String attr,
            ASMOclAny vBase, ASMOclAny vUpdated)
            throws ConflictingModificationException {
        if (vBase.getModTag().equals(ModTag.UNSET)) {
            copySingleValue(base, attr, vBase, vUpdated, vUpdated.getModTag());
        }
    }

}
