/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl.test;

import static org.junit.Assert.assertTrue;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.atl.engine.repositories.emf4atl.ASMEMFModel;
import org.atl.engine.vm.ASM;
import org.atl.engine.vm.ASMExecEnv;
import org.atl.engine.vm.ASMOperation;
import org.atl.engine.vm.ASMStackFrame;
import org.atl.engine.vm.DummyDebugger;
import org.atl.engine.vm.StackFrame;
import org.atl.engine.vm.nativelib.ASMBoolean;
import org.atl.engine.vm.nativelib.ASMModelElement;
import org.atl.engine.vm.nativelib.ASMModule;
import org.atl.engine.vm.nativelib.ASMString;
import org.eclipse.emf.common.util.URI;
import org.junit.Test;

public class ModelReadTest {

    @Test
    public void testReadNonEcoreType() throws Exception {
        ASMEMFModel.createMOF();

        ASMEMFModel metaModel = ASMEMFModel.loadASMEMFModel("Classes",
                ASMEMFModel.createMOF(), URI.createFileURI("TestData/Class.xmi"));
        ASMEMFModel model = ASMEMFModel.loadASMEMFModel("Source", metaModel,
                URI.createFileURI("TestData/Source.classes"));

        ASM asm = new ASM();
        ASMModule module = new ASMModule(asm);
        ASMExecEnv env = new ASMExecEnv(module, new DummyDebugger());
        List list = new LinkedList();
        list.add(asm);
        StackFrame frame = ASMStackFrame.rootFrame(env, new ASMOperation(asm,
                "main"), list);

        Set attributes = model.getElementsByType("Attribute");
        for (Object o : attributes) {
            ASMModelElement me = (ASMModelElement) o;
            assertTrue(me.get(frame, "name") instanceof ASMString);
            assertTrue(me.get(frame, "multiValued") instanceof ASMBoolean);
        }
        
//        for (TreeIterator i = model.getExtent().getAllContents(); i.hasNext();) {
//            EObject eo = (EObject) i.next();
//            break;
//        }
//        for (TreeIterator i = model.getExtent().getAllContents(); i.hasNext();) {
//            EObject eo = (EObject) i.next();
//        }

    }

}
