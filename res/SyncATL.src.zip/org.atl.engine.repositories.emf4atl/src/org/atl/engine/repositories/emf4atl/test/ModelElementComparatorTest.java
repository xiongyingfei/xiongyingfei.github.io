/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl.test;

import org.atl.engine.repositories.emf4atl.ASMEMFModel;
import org.atl.engine.repositories.emf4atl.ASMEMFModelElement;
import org.atl.engine.repositories.emf4atl.ModelElementComparator;
import org.atl.engine.vm.nativelib.ASMModelElement;
import org.atl.engine.vm.nativelib.ASMOclAny;
import org.atl.engine.vm.nativelib.ASMReference;
import org.atl.engine.vm.nativelib.ASMString;
import org.eclipse.emf.common.util.URI;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.atl.engine.repositories.emf4atl.test.ModelHelper.*;
import static org.junit.Assert.*;

public class ModelElementComparatorTest {

    ASMEMFModel model1;

    ASMEMFModel model0;

    ASMEMFModel metaModel;

    ModelElementComparator comparator;

    @Before
    public void setUp() throws Exception {
        metaModel = ASMEMFModel.loadASMEMFModel("Families", ASMEMFModel
                .createMOF(), URI.createFileURI("TestData/Class.xmi"));
        model1 = ASMEMFModel.loadASMEMFModel("Source", metaModel, URI
                .createFileURI("TestData/Source1.classes"));
        model0 = ASMEMFModel.loadASMEMFModel("Source", metaModel, URI
                .createFileURI("TestData/Source.classes"));
        comparator = new ModelElementComparator();
    }

    @After
    public void tearDown() throws Exception {
        metaModel = null;
        model1 = null;
        model0 = null;
        comparator = null;
    }

    @Test
    public void testCompareClassesTrue() {
        ASMModelElement class0 = findModelElementByAttribute(model0, "Class",
                "name", "Family");
        ASMModelElement class1 = findModelElementByAttribute(model1, "Class",
                "name", "Family");
        
        assertTrue(comparator.areCorrespondent(class0, class1));

    }

    @Test
    public void testCompareClassesFalse() {
        ASMModelElement class0 = findModelElementByAttribute(model0, "Class",
                "name", "Family");
        ASMModelElement class1 = findModelElementByAttribute(model1, "Class",
                "name", "Person");
        
        assertFalse(comparator.areCorrespondent(class0, class1));

    }
    
    private class AttributeChecker implements Checker {

        ASMModelElement owner;
        String name;
        
        public AttributeChecker(ASMModelElement me, String name) {
            super();
            this.owner = me;
            this.name = name;
        }

        public boolean satisfy(ASMEMFModelElement me) {
            ASMOclAny nameValue = me.get(null, "name");
            ASMOclAny ownerValue = me.get(null, "owner");
            return nameValue.equals(new ASMString(name)) && 
            ownerValue.equals(new ASMReference(owner));
        }
        
    }

    @Test
    public void testCompareAttributesTrue() {
        ASMModelElement class0 = findModelElementByAttribute(model0, "Class",
                "name", "Family");
        ASMModelElement class1 = findModelElementByAttribute(model1, "Class",
                "name", "Family");
        
        ASMModelElement attr0 = findModelElementIf(model0, "Attribute", 
                new AttributeChecker(class0, "name"));
        ASMModelElement attr1 = findModelElementIf(model1, "Attribute", 
                new AttributeChecker(class1, "name"));

        
        assertTrue(comparator.areCorrespondent(attr0, attr1));

    }

    @Test
    public void testCompareAttributesFalse() {
        ASMModelElement class0 = findModelElementByAttribute(model0, "Class",
                "name", "Family");
        ASMModelElement class1 = findModelElementByAttribute(model1, "Class",
                "name", "Person");
        
        ASMModelElement attr0 = findModelElementIf(model0, "Attribute", 
                new AttributeChecker(class0, "name"));
        ASMModelElement attr1 = findModelElementIf(model1, "Attribute", 
                new AttributeChecker(class1, "name"));

        
        assertFalse(comparator.areCorrespondent(attr0, attr1));

    }
    
}
