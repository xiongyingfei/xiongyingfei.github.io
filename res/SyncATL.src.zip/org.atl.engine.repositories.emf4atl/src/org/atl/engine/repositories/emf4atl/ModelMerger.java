/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl;

import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;

import org.atl.engine.vm.nativelib.ASMModel;
import org.atl.engine.vm.nativelib.ASMModelElement;
import org.atl.engine.vm.nativelib.ASMOclAny;

public class ModelMerger extends ModelDifferencer {

    public static class ConflictingModificationException extends Exception {

        private static final long serialVersionUID = -5532155344758540214L;

        public ConflictingModificationException() {
            super();
        }

        public ConflictingModificationException(String modelElementName) {
            super("Conflict modification detected on " + modelElementName);
        }

        public ConflictingModificationException(String modelElementName,
                String attrName) {
            super("Conflict modification detected on " + modelElementName + ":"
                    + attrName);
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see org.atl.engine.repositories.emf4atl.ModelComparator#mergeMatchedMEs(org.atl.engine.vm.nativelib.ASMModelElement,
     *      org.atl.engine.vm.nativelib.ASMModelElement)
     */
    @Override
    protected void mergeMatchedMEs(ASMModelElement meBase,
            ASMModelElement meUpdated) throws ConflictingModificationException {
        if (meBase.getModTag().equals(ModTag.NON)) {
            meBase.setModTag(meUpdated.getModTag());
        } else if (meBase.getModel().equals(ModTag.DELETED)) {
            if (meUpdated.getModTag().equals(ModTag.INSERTED))
                throw new ConflictingModificationException(meBase.getName());
        } else {
            if (meUpdated.getModTag().equals(ModTag.DELETED)) {
                throw new ConflictingModificationException(meBase.getName());
            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.atl.engine.repositories.emf4atl.ModelComparator#mergeMissedMEInBase(org.atl.engine.vm.nativelib.ASMModelElement)
     */
    @Override
    protected void mergeUnmatchedMEInBase(ASMModelElement me)
            throws ConflictingModificationException {
        // assert (me.getModTag().equals(ModTag.INSERTED) || me.getModTag()
        // .equals(ModTag.DELETED));
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.atl.engine.repositories.emf4atl.ModelComparator#mergeMissedMEInUpdated(org.atl.engine.vm.nativelib.ASMModel,
     *      org.atl.engine.vm.nativelib.ASMModelElement)
     */
    @Override
    protected void mergeUnmatchedMEInUpdated(ASMModel baseModel,
            ASMModelElement meUpdated) throws ConflictingModificationException {
        // if (!meUpdated.getModTag().equals(ModTag.INSERTED)) {
        // System.out.println(meUpdated);
        // System.out.println(meUpdated.getModTag());
        // System.out.println(meUpdated.get(null, "lastName"));
        // }
        // assert (meUpdated.getModTag().equals(ModTag.INSERTED));
        ASMModelElement type = meUpdated.getMetaobject();
        ASMModelElement meBase = baseModel.newModelElement(type, true);
        meBase.setModTag(ModTag.INSERTED);
        setEqual(meBase, meUpdated);
        assert (baseModel.getElementsByTypeRaw(type).contains(meBase));
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.atl.engine.repositories.emf4atl.ModelComparator#mergeMissedValueInBase(java.lang.Object)
     */
    @Override
    protected void mergeUnmatchedValueInBase(ASMModelElement base, String attr,
            ASMOclAny baseItem) throws ConflictingModificationException {
        // assert (baseItem.getModTag().equals(ModTag.INSERTED));
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.atl.engine.repositories.emf4atl.ModelComparator#mergeMissedValueInUpdated(org.atl.engine.vm.nativelib.ASMModelElement,
     *      java.lang.String, java.lang.Object)
     */
    @Override
    protected void mergeUnmatchedValueInUpdated(ASMModelElement base,
            String attr, ASMOclAny updatedItem)
            throws ConflictingModificationException {
        // assert updatedItem.getModTag().equals(ModTag.INSERTED) :
        // base.getName()
        // + ":" + attr + ":" + updatedItem;

        copySingleValue(base, attr, updatedItem, updatedItem, ModTag.INSERTED);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.atl.engine.repositories.emf4atl.ModelComparator#mergeSingleAttribute(org.atl.engine.vm.nativelib.ASMModelElement,
     *      java.lang.String, org.atl.engine.vm.nativelib.ASMOclAny,
     *      org.atl.engine.vm.nativelib.ASMOclAny)
     */
    @Override
    protected void mergeSingleAttribute(ASMModelElement base, String attr,
            ASMOclAny vBase, ASMOclAny vUpdated)
            throws ConflictingModificationException {
        if (vBase.getModTag().equals(ModTag.NON)
                || vBase.getModTag().equals(ModTag.UNSET)) {
            copySingleValue(base, attr, vBase, vUpdated, vUpdated.getModTag());
        } else if (vBase.getModTag().equals(ModTag.DELETED)) {
            if (vUpdated.getModTag().equals(ModTag.INSERTED)
                    || vUpdated.getModTag().equals(ModTag.REPLACED))
                throw new ConflictingModificationException(base.getName(), attr);
        } else {
            if (vUpdated.getModTag().equals(ModTag.NON)
                    || vUpdated.getModTag().equals(ModTag.UNSET)) {

            } else if (vUpdated.getModTag().equals(ModTag.DELETED)) {
                throw new ConflictingModificationException(base.getName(), attr);
            } else {
                if (!vBase.equals(vUpdated)) {
                    throw new ConflictingModificationException(base.getName(),
                            attr);
                }
            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.atl.engine.repositories.emf4atl.ModelDifferencer#mergeMultipleAttributeValue(org.atl.engine.vm.nativelib.ASMOclAny,
     *      org.atl.engine.vm.nativelib.ASMOclAny)
     */
    @Override
    protected void mergeMultipleAttributeValue(ASMOclAny baseItem,
            ASMOclAny updatedItem) throws ConflictingModificationException {
        if (baseItem.getModTag().equals(ModTag.NON)
                || baseItem.getModTag().equals(ModTag.UNSET)) {
            baseItem.setModTag(updatedItem.getModTag());
        }
    }

}
