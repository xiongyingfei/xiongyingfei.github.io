/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;

import org.atl.engine.repositories.emf4atl.ASMEMFModel;
import org.atl.engine.repositories.emf4atl.ASMEMFModelElement;
import org.atl.engine.vm.ASM;
import org.atl.engine.vm.ASMExecEnv;
import org.atl.engine.vm.ASMOperation;
import org.atl.engine.vm.ASMStackFrame;
import org.atl.engine.vm.DummyDebugger;
import org.atl.engine.vm.StackFrame;
import org.atl.engine.vm.nativelib.ASMModelElement;
import org.atl.engine.vm.nativelib.ASMModule;
import org.atl.engine.vm.nativelib.ASMOclAny;
import org.atl.engine.vm.nativelib.ASMReference;
import org.atl.engine.vm.nativelib.ASMSequence;
import org.atl.engine.vm.nativelib.ASMSet;
import org.atl.engine.vm.nativelib.ASMString;
import org.eclipse.emf.common.util.URI;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class ASMEMFModelElementTest {

    private static final String TEMP_FILE_NAME = "TestData/temp.families";

    ASMEMFModel model;

    ASMEMFModel metaModel;

    ASMEMFModelElement aFamily;

    ASMModelElement aMember;

    private StackFrame frame;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        ASMEMFModel.resetAll();
        ASMEMFModel.createMOF();
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
        metaModel = ASMEMFModel.loadASMEMFModel("Families", ASMEMFModel
                .createMOF(), URI.createFileURI("TestData/Families.ecore"));
        model = ASMEMFModel.loadASMEMFModel("Source", metaModel, URI
                .createFileURI("TestData/Source.Families"));

        ASM asm = new ASM();
        ASMModule module = new ASMModule(asm);
        ASMExecEnv env = new ASMExecEnv(module, new DummyDebugger());
        List list = new LinkedList();
        list.add(asm);
        frame = ASMStackFrame.rootFrame(env, new ASMOperation(asm, "main"),
                list);
    }

    private void initializeFamilyAndMember() {
        aFamily = (ASMEMFModelElement) model.newModelElement(metaModel
                .findModelElement("Family"), true);
        aMember = model.newModelElement(metaModel.findModelElement("Member"), true);
    }

    @After
    public void tearDown() throws Exception {
        metaModel = null;
        model = null;
        aFamily = null;
        aMember = null;
        frame = null;
        // new File(TEMP_FILE_NAME).delete();
    }

    @Test
    public void testSetGetSingle() throws Exception {
        initializeFamilyAndMember();
        ASMString str = new ASMString("abc");
        str.setPutBack(new TestPutBack());
        str.setModTag(ModTag.INSERTED);
//        str.setPutBack(new TestPutBack());
        aFamily.set(frame, "lastName", str);
        ASMString newStr = (ASMString) aFamily.get(frame, "lastName");
        assertTrue(newStr.getPutBack() instanceof TestPutBack);
        assertEquals("abc", newStr.getSymbol());
    }

    @Test
    public void testSetGetSequence() throws Exception {
        initializeFamilyAndMember();
        ASMString str1 = new ASMString("abc1");
        str1.setPutBack(new TestPutBack());
        str1.setModTag(ModTag.INSERTED);
//        str1.setSatisfy(new TestSatisfy());

        ASMString str2 = new ASMString("abc2");
        str2.setPutBack(new TestPutBack());
        str2.setModTag(ModTag.NON);
//        str2.setSatisfy(new TestSatisfy());

        ASMSequence list = new ASMSequence();
        list.add(str1);
        list.add(str2);
        aFamily.set(frame, "stringSeq", list);
        ASMSequence newList = (ASMSequence) aFamily.get(frame, "stringSeq");
        assertTrue(((ASMString) newList.at(0)).getPutBack() instanceof TestPutBack);
        assertTrue(((ASMString) newList.at(1)).getPutBack() instanceof TestPutBack);
        assertEquals("abc1", ((ASMString) newList.at(0)).getSymbol());
        assertEquals("abc2", ((ASMString) newList.at(1)).getSymbol());
    }

    @Test
    public void testSetGetSet() throws Exception {
        initializeFamilyAndMember();
        ASMString str1 = new ASMString("abc1");
        str1.setPutBack(new TestPutBack());
        str1.setModTag(ModTag.INSERTED);
//        str1.setSatisfy(new TestSatisfy());

        ASMString str2 = new ASMString("abc2");
        str2.setPutBack(new TestPutBack());
        str2.setModTag(ModTag.NON);
//        str2.setSatisfy(new TestSatisfy());

        ASMString str3 = new ASMString("abc2");

        ASMSet set = new ASMSet();
        set.add(str1);
        set.add(str2);
        aFamily.set(frame, "stringSet", set);
        set = new ASMSet();
        set.add(str3);
        aFamily.set(frame, "stringSet", set);

        aFamily.set(frame, "lastName", new ASMString("ANameForTesting"));

        model.save(TEMP_FILE_NAME);
        model = ASMEMFModel.loadASMEMFModel("Temp", metaModel, URI
                .createFileURI(TEMP_FILE_NAME));
        aFamily = findModelElementByAttribute("Family", "lastName",
                "ANameForTesting");

        assertTrue(aFamily != null);

        ASMSequence newSet = (ASMSequence) aFamily.get(frame, "stringSet");
        assertTrue(newSet.collection().contains(new ASMString("abc1")));
        assertTrue(newSet.collection().contains(new ASMString("abc2")));
        assertEquals(2, newSet.collection().size());
    }

    @Test
    public void testSetGetOppositeManySide() throws Exception {
        initializeFamilyAndMember();
        ASMSet set = new ASMSet();
        ASMReference ref = new ASMReference(aMember);
        ref.setPutBack(new TestPutBack());
        ref.setModTag(ModTag.INSERTED);
//        ref.setSatisfy(new TestSatisfy());
        set.add(ref);
        aFamily.set(frame, "member", set);

        ASMReference newRef = (ASMReference) aMember.get(frame, "family");
        assertSame(aFamily, newRef.getModelElement());
        assertEquals(ModTag.INSERTED, newRef.getModTag());
    }

    @Test
    public void testSetGetOppositeSingleSide() throws Exception {
        initializeFamilyAndMember();
        ASMReference ref1 = new ASMReference(aFamily);
        ref1.setPutBack(new TestPutBack());
        ref1.setModTag(ModTag.REPLACED);
//        ref1.setSatisfy(new TestSatisfy());

        ASMModelElement family2 = getExistingFamily();

        ASMReference ref2 = new ASMReference(family2);
        ref2.setPutBack(new TestPutBack());
        ref2.setModTag(ModTag.REPLACED);
//        ref2.setSatisfy(new TestSatisfy());
        aMember.set(frame, "family", ref1);
        aMember.set(frame, "family", ref2);

        ASMSequence set1 = (ASMSequence) aFamily.getRaw(frame, "member");
        assertTrue(set1 != null);
        assertEquals(1, set1.collection().size());
        ASMReference oppositeRef1 = ((ASMReference) set1.collection()
                .iterator().next());
        assertTrue(oppositeRef1.getModelElement().equals(aMember));
        assertEquals(ModTag.DELETED, oppositeRef1.getModTag());

        ASMSequence set2 = (ASMSequence) family2.get(frame, "member");
        assertTrue(set2.collection().contains(new ASMReference(aMember)));

        final String specialStringForTesting = "NameForTesting111";
        aFamily.set(frame, "lastName", new ASMString(specialStringForTesting));
        model.save(TEMP_FILE_NAME);
        model = ASMEMFModel.loadASMEMFModel("Temp", metaModel, URI
                .createFileURI(TEMP_FILE_NAME));
        ASMModelElement result = findModelElementByAttribute("Family",
                "lastName", specialStringForTesting);
        assertEquals(0, ((ASMSequence) result.get(frame, "member")).size());

    }

    private ASMModelElement getExistingFamily() {
        Iterator iterator = model.getElementsByType("Family").iterator();
        ASMModelElement family2 = (ASMModelElement) iterator.next();
        if (family2 == aFamily)
            family2 = (ASMModelElement) iterator.next();
        return family2;
    }

    private ASMEMFModelElement findModelElementByAttribute(final String family,
            final String attrName, final String expected) {
        // ASMEMFModelElement result = null;
        // for (Object o : model.getElementsByType(family)) {
        // ASMEMFModelElement me = (ASMEMFModelElement) o;
        // if (me.get(frame, attrName).equals(
        // new ASMString(expected))) {
        // result = me;
        // break;
        // }
        // }
        // return result;
        return ModelHelper.findModelElementByAttribute(model, family, attrName,
                expected);
    }

    @Test
    public void testSingleLocationReplace() throws Exception {
        final ASMModelElement family = getExistingFamily();
        ASMString str1 = (ASMString) family.get(frame, "lastName");

        ASMString str2 = new ASMString("abc2");
        str2.setPutBack(new TestPutBack());
        str2.setModTag(ModTag.REPLACED);
//        str2.setSatisfy(new TestSatisfy());

        str1.getPutBack().putBackModification(str2);

        ASMString newStr = (ASMString) family.get(frame, "lastName");
        assertEquals("abc2", newStr.getSymbol());
        assertEquals(ModTag.REPLACED, newStr.getModTag());
    }

    @Test
    public void testSetLocationReplace() throws Exception {
        final ASMModelElement family = getExistingFamily();
        ASMSequence set = (ASMSequence) family.get(frame, "stringSet");
        ASMString str1 = (ASMString) set.iterator().next();

        ASMString str2 = new ASMString("abc2");
        str2.setPutBack(new TestPutBack());
        str2.setModTag(ModTag.REPLACED);
//        str2.setSatisfy(new TestSatisfy());

        str1.getPutBack().putBackModification(str2);

        ASMSequence newSet = (ASMSequence) family.get(frame, "stringSet");
        assertTrue(newSet.collection().contains(str2));
    }

    @Test
    public void testLocationInsert() throws Exception {

    }

    @Test
    public void testLocationDelete() throws Exception {
        final ASMModelElement family = getExistingFamily();
        ASMSequence set = (ASMSequence) family.get(frame, "stringSet");
        ASMString str1 = (ASMString) set.iterator().next();
        int size = set.size();

//        ASMString str2 = new ASMString(str1.getSymbol());
//        str2.setModTag(ModTag.DELETED);

        str1.getPutBack().putBackDeletion();

        ASMSequence newSet = (ASMSequence) family.get(frame, "stringSet");
        assertFalse(newSet.collection().contains(str1));
        assertEquals(size - 1, newSet.collection().size());
    }

    @Test
    public void testModelElementDelete() throws Exception {
        final ASMModelElement family = getExistingFamily();
        assertTrue(((ASMSequence) family.get(frame, "member")).collection()
                .size() != 0);
        ASMModelElement member = ((ASMReference) ((ASMSequence) family.get(
                frame, "member")).iterator().next()).getModelElement();

        family.setModTag(ModTag.DELETED);
        family.putBack();
        
        //family.getSourceLocation().deleteSourceElement();

        assertEquals(ModTag.DELETED, family.getModTag());
        assertEquals(ModTag.DELETED, member.getModTag());

    }
    
    
    @Test
    public void testSaveDeletedModelElement() throws Exception {
        final ASMModelElement family = getExistingFamily();
        assertTrue(((ASMSequence) family.get(frame, "member")).collection()
                .size() != 0);
        ASMModelElement member = ((ASMReference) ((ASMSequence) family.get(
                frame, "member")).iterator().next()).getModelElement();
        
        ASMOclAny v = member.get(null, "firstName");

        member.setModTag(ModTag.DELETED);
        member.putBack();
        
        model.save(TEMP_FILE_NAME);
        model = ASMEMFModel.loadASMEMFModel("Temp", metaModel, URI
                .createFileURI(TEMP_FILE_NAME));
        aMember = findModelElementByAttribute("Member", "firstName",
                ((ASMString)v).getSymbol());

        Assert.assertNull(aMember);

    }


    private static class TestPutBack implements
            jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.PutBack {

        public void putback(ASMOclAny o) {
        }

        public void putBackDeletion() {
            
        }

        public void putBackModification(ASMOclAny o) {
            
        }

        public boolean satisfyDeletion() {
            return false;
        }

        public boolean satisfyModification(ASMOclAny o) {
            return false;
        }

        public ASMOclAny reevalute() {
            return null;
        }
    }


}
