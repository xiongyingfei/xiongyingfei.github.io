/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl.test;

import static org.atl.engine.repositories.emf4atl.test.ModelHelper.findModelElementByAttribute;
import static org.junit.Assert.assertEquals;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;

import org.atl.engine.repositories.emf4atl.ASMEMFModel;
import org.atl.engine.repositories.emf4atl.ModelDifferencer;
import org.atl.engine.repositories.emf4atl.ModelMerger;
import org.atl.engine.vm.nativelib.ASMModelElement;
import org.eclipse.emf.common.util.URI;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ModelMergerClass2RelationalIDTest {

    ASMEMFModel baseModel;

    ASMEMFModel metaModel;
    

    @Before
    public void setUp() throws Exception {
        metaModel = ASMEMFModel.loadASMEMFModel("Families", ASMEMFModel
                .createMOF(), URI.createFileURI("TestData/ClassID.xmi"));
        baseModel = ASMEMFModel.loadASMEMFModel("Source", metaModel, URI
                .createFileURI("TestData/SourceID.classes"));
        ASMEMFModel updatedModel0 = ASMEMFModel.loadASMEMFModel("Source",
                metaModel, URI.createFileURI("TestData/SourceID1.classes"));
        ASMEMFModel baseModel1 = ASMEMFModel.loadASMEMFModel("Target",
                metaModel, URI.createFileURI("TestData/SourceID.classes"));
        ASMEMFModel updatedModel1 = ASMEMFModel.loadASMEMFModel("Target",
                metaModel, URI.createFileURI("TestData/SourceID.classes"));
        ModelDifferencer differencer0 = new ModelDifferencer();
        differencer0.merge(baseModel, updatedModel0);
        ModelDifferencer differencer1 = new ModelDifferencer();
        differencer1.merge(baseModel1, updatedModel1);

        ModelMerger merger = new ModelMerger();
        merger.merge(baseModel, baseModel1);
    }

    @After
    public void tearDown() throws Exception {
        metaModel = null;
        baseModel = null;
    }

    @Test
    public void testDeleteModelElement() throws Exception {
        ASMModelElement me = findModelElementByAttribute(baseModel,
                "Attribute", "name", "closestFriend");
        assertEquals(ModTag.DELETED, me.getModTag());
    }
}
