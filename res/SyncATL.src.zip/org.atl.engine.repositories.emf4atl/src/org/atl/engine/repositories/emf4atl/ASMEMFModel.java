package org.atl.engine.repositories.emf4atl;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;

import org.atl.engine.vm.nativelib.ASMModel;
import org.atl.engine.vm.nativelib.ASMModelElement;
import org.atl.engine.vm.nativelib.ASMOclUndefined;
import org.atl.engine.vm.nativelib.ASMModelElement.NotMetaModelObjectException;
import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceImpl;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.XMIResource;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

/**
 * @author Fr�d�ric Jouault
 * @author Dennis Wagelaar <dennis.wagelaar@vub.ac.be>
 */
public class ASMEMFModel extends ASMModel {

    // true if extent was explicitly loaded and requires explicit unloading
    private boolean unload = false;

    // nsURIs that were explicitly registered and need unregistering
    private Set unregister = new HashSet();

    // if not null, model could not yet be loaded from URI and needs to be
    // loaded later from this URI
    private String resolveURI = null;

    public static ASMEMFModel getMOF() {
        return mofmm;
    }

    private Map modelElements = new HashMap();

    public ASMModelElement getASMModelElement(EObject object) {
        ASMModelElement ret = null;

        synchronized (modelElements) {
            ret = (ASMModelElement) modelElements.get(object);
            if (ret == null) {
                ret = new ASMEMFModelElement(modelElements, this, object);
            }

        }

        return ret;
    }
    
    
    private ASMModelElement getASMModelElementForNew(EObject object) {
        ASMModelElement ret = null;

        synchronized (modelElements) {
            ret = new ASMEMFModelElement(modelElements, this, object, true);
        }

        return ret;
    }


    private Map classifiers = null;

    private ASMModelElement getClassifier(String name) {
        if (classifiers == null) {
            classifiers = new HashMap();
            initClassifiersInAllExtents(classifiers);
        }
        ASMModelElement ret = null;

        EObject eo = (EObject) classifiers.get(name);
        if (eo != null) {
            ret = getASMModelElement(eo);
        }

        return ret;
    }

    /**
     * Indexes all classifiers in main extent and referenced extents.
     * 
     * @param classifiers
     *            The classifier map to build.
     * @see #register(Map, String, EObject)
     * @author Dennis Wagelaar <dennis.wagelaar@vub.ac.be>
     */
    private void initClassifiersInAllExtents(Map classifiers) {
        initClassifiers(getExtent().getContents().iterator(), classifiers, null);
        Iterator refExtents = referencedExtents.iterator();
        while (refExtents.hasNext()) {
            initClassifiers(((Resource) refExtents.next()).getContents()
                    .iterator(), classifiers, null);
        }
    }

    private void initClassifiers(Iterator i, Map classifiers, String base) {
        for (; i.hasNext();) {
            EObject eo = (EObject) i.next();
            if (eo instanceof EPackage) {
                String name = ((EPackage) eo).getName();
                if (base != null) {
                    name = base + "::" + name;
                }
                initClassifiers(((EPackage) eo).eContents().iterator(),
                        classifiers, name);
            } else if (eo instanceof EClassifier) {
                String name = ((EClassifier) eo).getName();
                // register the classifier under its simple name
                register(classifiers, name, eo);
                if (base != null) {
                    name = base + "::" + name;
                    // register the classifier under its full name
                    register(classifiers, name, eo);
                }
            } else {
                // No meta-package or meta-class => just keep digging.
                // N.B. This situation occurs in UML2 profiles, where
                // EPackages containing EClasses are buried somewhere
                // underneath other elements.
                initClassifiers(eo.eContents().iterator(), classifiers, base);
            }
        }
    }

    private void register(Map classifiers, String name, EObject classifier) {
        if (classifiers.containsKey(name)) {
            System.out
                    .println("Warning: metamodel contains several classifiers with same name: "
                            + name);
        }
        classifiers.put(name, classifier);
    }

    public ASMModelElement findModelElement(String name) {
        ASMModelElement ret = null;

        ret = getClassifier(name);

        return ret;
    }

    /*
     * public ASMModelElement findModelElement(String name) { ASMModelElement
     * ret = null;
     * 
     * EObject eo = null;
     * 
     * eo = findModelElementIn(name, extent.getContents().iterator());
     * 
     * if(eo != null) ret = getASMModelElement(eo);
     * 
     * return ret; }
     * 
     * private EObject findModelElementIn(String name, Iterator i) { EObject ret =
     * null;
     * 
     * for( ; i.hasNext() && (ret == null); ) { EObject t = (EObject)i.next();
     * if(t instanceof EPackage) { ret = ((EPackage)t).getEClassifier(name);
     * if(ret == null) { ret = findModelElementIn(name,
     * ((EPackage)t).getESubpackages().iterator()); } } }
     * 
     * return ret; }
     */

    /**
     * @param type
     *            The type of element to search for.
     * @return The set of ASMModelElements that are instances of type.
     * @see ASMModelElement
     */
    public Set getElementsByType(ASMModelElement type) {
        Set ret = new HashSet();
        EClass t = (EClass) ((ASMEMFModelElement) type).getEObject();
        addElementsOfType(ret, t, getExtent(), false);
        for (Iterator i = referencedExtents.iterator(); i.hasNext();) {
            Resource res = (Resource) i.next();
            addElementsOfType(ret, t, res, false);
        }

        return ret;
    }

    /**
     * Adds all elements of the given type to the set.
     * 
     * @param elements
     *            The set to add to.
     * @param type
     *            The type to test for.
     * @param res
     *            The resource containing the elements.
     */
    private void addElementsOfType(Set elements, EClassifier type, Resource res, boolean includingDeleted) {
        for (Iterator i = res.getAllContents(); i.hasNext();) {
            EObject eo = (EObject) i.next();
            if (type.isInstance(eo)) {
                ASMModelElement modelElement = getASMModelElement(eo);
                if (modelElement.getModTag().isDeleted() && !includingDeleted) continue;
                elements.add(modelElement);
            }
        }
    }

    private void addElementsOfTypeRaw(Set elements, EClassifier type, Resource res, boolean includingDeleted) {
        for (Iterator i = res.getAllContents(); i.hasNext();) {
            EObject eo = (EObject) i.next();
            if (type.isInstance(eo)) {
                ASMModelElement modelElement = getASMModelElement(eo);
                elements.add(modelElement);
            }
        }
    }

    
    public ASMModelElement newModelElementImpl(ASMModelElement type) {
        ASMModelElement ret = null;

        EClass t = (EClass) ((ASMEMFModelElement) type).getEObject();
        EObject eo = t.getEPackage().getEFactoryInstance().create(t);
        ret = (ASMEMFModelElement) getASMModelElementForNew(eo);
        getExtent().getContents().add(eo);

        return ret;
    }

    /**
     * @param name
     * @param metamodel
     * @param isTarget
     */
    protected ASMEMFModel(String name, Resource extent, ASMEMFModel metamodel,
            boolean isTarget) {
        super(name, metamodel, isTarget);
        this.extent = extent;
    }

    /**
     * Simple Resource wrapping factory.
     */
    public static ASMEMFModel loadASMEMFModel(String name,
            ASMEMFModel metamodel, Resource extent) throws Exception {
        ASMEMFModel ret = null;

        ret = new ASMEMFModel(name, extent, metamodel, false);

        return ret;
    }

    public void dispose() {

        if (extent != null) {
            referencedExtents.clear();
            referencedExtents = null;
            for (Iterator unrs = unregister.iterator(); unrs.hasNext();) {
                String nsURI = (String) unrs.next();
                resourceSet.getPackageRegistry().remove(nsURI);

            }
            resourceSet.getResources().remove(extent);
            if (unload) {
                extent.unload();
            }
            extent = null;

            modelElements.clear();
            unregister.clear();
        }
    }

    public void finalize() {
        dispose();
    }

    /**
     * Creates a new ASMEMFModel. Do not use this method for models that require
     * a special registered factory (e.g. uml2).
     * 
     * @param name
     *            The model name. Also used as EMF model URI.
     * @param metamodel
     * @return
     * @throws Exception
     */
    public static ASMEMFModel newASMEMFModel(String name, ASMEMFModel metamodel)
            throws Exception {
        return newASMEMFModel(name, name, metamodel);
    }

    /**
     * Creates a new ASMEMFModel.
     * 
     * @param name
     *            The model name. Not used by EMF.
     * @param uri
     *            The model URI. EMF uses this to determine the correct factory.
     * @param metamodel
     * @return
     * @throws Exception
     * @author Dennis Wagelaar <dennis.wagelaar@vub.ac.be>
     */
    public static ASMEMFModel newASMEMFModel(String name, String uri,
            ASMEMFModel metamodel) throws Exception {
        ASMEMFModel ret = null;

        Resource extent = resourceSet.createResource(URI.createURI(uri));

        ret = new ASMEMFModel(name, extent, metamodel, true);
        ret.unload = true;

        return ret;
    }

    public static ASMEMFModel loadASMEMFModel(String name,
            ASMEMFModel metamodel, String url) throws Exception {
        ASMEMFModel ret = null;

        if (url.startsWith("uri:")) {
            String uri = url.substring(4);
            EPackage pack = resourceSet.getPackageRegistry().getEPackage(uri);
            if (pack == null) {
                ret = new ASMEMFModel(name, null, metamodel, false);
                ret.resolveURI = uri;
            } else {
                Resource extent = pack.eResource();
                ret = new ASMEMFModel(name, extent, metamodel, false);
                ret.addAllReferencedExtents();
            }
        } else {
            ret = loadASMEMFModel(name, metamodel, URI.createURI(url));
        }

        return ret;
    }

    public static ASMEMFModel loadASMEMFModel(String name,
            ASMEMFModel metamodel, URL url) throws Exception {
        ASMEMFModel ret = null;

        ret = loadASMEMFModel(name, metamodel, url.openStream());

        return ret;
    }

    public static ASMEMFModel loadASMEMFModel(String name,
            ASMEMFModel metamodel, URI uri) throws Exception {
        ASMEMFModel ret = null;

        try {
            Resource extent = resourceSet.createResource(uri);
            extent.load(Collections.EMPTY_MAP);
            // Resource extent = resourceSet.getResource(uri, true);
            ret = new ASMEMFModel(name, extent, metamodel, true);
            ret.addAllReferencedExtents();
//            ret.setIsTarget(false);
            ret.unload = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        adaptMetamodel(ret, metamodel);

        return ret;
    }

    public static ASMEMFModel loadASMEMFModel(String name,
            ASMEMFModel metamodel, InputStream in) throws Exception {
        ASMEMFModel ret = newASMEMFModel(name, metamodel);

        try {
            ret.getExtent().load(in, Collections.EMPTY_MAP);
            ret.addAllReferencedExtents();
            ret.unload = true;
        } catch (Exception e) {
            e.printStackTrace();
        }

        adaptMetamodel(ret, metamodel);
//        ret.setIsTarget(false);

        return ret;
    }

    private static void adaptMetamodel(ASMEMFModel model, ASMEMFModel metamodel) {
        if (metamodel == mofmm) {
            for (Iterator i = model.getElementsByType("EPackage").iterator(); i
                    .hasNext();) {
                ASMEMFModelElement ame = (ASMEMFModelElement) i.next();
                EPackage p = (EPackage) ame.getEObject();
                String nsURI = p.getNsURI();
                if (nsURI == null) {
                    // System.err.println("DEBUG: EPackage " + p.getName() + "
                    // in model " + model.getName() + " has no nsURI.");
                    nsURI = p.getName();
                    p.setNsURI(nsURI);
                }
                if (resourceSet.getPackageRegistry().containsKey(nsURI)) {
                    if (!p.equals(resourceSet.getPackageRegistry().getEPackage(
                            nsURI))) {
                        // System.err.println("WARNING: overwriting local EMF
                        // registry entry for " + nsURI);
                    }
                } else {
                    model.unregister.add(nsURI);
                }
                resourceSet.getPackageRegistry().put(nsURI, p);
                // System.err.println("INFO: Registering " + nsURI + " in local
                // EMF registry");
            }
            for (Iterator i = model.getElementsByType("EDataType").iterator(); i
                    .hasNext();) {
                ASMEMFModelElement ame = (ASMEMFModelElement) i.next();
                EStructuralFeature nameAttr = ame.getEObject().eClass()
                        .getEStructuralFeature("name");
                EStructuralFeature instanceClassNameAttr = ame.getEObject()
                        .eClass().getEStructuralFeature("instanceClassName");
                assert ame != null;
                // assert ame.get(null, "name") != null;
                assert ame.getEObject().eGet(nameAttr) != null;
                // String tname = ((ASMString) ame.get(null,
                // "name")).getSymbol();
                String tname = (String) ame.getEObject().eGet(nameAttr);
                String icn = null;
                if (tname.equals("Boolean")) {
                    icn = "boolean"; // "java.lang.Boolean";
                } else if (tname.equals("Double")) {
                    icn = "java.lang.Double";
                } else if (tname.equals("Float")) {
                    icn = "java.lang.Float";
                } else if (tname.equals("Integer")) {
                    icn = "java.lang.Integer";
                } else if (tname.equals("String")) {
                    icn = "java.lang.String";
                }
                if (icn != null)
                    // ame.set(null, "instanceClassName", new ASMString(icn));
                    ame.getEObject().eSet(instanceClassNameAttr, icn);
            }
        }

        /*
         * reader.read(url.openStream(), url.toString(), ret.pack);
         * ret.getAllAcquaintances();
         */
    }

    public static ASMEMFModel createMOF() {

        if (mofmm == null) {
            // Resource extent =
            // resourceSet.createResource(URI.createURI("http://www.eclipse.org/emf/2002/Ecore"));
            // System.out.println("Actual resource class: " +
            // extent.getClass());
            // extent.getContents().add(EcorePackage.eINSTANCE);
            mofmm = new ASMEMFModel("MOF", EcorePackage.eINSTANCE.eResource(),
                    null, false);
        }

        return mofmm;
    }

    public Resource getExtent() {
        if ((extent == null) && (resolveURI != null)) {
            EPackage pack = resourceSet.getPackageRegistry().getEPackage(
                    resolveURI);
            extent = pack.eResource();
            addAllReferencedExtents();
        }
        return extent;
    }

    static {
        init();
    }

    public static void resetAll() {
        mofmm = null;
        resourceSet = null;
        init();
    }

    private static void init() {
        Map etfm = Resource.Factory.Registry.INSTANCE
                .getExtensionToFactoryMap();
        if (!etfm.containsKey("*")) {
            etfm.put("*", new XMIResourceFactoryImpl());
        }
        // System.out.println(Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap());
        // System.out.println(Resource.Factory.Registry.INSTANCE.getProtocolToFactoryMap());
        resourceSet = new ResourceSetImpl();

    }

    public static ResourceSet getResourceSet() {
        return resourceSet;
    }

    public boolean equals(Object o) {
        return (o instanceof ASMEMFModel)
                && (((ASMEMFModel) o).extent == extent);
    }

    private static ResourceSet resourceSet;

    private static ASMEMFModel mofmm = null;

    private Resource extent;

    private Set referencedExtents = new HashSet();

    /**
     * Searches for and adds all Resource extents that are referenced from the
     * main extent to referencedExtents.
     * 
     * @author Dennis Wagelaar <dennis.wagelaar@vub.ac.be>
     */
    private void addAllReferencedExtents() {
        Iterator contents = getExtent().getAllContents();
        while (contents.hasNext()) {
            Object o = contents.next();
            if (o instanceof EClass) {
                addReferencedExtentsFor((EClass) o, new HashSet());
            }
        }
        referencedExtents.remove(getExtent());
    }

    /**
     * Searches for and adds all Resource extents that are referenced from
     * eClass to referencedExtents.
     * 
     * @author Dennis Wagelaar <dennis.wagelaar@vub.ac.be>
     * @param eClass
     * @param ignore
     *            Set of classes to ignore for searching.
     */
    private void addReferencedExtentsFor(EClass eClass, Set ignore) {
        if (ignore.contains(eClass)) {
            return;
        }
        ignore.add(eClass);
        Iterator eRefs = eClass.getEReferences().iterator();
        while (eRefs.hasNext()) {
            EReference eRef = (EReference) eRefs.next();
            if (eRef.isContainment()) {
                EClassifier eType = eRef.getEType();
                if (eType.eResource() != null) {
                    referencedExtents.add(eType.eResource());
                } else {
                    System.err.println("WARNING: Resource for "
                            + eType.toString()
                            + " is null; cannot be referenced");
                }
                if (eType instanceof EClass) {
                    addReferencedExtentsFor((EClass) eType, ignore);
                }
            }
        }
        Iterator eAtts = eClass.getEAttributes().iterator();
        while (eAtts.hasNext()) {
            EAttribute eAtt = (EAttribute) eAtts.next();
            EClassifier eType = eAtt.getEType();
            if (eType.eResource() != null) {
                referencedExtents.add(eType.eResource());
            } else {
                System.err.println("WARNING: Resource for " + eType.toString()
                        + " is null; cannot be referenced");
            }
        }
        Iterator eSupers = eClass.getESuperTypes().iterator();
        while (eSupers.hasNext()) {
            EClass eSuper = (EClass) eSupers.next();
            if (eSuper.eResource() != null) {
                referencedExtents.add(eSuper.eResource());
                addReferencedExtentsFor(eSuper, ignore);
            } else {
                System.err.println("WARNING: Resource for " + eSuper.toString()
                        + " is null; cannot be referenced");
            }
        }
    }

    /**
     * @return The set of referenced Resources.
     */
    public Set getReferencedExtents() {
        return referencedExtents;
    }
    
    public void removeModelElementFromResource(ASMEMFModelElement element) {
//        writeEObjects();
//        element.setModTag(ModTag.DELETED);
//        for (Iterator i = element.getEObject().eContents().iterator(); i.hasNext();)
//            removeModelElement((ASMEMFModelElement) getASMModelElement((EObject) i.next()));

        EObject object = element.getEObject();
        if (object.eContainer() != null) {
            EObject container = element.getEObject().eContainer();
            EStructuralFeature containingFeature = object.eContainingFeature();
            ((ASMEMFModelElement) getASMModelElement(container))
                    .removeReference(null, containingFeature
                            .getName(), element);
            

        }

        for(Object o : object.eClass().getEAllReferences()) {
            EReference ref = (EReference) o;
            if (ref.getEOpposite() == null)
            {
                continue;
            }
            ASMOclUndefined oclUndefined = new ASMOclUndefined();
            oclUndefined.setModTag(ModTag.DELETED);
            element.set(null, ref.getName(), oclUndefined);
        }
        
    }

    public void removeModelElement(ASMEMFModelElement element) {
        writeEObjects();
        element.setModTag(ModTag.DELETED);
//        try {
//            for(String name : element.getMetaobject().getAttributeNames()) {
//                element.get(null, name).setModTag(ModTag.DELETED);
//            }
//        } catch (NotMetaModelObjectException e) {
//            assert false;
//            e.printStackTrace();
//        }
        for (TreeIterator i = element.getEObject().eAllContents(); i.hasNext();)
            getASMModelElement((EObject) i.next()).setModTag(ModTag.DELETED);
//        for (Iterator i = element.getEObject().eContents().iterator(); i.hasNext();)
//            removeModelElement((ASMEMFModelElement) getASMModelElement((EObject) i.next()));

//        for (EContentsEList.FeatureIterator featureIterator = (EContentsEList.FeatureIterator) element
//                .getEObject().eCrossReferences().iterator(); featureIterator
//                .hasNext();) {
//            EObject eObject = (EObject) featureIterator.next();
//            EReference eReference = (EReference) featureIterator.feature();
//            
//            System.out.println(eObject);
//            System.out.println(eReference.getName());
//            
//            ((ASMEMFModelElement) getASMModelElement(eObject)).removeReference(
//                    null, eReference.getName(), element);
//        }

//        EObject object = element.getEObject();
//        if (object.eContainer() != null) {
//            EObject container = element.getEObject().eContainer();
//            EStructuralFeature containingFeature = object.eContainingFeature();
//            ((ASMEMFModelElement) getASMModelElement(container))
//                    .removeReference(null, containingFeature
//                            .getName(), element);
//            
//
//        }
//
//        for(Object o : object.eClass().getEAllReferences()) {
//            EReference ref = (EReference) o;
//            if (ref.getEOpposite() == null)
//            {
//                continue;
//            }
//            ASMOclUndefined oclUndefined = new ASMOclUndefined();
//            oclUndefined.setModTag(ModTag.DELETED);
//            element.set(null, ref.getName(), oclUndefined);
//        }
        
        

    }

    @Override
    public void save(String strUri) throws IOException {
        final String encoding = "ISO-8859-1";
        final boolean useIDs = false;
        final boolean removeIDs = false;

        Resource r = getExtent();
        URI uri = URI.createURI(strUri);
        if (uri != null) {
            r.setURI(uri);
        }
        Map options = new HashMap();
        options.put(XMIResource.OPTION_ENCODING, encoding);
        options.put(XMIResource.OPTION_USE_ENCODED_ATTRIBUTE_STYLE,
                Boolean.FALSE);

        // for (TreeIterator i = r.getAllContents(); i.hasNext();) {
        // EObject eo = (EObject) i.next();
        // ASMModelElement asmElement = getASMModelElement(eo);
        // if (asmElement.getModTag().isDeleted()) {
        // i.remove();
        // continue;
        // }
        // }
        // for (TreeIterator i = r.getAllContents(); i.hasNext();) {
        // EObject eo = (EObject) i.next();
        // ASMModelElement asmElement = getASMModelElement(eo);
        // asmElement.prepareSave();
        // }
        //
        // for (TreeIterator i = r.getAllContents(); i.hasNext();) {
        // EObject eo = (EObject) i.next();
        // ASMModelElement asmElement = getASMModelElement(eo);
        // if (asmElement.IsContained()) {
        // i.remove();
        // }
        // }
//        for (Iterator i = modelElements.values().iterator(); i.hasNext();) {
//            ASMEMFModelElement asmElement = (ASMEMFModelElement) i.next();
//            if (asmElement.getModTag().isDeleted()
//                    && asmElement.getEObject().eContainer() == null) {
//                r.getContents().remove(asmElement.getEObject());
//            }
//
//        }

        writeEObjectsBeforeSave();

        if ((useIDs || removeIDs) && (r instanceof XMIResource)) {
            XMIResource xr = ((XMIResource) r);
            int id = 1;
            Set alreadySet = new HashSet();
            for (Iterator i = r.getAllContents(); i.hasNext();) {
                EObject eo = (EObject) i.next();
                if (alreadySet.contains(eo))
                    continue; // because sometimes a single element gets
                // processed twice
                xr.setID(eo, removeIDs ? null : ("a" + (id++)));
                alreadySet.add(eo);
            }
        }

        try {
            r.save(options);
        } catch (IOException e1) {
            e1.printStackTrace();
        }

    }

    private void writeEObjects() {
        Resource r = getExtent();
        for (Iterator i = modelElements.values().iterator(); i.hasNext();) {
            ASMEMFModelElement asmElement = (ASMEMFModelElement) i.next();
            if (asmElement.getModTag().isDeleted()) continue;
            asmElement.prepareSave();
        }
        
        for (Iterator i = modelElements.values().iterator(); i.hasNext();) {
            ASMEMFModelElement asmElement = (ASMEMFModelElement) i.next();
            if (asmElement.IsContained()) {
                r.getContents().remove(asmElement.getEObject());
            }
            else {             
                r.getContents().add(asmElement.getEObject());
            }
        }
    }
    
    private void writeEObjectsBeforeSave() {

        Resource r = getExtent();
        for (Iterator i = modelElements.values().iterator(); i.hasNext();) {
            ASMEMFModelElement asmElement = (ASMEMFModelElement) i.next();
            if (asmElement.getModTag().isDeleted()) {
                removeModelElementFromResource(asmElement);
            }
        }

        writeEObjects();
        
        for (Iterator i = modelElements.values().iterator(); i.hasNext();) {
            ASMEMFModelElement asmElement = (ASMEMFModelElement) i.next();
            if (asmElement.getModTag().isDeleted()) {
                r.getContents().remove(asmElement.getEObject());
            }
        }

        
        
    }

    @Override
    public void putBack() {
        Resource r = getExtent();
        for (Iterator i = r.getAllContents(); i.hasNext();) {
            ASMModelElement me = getASMModelElement((EObject) i.next());
            me.putBackReplacement();
        }
        for (Iterator i = r.getAllContents(); i.hasNext();) {
            ASMModelElement me = getASMModelElement((EObject) i.next());
            me.putBackDeletion();
        }
    }

    @Override
    public boolean satisfy() {
        Resource r = getExtent();
        for (Iterator i = r.getAllContents(); i.hasNext();) {
            ASMModelElement me = getASMModelElement((EObject) i.next());
            if (!me.satisfy())
                return false;
        }
        return true;
    }

    @Override
    public Set getElementsByTypeRaw(ASMModelElement type) {
        Set ret = new HashSet();
        EClass t = (EClass) ((ASMEMFModelElement) type).getEObject();
        addElementsOfType(ret, t, getExtent(), true);
        for (Iterator i = referencedExtents.iterator(); i.hasNext();) {
            Resource res = (Resource) i.next();
            addElementsOfTypeRaw(ret, t, res, true);
        }

        return ret;
    }

}
