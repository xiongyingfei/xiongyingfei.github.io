/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl;

import org.atl.engine.vm.StackFrame;
import org.atl.engine.vm.nativelib.ASMSequence;
import org.atl.engine.vm.nativelib.ASMValue;

public class MultipleAttrLocation extends CollectionLocation {
    
    private ASMEMFModelElement _modelElement;
    private String _attributeName;
    private StackFrame _frame;
    private int _index;

    public MultipleAttrLocation(StackFrame frame, ASMEMFModelElement modelElement, String attributeName, int index) {
        super();
        _frame = frame;
        _modelElement = modelElement;
        _attributeName = attributeName;
        _index = index;
    }

    @Override
    public void replaceSourceValue(ASMValue value) {
        checkReplacementConflicts(value, _attributeName, _modelElement.toString());
        _modelElement.replaceItemInMultiple(_attributeName, _index, value);
    }

    @Override
    public void deleteSourceValue() {
        checkDeletionConflicts(_attributeName, _modelElement.toString());
        _modelElement.removeItemFromMultiple(_attributeName, _index);
    }

    @Override
    public ASMValue getSourceValue() {
        return (ASMValue) 
        ((ASMSequence)_modelElement.getRaw(_frame, _attributeName)).at(_index);
    }

    @Override
    public void insertSourceValue(ASMValue value) {
        ASMSequence seq = new ASMSequence();
        seq.add(value);
        _modelElement.set(_frame, _attributeName, seq);

    }

}
