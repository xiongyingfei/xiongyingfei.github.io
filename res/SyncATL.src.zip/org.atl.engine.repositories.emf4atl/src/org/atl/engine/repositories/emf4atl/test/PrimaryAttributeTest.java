/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.atl.engine.repositories.emf4atl.ASMEMFModel;
import org.eclipse.emf.common.util.URI;
import org.junit.Test;

public class PrimaryAttributeTest {

    @Test
    public void testFamily() throws Exception {
        ASMEMFModel metaModel = ASMEMFModel.loadASMEMFModel("Families",
                ASMEMFModel.createMOF(), URI
                        .createFileURI("TestData/Families.ecore"));

        assertTrue(metaModel.findModelElement("Family").isPrimaryAttribute(
                "lastName"));
        assertEquals(1, metaModel.findModelElement("Family")
                .getPrimaryAttributeNames().size());
        assertEquals("lastName", metaModel.findModelElement("Family")
                .getPrimaryAttributeNames().iterator().next());
        
    }
    
    @Test
    public void testClass() throws Exception {
        ASMEMFModel metaModel = ASMEMFModel.loadASMEMFModel("Class",
                ASMEMFModel.createMOF(), URI
                        .createFileURI("TestData/Class.xmi"));

        assertTrue(metaModel.findModelElement("Class").isPrimaryAttribute(
                "name"));
        assertTrue(metaModel.findModelElement("Attribute")
                .getPrimaryAttributeNames().contains("owner"));
        assertTrue(metaModel.findModelElement("Attribute")
                .getPrimaryAttributeNames().contains("name"));
        assertEquals(2, metaModel.findModelElement("Attribute")
                .getPrimaryAttributeNames().size());

    }

}
