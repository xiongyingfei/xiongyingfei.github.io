/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl;

import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.SourceLocation;

import org.atl.engine.vm.StackFrame;
import org.atl.engine.vm.nativelib.ASMValue;

public class AttributeLocation extends SourceLocation {

    private ASMEMFModelElement _modelElement;

    private String _attributeName;

    private StackFrame _frame;

    @Override
    public void replaceSourceValue(ASMValue value) {
        checkReplacementConflicts(value, _attributeName, _modelElement.toString());
        _modelElement.set(_frame, _attributeName, value);
    }

    public AttributeLocation(ASMEMFModelElement modelElement,
            String attributeName, StackFrame frame) {
        super();
        _modelElement = modelElement;
        _attributeName = attributeName;
        _frame = frame;
    }

    @Override
    public ASMValue getSourceValue() {
        return (ASMValue) _modelElement.get(_frame, _attributeName);
    }

    public void deleteSourceValue() {
        //replaceSourceValue(null);
        _modelElement.getRaw(_frame, _attributeName).setModTag(ModTag.DELETED);
    }

    @Override
    public void insertSourceValue(ASMValue value) {
        replaceSourceValue(value);

    }

}
