/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl;


import org.atl.engine.vm.nativelib.ASMModelElement.NotMetaModelObjectException;

import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModelElementLocation;

public class EMFModelElementLocation implements ModelElementLocation {

    ASMEMFModel _model;
    ASMEMFModelElement _modelElement;
    
    public EMFModelElementLocation(ASMEMFModel model, ASMEMFModelElement modelElement) {
        super();
        _model = model;
        _modelElement = modelElement;
    }

    public void deleteSourceElement() {
        try {
            for(String name : _modelElement.getMetaobject().getAttributeNames()) {
                ModTag modTag = _modelElement.get(null, name).getModTag();
                if(modTag.equals(ModTag.REPLACED) || modTag.equals(ModTag.INSERTED)) {
                    System.err.println("Conflicting modifications detected! On: " + _model + " and attribute " + name);
                }
            }
        } catch (NotMetaModelObjectException e) {
            assert false;
            e.printStackTrace();
        }
        _model.removeModelElement(_modelElement);
    }

    public void insertNewElement() {
        // TODO Auto-generated method stub

    }

    public ASMEMFModelElement getModelElement() {
        return _modelElement;
        
    }

}
