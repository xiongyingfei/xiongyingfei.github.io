/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl;

import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;

import org.atl.engine.vm.nativelib.ASMSequence;
import org.atl.engine.vm.nativelib.ASMValue;

public class InnerSequenceLocation extends CollectionLocation {

    ASMSequence _sequence;
    int _index;


    public InnerSequenceLocation(ASMSequence sequence, int index) {
        super();
        _sequence = sequence;
        _index = index;
    }

    @Override
    public void deleteSourceValue() {
        checkDeletionConflicts("", "");
        _sequence.at(_index).setModTag(ModTag.DELETED);

    }

    @Override
    public void replaceSourceValue(ASMValue value) {
        checkReplacementConflicts(value, "", "");
        _sequence.replace(_index, value);
    }

    @Override
    public ASMValue getSourceValue() {
        return (ASMValue) _sequence.at(_index);
    }

    @Override
    public void insertSourceValue(ASMValue value) {
        // TODO Auto-generated method stub
        
    }
}
