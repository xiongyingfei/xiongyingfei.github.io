/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl.test;

import org.atl.engine.repositories.emf4atl.ASMEMFModelElement;
import org.atl.engine.vm.nativelib.ASMModel;
import org.atl.engine.vm.nativelib.ASMString;

public class ModelHelper {
    public static ASMEMFModelElement findModelElementByAttribute(
            final ASMModel model, final String className, final String attrName,
            final String attrValue) {
        ASMEMFModelElement result = null;
        for (Object o : model.getElementsByTypeRaw(className)) {
            ASMEMFModelElement me = (ASMEMFModelElement) o;
            if (me.get(null, attrName).equals(new ASMString(attrValue))) {
                result = me;
                break;
            }
        }
        return result;
    }

    public interface Checker {
        boolean satisfy(ASMEMFModelElement me);
    }
    
    public static ASMEMFModelElement findModelElementIf(
            final ASMModel model, final String className, Checker checker) {
        ASMEMFModelElement result = null;
        for (Object o : model.getElementsByTypeRaw(className)) {
            ASMEMFModelElement me = (ASMEMFModelElement) o;
            if (checker.satisfy(me)) {
                result = me;
                break;
            }
        }
        return result;
    }


}
