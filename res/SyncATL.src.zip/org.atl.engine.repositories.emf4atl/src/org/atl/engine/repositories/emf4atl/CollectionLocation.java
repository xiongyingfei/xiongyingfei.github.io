/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl;

import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.SourceLocation;

import org.atl.engine.vm.nativelib.ASMValue;

public abstract class CollectionLocation extends SourceLocation {
    
    @Override
    public abstract void replaceSourceValue(ASMValue value);

}
