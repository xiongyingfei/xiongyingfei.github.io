/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package org.atl.engine.repositories.emf4atl.test;

import static org.atl.engine.repositories.emf4atl.test.ModelHelper.findModelElementByAttribute;
import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import jp.ac.u_tokyo.ipl.BiXM.backwardExtensions.ModTag;

import org.atl.engine.repositories.emf4atl.ASMEMFModel;
import org.atl.engine.repositories.emf4atl.ModelDifferencer;
import org.atl.engine.repositories.emf4atl.SupplMerger;
import org.atl.engine.vm.nativelib.ASMModelElement;
import org.atl.engine.vm.nativelib.ASMReference;
import org.atl.engine.vm.nativelib.ASMSequence;
import org.atl.engine.vm.nativelib.ASMString;
import org.eclipse.emf.common.util.URI;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SupplementMergerTest {

    ASMEMFModel baseModel;

    ASMEMFModel updatedModel;

    ASMEMFModel metaModel;

    SupplMerger comparator;

    @Before
    public void setUp() throws Exception {
        metaModel = ASMEMFModel.loadASMEMFModel("Families", ASMEMFModel
                .createMOF(), URI.createFileURI("TestData/Families.ecore"));
        baseModel = ASMEMFModel.newASMEMFModel("Base", metaModel);
        ASMModelElement me = baseModel.newModelElement("Family");
        me.set(null, "lastName", new ASMString("Xiong"));
        
        me.set(null, "stringSeq", new ASMString("13"));
        
        assert(me.get(null, "stringSet").getModTag().equals(ModTag.UNSET));
        assert(me.getRaw(null, "stringSet").getModTag().equals(ModTag.UNSET));
        
        updatedModel = ASMEMFModel.loadASMEMFModel("Source", metaModel, URI
                .createFileURI("TestData/Source.Families"));
        comparator = new SupplMerger();
        comparator.merge(baseModel, updatedModel);
    }

    @After
    public void tearDown() throws Exception {
        metaModel = null;
        baseModel = null;
        updatedModel = null;
        comparator = null;
    }
    
    @Test
    public void testSetAttribute() {
        ASMModelElement me = findModelElementByAttribute(baseModel, "Family",
                "lastName", "Xiong");
        ASMSequence set = (ASMSequence) me.get(null, "stringSeq");
        assertEquals(1, set.collection().size());
        assertTrue(set.collection().contains(new ASMString("13")));
    }

    @Test
    public void testUnsetAttribute() {
        ASMModelElement me = findModelElementByAttribute(baseModel, "Family",
                "lastName", "Xiong");
        ASMSequence set = (ASMSequence) me.get(null, "stringSet");
        assertEquals(2, set.collection().size());
        assertTrue(set.collection().contains(new ASMString("bbc")));
    }

    @Test
    public void testUncreatedType() {
        ASMModelElement me2 = findModelElementByAttribute(baseModel, "Member",
                "firstName", "Yingfei");
        assertNotNull(me2);
        ASMModelElement me = findModelElementByAttribute(baseModel, "Family",
                "lastName", "Xiong");
        ASMSequence set = (ASMSequence) me.get(null, "member");
        assertEquals(2, set.collection().size());
        assertTrue(set.collection().contains(new ASMReference(me2)));

    }

    
    @Test
    public void testCreatedType() {
        ASMModelElement me = findModelElementByAttribute(baseModel, "Family",
                "lastName", "Liu");
        assertNull(me);
    }


}
