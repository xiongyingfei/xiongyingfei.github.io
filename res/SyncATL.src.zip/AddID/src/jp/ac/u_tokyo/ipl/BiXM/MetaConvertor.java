package jp.ac.u_tokyo.ipl.BiXM;

import java.io.IOException;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EAnnotation;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.ENamedElement;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EcoreFactory;
import org.eclipse.emf.ecore.impl.EAnnotationImpl;
import org.eclipse.emf.ecore.impl.EcoreFactoryImpl;
import org.eclipse.emf.ecore.impl.EcorePackageImpl;
import org.eclipse.emf.ecore.resource.Resource;
/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */

public class MetaConvertor {
    
    public static void convert(String srcFile, String tgtFile) throws IOException {
        Resource src = ModelManager.INSTANCE.loadModel(srcFile);
        
        for (TreeIterator it = src.getAllContents(); it.hasNext();) {
            EObject o = (EObject) it.next();
            if (o instanceof EClass) {
                EClass c = (EClass) o;
                EList superTypes = c.getEAllSuperTypes();
                if (superTypes.size() == 0) {
                    EAttribute id = createIDAttribute(o.eClass().eResource());
                    c.getEStructuralFeatures().add(id);
                }
            }
            if (o instanceof EPackage) {
                EPackage p = (EPackage) o;
                if (p.getNsURI() == null || p.getNsURI().equals("")) {
                    p.setNsURI(p.getName());
                }
                
            }
            
        }
        
        src.setURI(URI.createFileURI(tgtFile));
        src.save(null);

    }
    
    private static EAttribute createIDAttribute(Resource ecore) {
        EcoreFactory factory = new EcoreFactoryImpl();
        EAttribute attr = factory.createEAttribute();
        EDataType string = EcorePackageImpl.init().getEString();
        attr.setEType(string);
        attr.setName("ID");
        
        EAnnotation annotation = factory.createEAnnotation();
        annotation.setSource("http:///jp.ac.u_tokyo.ipl.BiXM.AttributeAnnotations");
        annotation.getDetails().put("PrimaryAttribute", "true");
        annotation.setEModelElement(attr);

        return attr;
    }
    
//    private static ENamedElement findByName(EList objects, String name) {
//        for(Object obj : objects) {
//            if (obj instanceof ENamedElement) {
//                if (((ENamedElement)obj).getName().equals(name))
//                    return (ENamedElement) obj;
//            }
//        }
//        return null;
//    }
    
    public static void main(String[] args) {
        try {
            convert("testData/Class.xmi", "testData/ClassID.xmi");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
