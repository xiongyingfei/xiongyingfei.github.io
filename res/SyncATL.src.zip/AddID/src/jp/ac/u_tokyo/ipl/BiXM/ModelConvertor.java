/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM;

import java.io.IOException;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;

public class ModelConvertor {

    /**
     * @param args
     */
    public static void main(String[] args) {
        try {
            convert("testData/ClassID.xmi", "testData/Sample.classes", "testData/SampleID.classes");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private static int _idCounter = 0;
    
    private static String getID() {
        return new Integer(_idCounter++).toString();
    }
    
    public static void convert(String metaModel, String srcFile, String tgtFile) throws IOException {
        ModelManager.INSTANCE.loadMetaModel(metaModel);
        Resource src = ModelManager.INSTANCE.loadModel(srcFile);
        
        for (TreeIterator it = src.getAllContents(); it.hasNext();) {
            EObject o = (EObject) it.next();
            ModelManager.setAttribute(o, "ID", getID());
        }
        
        src.setURI(URI.createFileURI(tgtFile));
        src.save(null);
    }

}
