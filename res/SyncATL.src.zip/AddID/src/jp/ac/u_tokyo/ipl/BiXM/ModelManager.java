package jp.ac.u_tokyo.ipl.BiXM;

import java.util.Iterator;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EFactory;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

/*
 * Copyright (c) 2007, Xiong Yingfei, SwiftWing Studio
 * All rights reserved.
 */

public class ModelManager {

    private final ResourceSet _resSet = new ResourceSetImpl();

    @SuppressWarnings("unchecked")
    public ModelManager() {
        Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("*",
                new XMIResourceFactoryImpl());
    }

    public static ModelManager INSTANCE = new ModelManager();

    @SuppressWarnings("unchecked")
    public Resource loadMetaModel(String metaFileName) {
        URI metaURI = URI.createFileURI(metaFileName);
        Resource metaRes = _resSet.getResource(metaURI, true);
        for (Iterator it = metaRes.getAllContents(); it.hasNext();) {
            Object object = it.next();
            if (object instanceof EPackage) {
                String nsURI = ((EPackage) object).getNsURI();
                if (nsURI == null || nsURI.equals(""))
                    nsURI = ((EPackage) object).getName();
                EPackage.Registry.INSTANCE.put(nsURI, object);
            }

            if (object instanceof EDataType) {
                modifyDataTypeAccordingToATL(object);
            }
        }

        return metaRes;
    }

    private void modifyDataTypeAccordingToATL(Object object) {
        EDataType dataType = (EDataType) object;
        String tname = dataType.getName();
        String icn = null;
        if (tname.equals("Boolean")) {
            icn = "boolean"; // "java.lang.Boolean";
        } else if (tname.equals("Double")) {
            icn = "java.lang.Double";
        } else if (tname.equals("Float")) {
            icn = "java.lang.Float";
        } else if (tname.equals("Integer")) {
            icn = "java.lang.Integer";
        } else if (tname.equals("String")) {
            icn = "java.lang.String";
        }
        if (icn != null)
            dataType.setInstanceClassName(icn);
    }

    public Resource loadModel(String fileName) {
        URI fileURI = URI.createFileURI(fileName);

        return _resSet.getResource(fileURI, true);

    }

    /**
     * @return the resSet
     */
    public ResourceSet getResSet() {
        return _resSet;
    }

    protected static Object getAttribute(EObject o, String firstAttr) {
        return o.eGet(o.eClass().getEStructuralFeature(firstAttr));
    }

    protected static void setAttribute(EObject object, String attributeName,
            Object attributeVal) {
        object.eSet(object.eClass().getEStructuralFeature(attributeName),
                attributeVal);
    }

    public static EObject createObject(String packageNsURI, String className) {
        EPackage ePackage = EPackage.Registry.INSTANCE
                .getEPackage(packageNsURI);
        EFactory eFactory = ePackage.getEFactoryInstance();

        EClass eClass = (EClass) ePackage.getEClassifier(className);
        EObject eObject = eFactory.create(eClass);

        return eObject;
    }

}
