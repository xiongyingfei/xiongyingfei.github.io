/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM;

import java.io.IOException;

public class Main {

    /**
     * @param args
     */
    public static void main(String[] args) {
        try {
            if (args.length >= 3)
                if (args[0].equals("-mm") || args[0].equals("-metamodel")) {
                    MetaConvertor.convert(args[1], args[2]);
                    return;
                }
                else if ((args[0].equals("-m") || args[0].equals("-model")) && args.length >= 4) {
                    ModelConvertor.convert(args[1], args[2], args[3]);
                    return;
                }
                else if (args[0].equals("-atl") || args[0].equals("-a")) {
                    ATLConvertor.convert(args[1], args[2]);
                    return;
                }
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.print("Usage:\n" +
                "Convert a meta-model:       java -AddID.jar -metamodel sourceFile targetFile\n" +
                "Convert a model:            java -AddID.jar -model metaModelFile sourceFile targetFile\n" +
                "Convert an ATL source file: java -AddID.jar -atl sourceFile targetFile\n");
        

    }

}
