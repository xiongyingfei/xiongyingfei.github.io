/*
 * Copyright (c) 2007, Xiong Yingfei, the University of Tokyo
 * All rights reserved.
 */
package jp.ac.u_tokyo.ipl.BiXM;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.LinkedList;
import java.util.List;

public class ATLConvertor {

    public static void main(String[] args) {
        try {
            convert("testData/Class2Relational.atl",
                    "testData/Class2RelationalID.atl");
            convert("testData/SimpleClass2SimpleRDBMS.atl",
                    "testData/SimpleClass2SimpleRDBMSID.atl");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class CommentStorer {
        int lineNumber;

        String content;

        public CommentStorer(int lineNumber, String content) {
            super();
            this.lineNumber = lineNumber;
            this.content = content;
        }

        @Override
        public String toString() {
            return new Integer(lineNumber).toString() + ":" + content;
        }
        
        
    }

    private static List<CommentStorer> _comments = new LinkedList<CommentStorer>();

    private static void insertComment(StringBuilder sb, CommentStorer comment) {
        int lastLinePos = -1;
        int curLine = 0;

        while (true) {
            lastLinePos = sb.indexOf("\n", lastLinePos + 1);
            if (lastLinePos < 0)
                return;
            if (curLine == comment.lineNumber) {
                sb.insert(lastLinePos, comment.content);
                return;
            }
            curLine++;
        }
    }
    
    private static int _postFixCounter = 0;
    private static String getPostFix() {
        return "a" + new Integer(_postFixCounter++).toString();
    }

    public static void convert(String srcFile, String tgtFile)
            throws IOException {
        LineNumberReader r = new LineNumberReader(new FileReader(srcFile));

        StringBuilder sb = new StringBuilder();
        String line = r.readLine();
        while (line != null) {
            int index = line.indexOf("--");
            if (index >= 0) {
                _comments.add(new CommentStorer(r.getLineNumber(), line
                        .substring(index)));
                line = line.substring(0, index);
            }

            sb.append(line);
            sb.append("\n");
            line = r.readLine();
        }
        String text = sb.toString();

        StringBuilder result = new StringBuilder();

        int ruleStart = findWord(text, "rule", 0) + 4;
        int lastPos = 0;
        while (ruleStart > 3) {
            int fromStart = findWord(text, "from", ruleStart) + 4;
            String fromVar = findNextWord(text, fromStart);

            int toStart = findWord(text, "to", fromStart) + 2;

            int rightBracket = findEndParenthesis(text, toStart, 1, '{', '}');
            int lastRightParen = toStart;
            int leftParen = text.indexOf('(', lastRightParen);

            while (leftParen > 0 && leftParen < rightBracket) {

                String var = findforeach(text, lastRightParen, leftParen);
                if (var == null)
                    var = fromVar;
                else {
                    lastRightParen = findEndParenthesis(text, text.indexOf("(",
                            lastRightParen) + 1, 1, '(', ')');
                    leftParen = text.indexOf('(', lastRightParen);
                }

                lastRightParen = findEndParenthesis(text, leftParen + 1, 1,
                        '(', ')');
                result.append(text.substring(lastPos, lastRightParen));
                result.append(",ID <- " + var + ".ID + \'" + getPostFix() + "\'");
                lastPos = lastRightParen;
                leftParen = text.indexOf('(', lastRightParen);
            }

            ruleStart = findWord(text, "rule", rightBracket) + 4;
        }

        result.append(text.substring(lastPos));
        
        for(CommentStorer cs : _comments) {
            insertComment(result, cs);
        }

        FileWriter writer = new FileWriter(tgtFile);
        try {
            writer.write(result.toString());
        } finally {
            writer.close();
        }
    }

    private static int findWord(String text, String word, int start) {
        while (true) {
            SubStringPos pos = findNextWordPos(text, start);
            if (pos.start < start)
                return -1;
            if (text.subSequence(pos.start, pos.end).equals(word))
                return pos.start;
            start = pos.end;
        }
    }

    private static String findforeach(String text, int start, int end) {
        String part = text.substring(start, end);
        int index = part.indexOf("foreach");
        if (index < 0)
            return null;

        return findNextWord(text, index + start + 7);
    }

    private static int findEndParenthesis(String text, int start,
            int openCount, char leftParen, char rightParen) {
        for (int i = start; i < text.length(); i++) {
            if (text.charAt(i) == leftParen)
                openCount++;
            else if (text.charAt(i) == rightParen)
                openCount--;

            if (openCount == 0)
                return i;
        }
        return -1;
    }

    private static class SubStringPos {
        int start = -1;

        int end = -1;
    }

    private static String findNextWord(String text, int start) {
        // StringBuilder sb = new StringBuilder();
        // boolean inWord = false;
        // for (int i = start; i < text.length(); i++) {
        // if (!inWord) {
        // if (Character.isJavaIdentifierStart(text.charAt(i))) {
        // inWord = true;
        // sb.append(text.charAt(i));
        // }
        // } else {
        // if (!Character.isJavaIdentifierPart(text.charAt(i)))
        // break;
        // sb.append(text.charAt(i));
        //
        // }
        // }
        // return sb.toString();

        SubStringPos result = findNextWordPos(text, start);
        return text.substring(result.start, result.end);
    }

    private static SubStringPos findNextWordPos(String text, int start) {
        SubStringPos result = new SubStringPos();
        boolean inWord = false;
        int i;
        for (i = start; i < text.length(); i++) {
            if (!inWord) {
                if (Character.isJavaIdentifierStart(text.charAt(i))) {
                    inWord = true;
                    result.start = i;
                }
            } else {
                if (!Character.isJavaIdentifierPart(text.charAt(i))) {
                    result.end = i;
                    break;
                }
            }
        }
        if (result.start >= start && result.end < 0)
            result.end = i;
        return result;
    }

}
