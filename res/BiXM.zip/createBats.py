synchronization = """
@java -ea -jar ../BiXM.jar --s --trans file:%(src)s2%(tgt)s.asm --src IN=Source.%(src)s %(src)s=%(src)s.ecore --tgt OUT=target-modified.%(tgt)s %(tgt)s=%(tgt)s.ecore --modifiedSrc IN=source-modified.%(src)s --outSrc IN=source-synchronized.%(src)s --outTgt OUT=target-synchronized.%(tgt)s --checkif
"""

transform = """
@java -ea -jar ../BiXM.jar --f --trans file:%(src)s2%(tgt)s.asm --src IN=Source.%(src)s %(src)s=%(src)s.ecore --tgt OUT=target.%(tgt)s %(tgt)s=%(tgt)s.ecore
@copy source.%(src)s source-modified.%(src)s
@copy target.%(tgt)s target-modified.%(tgt)s
"""

clear= """
@del *-synchronized.*
@del *-modified.*
"""

import sys
src = sys.argv[1]
tgt = sys.argv[2]
open("clear.bat", "w").write(clear % {'src':src, 'tgt':tgt})
open("synchronize.bat", "w").write(synchronization % {'src':src, 'tgt':tgt})
open("transform.bat", "w").write(transform % {'src':src, 'tgt':tgt})
