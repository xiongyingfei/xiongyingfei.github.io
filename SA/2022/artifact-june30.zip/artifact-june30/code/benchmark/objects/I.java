package benchmark.objects;

public interface I {
	// G and H implement I

	public A foo(A a);
}
