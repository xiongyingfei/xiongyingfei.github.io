package benchmark.objects;

public class B {

	// Object B used as attribute of objects of type A

	public B() {
	}
}
