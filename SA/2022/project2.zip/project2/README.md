# SyGuS

pip install z3-solver

run 'python main.py 0.sl' and you will get the result of that trivial case.

A simple framework for Syntax-Guided Synthesis problem.

The framework now supports:

Only Int sort

Only one synth-fun expression

No define-fun expression

SMT-LIB:http://smtlib.cs.uiowa.edu/