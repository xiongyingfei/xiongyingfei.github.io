Run the following command to test all programs in /programs:
	python test.py
