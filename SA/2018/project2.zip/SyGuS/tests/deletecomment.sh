sed -i '/;/d' `grep -rl ';' ./`
