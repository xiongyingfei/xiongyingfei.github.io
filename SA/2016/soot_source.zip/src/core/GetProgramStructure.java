package core;

import java.util.Map;

import soot.Body;
import soot.PackManager;
import soot.Scene;
import soot.SceneTransformer;
import soot.SootClass;
import soot.SootField;
import soot.SootMethod;
import soot.Transform;
import soot.Unit;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.toolkits.graph.BriefUnitGraph;

public class GetProgramStructure {

	public static void main(String[] args) {
		
		PackManager.v().getPack("wjtp").add(
				
				new Transform("wjtp.myanalysis", new SceneTransformer() {
						@Override
						protected void internalTransform(String arg0, 
								Map<String, String> arg1) {	
							SootMethod mainMethod = Scene.v().getMainMethod();
							Body b = mainMethod.getActiveBody();
							BriefUnitGraph g = new BriefUnitGraph(b);
							LivenessAnalysis la = new LivenessAnalysis(g);
							for (Unit u : b.getUnits()) {
								System.out.print(u);
								System.out.println(" After: " + la.getFlowAfter(u));
								System.out.println(" Before: " + la.getFlowBefore(u));
							}
						}
					}
				)
				
			);
		
		String jdkLibPath = "/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/";
		String classpath = "bin"
				+ ":" + jdkLibPath + "rt.jar"
				+ ":" + jdkLibPath + "jsse.jar"
				+ ":" + jdkLibPath + "jce.jar";
		soot.Main.main(new String[] {
				"-w",
				"-p", "cg.spark", "enabled:true",
				"-p", "wjtp.myanalysis", "enabled:true",
				"-soot-class-path", classpath,
				"tests.Main"
		});
	}
}
