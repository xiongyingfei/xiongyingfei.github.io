package benchmark.objects;

public class P extends Q {

	public P(A a) {
		super(a);
	}
}
