# SyGuS

A simple framework for Syntax-Guided Synthesis problem.

The framework now supports:

Only Int sort

Only one synth-fun expression

No define-fun expression

