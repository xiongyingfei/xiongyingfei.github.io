package benchmark.internal;


public class Benchmark {

	public static void alloc(int id) {

	}

	public static void test(int id, Object targetVariable) {

	}

}
