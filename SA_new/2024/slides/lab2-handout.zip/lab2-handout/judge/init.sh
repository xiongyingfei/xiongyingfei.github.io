#!/bin/bash
docker build --no-cache -t lab2_submitter_local lab2_submitter
