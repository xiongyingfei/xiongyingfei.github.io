#!/bin/bash
docker build -t lab2_submitter_local lab2_submitter
